-- =========================================================================
-- FUNHAM AI V2.0 - SUPABASE DATABASE MIGRATION SCRIPT
-- Phục vụ lưu trữ tập trung, đồng bộ xuyên thiết bị & phân quyền minh chứng
-- =========================================================================

-- 1. BẢNG CLASSES (Lớp học)
create table if not exists public.classes (
  id uuid default gen_random_uuid() primary key,
  class_code text not null unique,
  class_name text not null,
  teacher_id text not null default 'gv1',
  created_at timestamptz default now()
);

-- 2. BẢNG STUDENTS (Học sinh)
create table if not exists public.students (
  id uuid default gen_random_uuid() primary key,
  class_id uuid not null references public.classes(id) on delete cascade,
  student_code text not null,
  display_name text not null,
  created_at timestamptz default now(),
  constraint uq_student_in_class unique (class_id, student_code)
);

-- 3. BẢNG ATTEMPTS (Lượt làm bài / khảo sát / luyện tập)
create table if not exists public.attempts (
  id uuid default gen_random_uuid() primary key,
  student_id uuid not null references public.students(id) on delete cascade,
  activity_id text not null,
  activity_type text not null, -- 'pre_assessment', 'post_assessment', 'practice', 'formula_doctor'
  score numeric(5,2) not null default 0,
  max_score numeric(5,2) not null default 10,
  started_at timestamptz default now(),
  completed_at timestamptz default now(),
  is_demo boolean not null default false
);

-- 4. BẢNG ERROR_EVENTS (Sự kiện lỗi công thức & tự sửa lỗi qua gợi ý AI)
create table if not exists public.error_events (
  id uuid default gen_random_uuid() primary key,
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  error_code text not null, -- E01 đến E10
  corrected boolean not null default false,
  hint_count integer not null default 0,
  created_at timestamptz default now()
);

-- 5. CHỈ MỤC TỐI ƯU TRUY VẤN (INDEXES)
create index if not exists idx_classes_code on public.classes(class_code);
create index if not exists idx_students_class on public.students(class_id);
create index if not exists idx_students_code on public.students(student_code);
create index if not exists idx_attempts_student on public.attempts(student_id);
create index if not exists idx_attempts_is_demo on public.attempts(is_demo);
create index if not exists idx_attempts_activity on public.attempts(activity_type);
create index if not exists idx_error_events_attempt on public.error_events(attempt_id);

-- 6. THIẾT LẬP ROW LEVEL SECURITY (RLS)
alter table public.classes enable row level security;
alter table public.students enable row level security;
alter table public.attempts enable row level security;
alter table public.error_events enable row level security;

-- Policy cho bảng classes (Cho phép đọc và thêm lớp học)
drop policy if exists "Allow public select classes" on public.classes;
create policy "Allow public select classes" on public.classes
  for select using (true);

drop policy if exists "Allow public insert classes" on public.classes;
create policy "Allow public insert classes" on public.classes
  for insert with check (true);

-- Policy cho bảng students (Cho phép đọc, thêm, cập nhật học sinh)
drop policy if exists "Allow public select students" on public.students;
create policy "Allow public select students" on public.students
  for select using (true);

drop policy if exists "Allow public insert students" on public.students;
create policy "Allow public insert students" on public.students
  for insert with check (true);

drop policy if exists "Allow public update students" on public.students;
create policy "Allow public update students" on public.students
  for update using (true);

-- Policy cho bảng attempts (Cho phép đọc và ghi kết quả làm bài)
drop policy if exists "Allow public select attempts" on public.attempts;
create policy "Allow public select attempts" on public.attempts
  for select using (true);

drop policy if exists "Allow public insert attempts" on public.attempts;
create policy "Allow public insert attempts" on public.attempts
  for insert with check (true);

-- Policy cho bảng error_events (Cho phép ghi nhận sự kiện lỗi và chẩn đoán)
drop policy if exists "Allow public select error_events" on public.error_events;
create policy "Allow public select error_events" on public.error_events
  for select using (true);

drop policy if exists "Allow public insert error_events" on public.error_events;
create policy "Allow public insert error_events" on public.error_events
  for insert with check (true);

-- 7. DỮ LIỆU KHỞI TẠO CÁC LỚP MẪU NĂM HỌC
insert into public.classes (class_code, class_name, teacher_id)
values 
  ('7A1', 'Lớp 7A1 - Năm học 2025-2026', 'gv1'),
  ('7A2', 'Lớp 7A2 - Năm học 2025-2026', 'gv1'),
  ('7A3', 'Lớp 7A3 - Năm học 2025-2026', 'gv1')
on conflict (class_code) do nothing;
