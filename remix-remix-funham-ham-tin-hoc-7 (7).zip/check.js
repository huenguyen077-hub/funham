import fs from 'fs';
import path from 'path';

function findImports(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            findImports(fullPath);
        } else if (fullPath.endsWith('.ts') || fullPath.endsWith('.tsx')) {
            const content = fs.readFileSync(fullPath, 'utf8');
            if (content.includes('@google/genai') || content.includes('genai')) {
                console.log(`Found in ${fullPath}`);
            }
        }
    }
}
findImports('./src');
console.log('Done');
