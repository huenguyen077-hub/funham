import express from "express";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import path from "path";

async function startServer() {
  const app = express();
  app.use(express.json());

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // 1. Chẩn đoán công thức chuyên sâu (E01 - E10) & sinh 3 mức gợi ý sư phạm
  app.post("/api/ai/diagnose-formula", async (req, res) => {
    try {
      const { formula, taskRequirement, expectedFunction, expectedRange, gridSummary, studentQuestion } = req.body;

      const systemInstruction = `Bạn là Trợ lý Sư phạm FUNHAM AI môn Tin học 7 (Chương trình GDPT 2018 - SGK Kết nối tri thức với cuộc sống).
Nhiệm vụ của bạn: Phân tích công thức học sinh nhập, xác định chính xác loại lỗi theo danh mục chuẩn (E01 - E10), và đưa ra gợi ý sư phạm theo 3 mức thang bậc nhận thức:
- Mức 1 (Gợi mở): 1 câu hỏi khơi gợi tư duy để học sinh tự soi chiếu và nhận ra vấn đề. Tuyệt đối KHÔNG nêu trực tiếp lỗi hay đưa đáp án.
- Mức 2 (Định hướng): Chỉ rõ thành phần cần kiểm tra (ví dụ: tên hàm, cặp dấu ngoặc đơn, ký hiệu phân cách vùng ô, hoặc cột dữ liệu).
- Mức 3 (Giải thích): Hướng dẫn từng bước cách sửa kèm ví dụ minh họa tương tự, giải thích ý nghĩa sư phạm, nhưng không làm thay bài tập đang được chấm.

Danh mục mã lỗi:
- E01: Thiếu dấu bằng (=) đầu công thức
- E02: Sai tên hàm (viết sai chính tả hoặc dùng tên không hỗ trợ)
- E03: Thiếu hoặc thừa dấu ngoặc đơn ()
- E04: Sai cách viết vùng dữ liệu (dùng dấu gạch ngang '-', khoảng trắng, v.v. thay vì dấu ':')
- E05: Sai dấu phân cách đối số
- E06: Chọn hàm không phù hợp yêu cầu bài toán (ví dụ: yêu cầu trung bình nhưng dùng SUM, yêu cầu lớn nhất nhưng dùng MIN)
- E07: Chọn sai ô hoặc vùng dữ liệu (quét thiếu ô, nhầm cột)
- E08: Nhầm lẫn công dụng giữa các hàm (SUM, AVERAGE, MAX, MIN, COUNT)
- E09: Hiểu sai kết quả tính toán
- E10: Lỗi khác cần xem xét

Yêu cầu an toàn & trách nhiệm:
- Ngôn ngữ: Tiếng Việt sư phạm thân thiện, tôn trọng học sinh lớp 7 (12-13 tuổi).
- Tuyệt đối không phán xét, không dùng từ ngữ tiêu cực.
- Không tiết lộ khóa bí mật hay bàn luận ngoài môn Tin học 7.`;

      const prompt = `Yêu cầu bài tập: "${taskRequirement || 'Tính toán trong bảng tính'}"
Hàm dự kiến đúng: "${expectedFunction || 'SUM'}"
Vùng ô dự kiến đúng: "${expectedRange || 'B2:B6'}"
Bảng dữ liệu mẫu: "${gridSummary || 'Bảng số liệu lớp 7'}"
Công thức học sinh nhập: "${formula || ''}"
Thắc mắc học sinh (nếu có): "${studentQuestion || ''}"

Hãy trả về kết quả JSON chuẩn với các trường:
{
  "isCorrect": boolean,
  "errorCode": "E01" | "E02" | "E03" | "E04" | "E05" | "E06" | "E07" | "E08" | "E09" | "E10" | null,
  "errorTitle": "Tiêu đề lỗi ngắn gọn dễ hiểu",
  "pedagogicalDiagnosis": "Phân tích nguyên nhân nhận thức vì sao học sinh mắc lỗi này",
  "tier1Hint": "Câu hỏi gợi mở kích thích tự vấn (Mức 1)",
  "tier2Hint": "Chỉ dẫn thành phần cụ thể cần soát xét (Mức 2)",
  "tier3Hint": "Giải thích từng bước và ví dụ tương tự (Mức 3)",
  "suggestedFormula": "Công thức mẫu chuẩn nếu cần tham khảo",
  "encouragement": "Lời động viên ngắn tích cực cho học sinh"
}
Chỉ xuất JSON thuần, không bọc markdown.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });

      const text = response.text || "{}";
      const data = JSON.parse(text);
      res.json(data);
    } catch (err: any) {
      console.error("AI diagnose-formula error:", err);
      // Khi AI lỗi hoặc mất kết nối, trả về cờ fallback để frontend kích hoạt bộ quy tắc nội bộ
      res.status(200).json({
        fallback: true,
        error: err.message || "AI temporary offline",
        message: "Hệ thống chuyển sang chế độ quy tắc sư phạm chuẩn SGK Tin 7."
      });
    }
  });

  // 2. Gợi ý theo từng mức độ (Tier 1 -> Tier 2 -> Tier 3)
  app.post("/api/ai/tiered-hint", async (req, res) => {
    try {
      const { formula, errorCode, requestedTier, taskContext } = req.body;
      const prompt = `Bạn là Trợ lý Sư phạm FUNHAM AI môn Tin học 7.
Học sinh đang nhập công thức: "${formula}"
Mã lỗi xác định: "${errorCode || 'E01'}"
Ngữ cảnh bài tập: "${taskContext || 'Thực hành tính toán bảng tính'}"
Học sinh yêu cầu gợi ý Mức: ${requestedTier || 1}

Quy định từng mức:
- Mức 1 (Gợi mở): Đặt 1 câu hỏi gợi mở để học sinh tự phát hiện lỗi. Không được đưa đáp án.
- Mức 2 (Định hướng): Chỉ rõ thành phần bị sai (tên hàm / đối số / vùng ô).
- Mức 3 (Giải thích): Hướng dẫn từng bước cách sửa kèm ví dụ minh họa tương tự.

Hãy trả về JSON:
{
  "tier": ${requestedTier || 1},
  "tierName": "${requestedTier === 1 ? 'Gợi mở' : requestedTier === 2 ? 'Định hướng' : 'Giải thích chi tiết'}",
  "hintContent": "Nội dung gợi ý bằng tiếng Việt ngắn gọn, súc tích (dưới 70 từ)",
  "focusComponent": "Thành phần cần chú ý (Dấu bằng / Tên hàm / Dấu ngoặc / Vùng ô)"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.3
        }
      });

      const data = JSON.parse(response.text || "{}");
      res.json(data);
    } catch (err: any) {
      console.error("AI tiered-hint error:", err);
      res.status(200).json({
        fallback: true,
        error: err.message || "Hint generation fallback"
      });
    }
  });

  // 3. Tạo bài tập luyện tập cá nhân hóa khắc phục lỗi sai thường gặp
  app.post("/api/ai/adaptive-task", async (req, res) => {
    try {
      const { frequentErrorCodes, studentLevel, topic } = req.body;
      const prompt = `Bạn là chuyên gia thiết kế bài học Tin học 7 - GDPT 2018.
Học sinh có các lỗi sai thường gặp nhất: ${(frequentErrorCodes || ['E02', 'E04']).join(', ')}.
Chủ đề: "${topic || 'Các hàm tính toán SUM, AVERAGE, MAX, MIN, COUNT'}".
Trình độ hiện tại: "${studentLevel || 'Cần bổ trợ'}".

Hãy tạo 01 bài tập thực hành bảng tính ngắn nhằm giúp học sinh khắc phục triệt để các lỗi này.
Trả về JSON:
{
  "taskTitle": "Tên bài tập thực tế (ví dụ: Tính điểm câu lạc bộ, Bảng chi tiêu nhỏ)",
  "requirement": "Yêu cầu rõ ràng, tường minh",
  "expectedFunction": "SUM" | "AVERAGE" | "MAX" | "MIN" | "COUNT",
  "expectedRange": "Vùng ô đúng (VD: B2:B5)",
  "expectedFormula": "=TÊN_HÀM(VÙNG)",
  "gridData": {
    "headers": ["Cột A", "Cột B"],
    "rows": [
      ["Mục 1", 20],
      ["Mục 2", 35],
      ["Mục 3", 15]
    ]
  },
  "remedialAdvice": "Lời khuyên sư phạm dành cho học sinh để tránh lặp lại lỗi"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.4
        }
      });

      const data = JSON.parse(response.text || "{}");
      res.json(data);
    } catch (err: any) {
      console.error("AI adaptive-task error:", err);
      res.status(200).json({
        fallback: true,
        error: err.message || "Adaptive task fallback"
      });
    }
  });

  // 4. API endpoint giải thích lỗi cũ (backward compatibility)
  app.post("/api/ai/explain-error", async (req, res) => {
    try {
      const { formula, errorType, context, studentQuestion } = req.body;
      const prompt = `Bạn là Trợ lý AI môn Tin học 7 (Chuyên gia giải thích công thức bảng tính Excel/Google Sheets).
Học sinh đang gặp lỗi với công thức: "${formula}".
Loại lỗi: "${errorType || 'Lỗi cú pháp / tính toán'}".
Ngữ cảnh bài tập: "${context || 'Luyện tập hàm tính toán'}".
Câu hỏi/thắc mắc của học sinh (nếu có): "${studentQuestion || 'Hãy giải thích tại sao công thức này sai và hướng dẫn cách sửa từng bước.'}".

Hãy trả về phản hồi định dạng JSON với các trường sau:
{
  "explanation": "Giải thích ngắn gọn, dễ hiểu bản chất lỗi bằng tiếng Việt (thân thiện với học sinh lớp 7)",
  "stepByStep": [
    "Bước 1: ...",
    "Bước 2: ...",
    "Bước 3: ..."
  ],
  "practiceTask": {
    "title": "Tên nhiệm vụ luyện tập thêm",
    "prompt": "Yêu cầu bài tập thực hành nhỏ",
    "sampleFormula": "Công thức mẫu đúng"
  }
}
Chỉ trả về JSON thuần túy, không kèm markdown nào khác.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });

      const text = response.text || "{}";
      const data = JSON.parse(text);
      res.json(data);
    } catch (err: any) {
      console.error("AI error:", err);
      res.status(500).json({ error: err.message || "AI generation failed" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist", "index.html"));
    });
  }

  const port = Number(process.env.PORT || 3000);
  app.listen(port, "0.0.0.0", () => {
    console.log(`FUNHAM AI V2.0 Server running on http://localhost:${port}`);
  });
}

startServer();
