import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Database, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  Check, 
  RefreshCw, 
  ExternalLink,
  Wifi,
  WifiOff,
  ShieldCheck,
  Send
} from 'lucide-react';
import { Button } from './ui/Button';
import { 
  getSupabaseConfig, 
  saveSupabaseConfig, 
  isSupabaseConfigured, 
  getSupabase 
} from '../services/supabaseClient';
import { 
  getOfflineQueueCount, 
  flushOfflineQueue 
} from '../services/databaseService';

interface SupabaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigChanged?: () => void;
}

export function SupabaseConfigModal({ isOpen, onClose, onConfigChanged }: SupabaseConfigModalProps) {
  const [url, setUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [queueCount, setQueueCount] = useState(0);
  const [isSyncingQueue, setIsSyncingQueue] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const config = getSupabaseConfig();
      setUrl(config.url);
      setAnonKey(config.anonKey);
      setTestResult(null);
      setQueueCount(getOfflineQueueCount());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    const cleanUrl = url.trim().replace(/\/rest\/v1\/?$/i, '').replace(/\/graphql\/?$/i, '').replace(/\/+$/, '');
    let cleanKey = anonKey.trim();
    if (cleanKey.startsWith('AQ.')) {
      cleanKey = cleanKey.substring(3);
    }

    if (!cleanUrl || !cleanKey) {
      setTestResult({
        success: false,
        message: 'Vui lòng nhập đầy đủ Supabase Project URL và Anon Public Key.',
      });
      return;
    }

    setUrl(cleanUrl);
    setAnonKey(cleanKey);

    setIsTesting(true);
    setTestResult(null);

    try {
      // Save temporarily to test
      saveSupabaseConfig(cleanUrl, cleanKey);
      const client = getSupabase();
      if (!client) {
        throw new Error('Không thể khởi tạo Supabase Client. Kiểm tra định dạng URL.');
      }

      // Ping classes table
      const { data, error } = await client.from('classes').select('id, class_code').limit(1);
      if (error) {
        if (error.code === '42P01') {
          setTestResult({
            success: false,
            message: 'Kết nối thành công nhưng CHƯA TẠO BẢNG trong Supabase! Hãy copy file SQL và chạy trong SQL Editor.',
          });
        } else {
          setTestResult({
            success: false,
            message: `Lỗi kết nối: ${error.message} (Code: ${error.code})`,
          });
        }
      } else {
        setTestResult({
          success: true,
          message: 'Kết nối Supabase THÀNH CÔNG! Bảng dữ liệu đã sẵn sàng nhận kết quả học sinh.',
        });
        if (onConfigChanged) onConfigChanged();
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Không thể kết nối đến máy chủ Supabase.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSave = () => {
    const cleanUrl = url.trim().replace(/\/rest\/v1\/?$/i, '').replace(/\/graphql\/?$/i, '').replace(/\/+$/, '');
    let cleanKey = anonKey.trim();
    if (cleanKey.startsWith('AQ.')) {
      cleanKey = cleanKey.substring(3);
    }
    saveSupabaseConfig(cleanUrl, cleanKey);
    setUrl(cleanUrl);
    setAnonKey(cleanKey);
    if (onConfigChanged) onConfigChanged();
    onClose();
  };

  const handleClear = () => {
    saveSupabaseConfig('', '');
    setUrl('');
    setAnonKey('');
    setTestResult({
      success: true,
      message: 'Đã xóa cấu hình. Hệ thống chuyển sang chế độ dữ liệu bộ nhớ nội bộ.',
    });
    if (onConfigChanged) onConfigChanged();
  };

  const handleFlushQueue = async () => {
    setIsSyncingQueue(true);
    try {
      const { syncedCount, errorsCount } = await flushOfflineQueue();
      setQueueCount(getOfflineQueueCount());
      if (syncedCount > 0) {
        setTestResult({
          success: true,
          message: `Đã đồng bộ thành công ${syncedCount} bản ghi tồn đọng lên Supabase!`,
        });
        if (onConfigChanged) onConfigChanged();
      } else if (errorsCount > 0) {
        setTestResult({
          success: false,
          message: `Chưa thể đồng bộ ${errorsCount} bản ghi. Hãy kiểm tra kết nối mạng và khóa Supabase.`,
        });
      }
    } catch (e: any) {
      setTestResult({ success: false, message: e.message || 'Lỗi đồng bộ hàng đợi' });
    } finally {
      setIsSyncingQueue(false);
    }
  };

  const FULL_SQL_SCHEMA = `-- =========================================================================
-- FUNHAM AI V2.0 - SUPABASE DATABASE MIGRATION SCRIPT
-- Phục vụ lưu trữ tập trung, đồng bộ xuyên thiết bị & phân quyền minh chứng
-- =========================================================================

-- 1. BẢNG CLASSES (Lớp học)
create table if not exists public.classes (
  id uuid default gen_random_uuid() primary key,
  class_code text not null unique,
  class_name text not null,
  teacher_id text not null default 'gv1',
  created_at timestamptz default now()
);

-- 2. BẢNG STUDENTS (Học sinh)
create table if not exists public.students (
  id uuid default gen_random_uuid() primary key,
  class_id uuid not null references public.classes(id) on delete cascade,
  student_code text not null,
  display_name text not null,
  created_at timestamptz default now(),
  constraint uq_student_in_class unique (class_id, student_code)
);

-- 3. BẢNG ATTEMPTS (Lượt làm bài / khảo sát / luyện tập)
create table if not exists public.attempts (
  id uuid default gen_random_uuid() primary key,
  student_id uuid not null references public.students(id) on delete cascade,
  activity_id text not null,
  activity_type text not null, -- 'pre_assessment', 'post_assessment', 'practice', 'formula_doctor'
  score numeric(5,2) not null default 0,
  max_score numeric(5,2) not null default 10,
  started_at timestamptz default now(),
  completed_at timestamptz default now(),
  is_demo boolean not null default false
);

-- 4. BẢNG ERROR_EVENTS (Sự kiện lỗi công thức & tự sửa lỗi qua gợi ý AI)
create table if not exists public.error_events (
  id uuid default gen_random_uuid() primary key,
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  error_code text not null, -- E01 đến E10
  corrected boolean not null default false,
  hint_count integer not null default 0,
  created_at timestamptz default now()
);

-- 5. CHỈ MỤC TỐI ƯU TRUY VẤN (INDEXES)
create index if not exists idx_classes_code on public.classes(class_code);
create index if not exists idx_students_class on public.students(class_id);
create index if not exists idx_students_code on public.students(student_code);
create index if not exists idx_attempts_student on public.attempts(student_id);
create index if not exists idx_attempts_is_demo on public.attempts(is_demo);
create index if not exists idx_attempts_activity on public.attempts(activity_type);
create index if not exists idx_error_events_attempt on public.error_events(attempt_id);

-- 6. THIẾT LẬP ROW LEVEL SECURITY (RLS)
alter table public.classes enable row level security;
alter table public.students enable row level security;
alter table public.attempts enable row level security;
alter table public.error_events enable row level security;

-- Policy cho bảng classes
drop policy if exists "Allow public select classes" on public.classes;
create policy "Allow public select classes" on public.classes for select using (true);
drop policy if exists "Allow public insert classes" on public.classes;
create policy "Allow public insert classes" on public.classes for insert with check (true);

-- Policy cho bảng students
drop policy if exists "Allow public select students" on public.students;
create policy "Allow public select students" on public.students for select using (true);
drop policy if exists "Allow public insert students" on public.students;
create policy "Allow public insert students" on public.students for insert with check (true);
drop policy if exists "Allow public update students" on public.students;
create policy "Allow public update students" on public.students for update using (true);

-- Policy cho bảng attempts
drop policy if exists "Allow public select attempts" on public.attempts;
create policy "Allow public select attempts" on public.attempts for select using (true);
drop policy if exists "Allow public insert attempts" on public.attempts;
create policy "Allow public insert attempts" on public.attempts for insert with check (true);

-- Policy cho bảng error_events
drop policy if exists "Allow public select error_events" on public.error_events;
create policy "Allow public select error_events" on public.error_events for select using (true);
drop policy if exists "Allow public insert error_events" on public.error_events;
create policy "Allow public insert error_events" on public.error_events for insert with check (true);

-- 7. KHỞI TẠO CÁC LỚP MẪU NĂM HỌC
insert into public.classes (class_code, class_name, teacher_id)
values 
  ('7A1', 'Lớp 7A1 - Năm học 2025-2026', 'gv1'),
  ('7A2', 'Lớp 7A2 - Năm học 2025-2026', 'gv1'),
  ('7A3', 'Lớp 7A3 - Năm học 2025-2026', 'gv1')
on conflict (class_code) do nothing;`;

  const copySqlToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(FULL_SQL_SCHEMA);
      setCopiedSql(true);
      setTimeout(() => setCopiedSql(false), 3000);
    } catch (e) {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = FULL_SQL_SCHEMA;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopiedSql(true);
      setTimeout(() => setCopiedSql(false), 3000);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-white rounded-3xl border-4 border-slate-300 shadow-2xl max-w-2xl w-full overflow-hidden text-slate-900 my-8"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-cyan-800 p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center text-2xl shadow-inner">
                <Database className="w-6 h-6 text-emerald-300" />
              </div>
              <div>
                <h3 className="text-xl md:text-2xl font-black uppercase tracking-wider">
                  Cấu hình Cơ sở dữ liệu Supabase
                </h3>
                <p className="text-xs text-emerald-100 font-bold">
                  Đồng bộ điểm và kết quả học sinh theo thời gian thực xuyên thiết bị
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 md:p-8 space-y-6 max-h-[75vh] overflow-y-auto text-sm">
            {/* Status overview */}
            <div className="p-4 rounded-2xl border-2 flex items-center justify-between gap-4 bg-slate-50 border-slate-200">
              <div className="flex items-center gap-3">
                {isSupabaseConfigured() ? (
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                    <Wifi className="w-5 h-5" />
                  </div>
                ) : (
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-black">
                    <WifiOff className="w-5 h-5" />
                  </div>
                )}
                <div>
                  <div className="font-black text-slate-800 text-sm">
                    {isSupabaseConfigured() ? 'ĐÃ KẾT NỐI SUPABASE CLOUD' : 'CHƯA CẤU HÌNH SUPABASE TRỰC TUYẾN'}
                  </div>
                  <div className="text-xs text-slate-500 font-bold">
                    {isSupabaseConfigured()
                      ? 'Dữ liệu học sinh sẽ được lưu trực tiếp lên đám mây và đồng bộ sang máy giáo viên.'
                      : 'Hệ thống đang hoạt động ở chế độ bộ nhớ cục bộ (chỉ lưu trên máy học sinh đang dùng).'}
                  </div>
                </div>
              </div>

              {queueCount > 0 && (
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-black">
                    {queueCount} bài chờ đồng bộ
                  </span>
                  <div className="mt-1">
                    <button
                      onClick={handleFlushQueue}
                      disabled={isSyncingQueue}
                      className="text-xs text-blue-600 hover:underline font-black cursor-pointer"
                    >
                      {isSyncingQueue ? 'Đang gửi...' : 'Gửi ngay'}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Inputs */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <span>🌐</span> Supabase Project URL
                </label>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://xyzabcdefg.supabase.co"
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 font-mono text-xs focus:border-emerald-600 focus:outline-none bg-slate-50 focus:bg-white"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Lấy tại Supabase Dashboard &gt; Project Settings &gt; API &gt; Project URL.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <span>🔑</span> Supabase Anon / Public Key
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                  >
                    {showKey ? 'Ẩn khóa' : 'Hiện khóa'}
                  </button>
                </div>
                <input
                  type={showKey ? 'text' : 'password'}
                  value={anonKey}
                  onChange={(e) => setAnonKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 font-mono text-xs focus:border-emerald-600 focus:outline-none bg-slate-50 focus:bg-white"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Khóa công khai anon (phải bắt đầu bằng <code className="text-emerald-700 font-mono">eyJ...</code>). Tuyệt đối không dùng service_role key!
                </p>
              </div>
            </div>

            {/* Test result message */}
            {testResult && (
              <div
                className={`p-4 rounded-2xl border-2 text-xs font-bold flex items-start gap-3 ${
                  testResult.success
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                    : 'bg-rose-50 border-rose-300 text-rose-900'
                }`}
              >
                {testResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
                <div>{testResult.message}</div>
              </div>
            )}

            {/* SQL Guide hint */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-5 text-xs space-y-3">
              <div className="flex items-center justify-between gap-2 border-b border-blue-200 pb-2.5">
                <div className="font-black text-blue-900 flex items-center gap-1.5 uppercase">
                  <span>📋</span>
                  <span>MÃ TẠO 4 BẢNG DỮ LIỆU SUPABASE (MIGRATION SQL)</span>
                </div>
                <button
                  type="button"
                  onClick={copySqlToClipboard}
                  className={`px-3 py-1.5 rounded-xl font-black text-xs uppercase flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                    copiedSql 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-blue-600 hover:bg-blue-500 text-white'
                  }`}
                >
                  {copiedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSql ? 'Đã sao chép SQL!' : 'Sao chép toàn bộ mã SQL'}</span>
                </button>
              </div>

              <div className="space-y-1.5 text-blue-950 font-bold leading-relaxed">
                <div><strong>📌 Cách chạy trên Supabase (Chỉ mất 30 giây):</strong></div>
                <ol className="list-decimal list-inside space-y-1 text-slate-700 pl-1">
                  <li>Mở <strong>Supabase Dashboard</strong> &gt; Chọn dự án của Thầy/Cô.</li>
                  <li>Nhấp vào biểu tượng <strong>SQL Editor</strong> ở cột menu bên trái (biểu tượng <code className="bg-blue-100 px-1 py-0.5 rounded font-mono text-blue-900">&gt;_</code>).</li>
                  <li>Bấm nút <strong>"New query"</strong>.</li>
                  <li>Bấm nút xanh <strong>"Sao chép toàn bộ mã SQL"</strong> ở trên, dán vào khung rồi bấm nút <strong>"Run"</strong>.</li>
                </ol>
                <p className="text-[11px] text-emerald-800 font-bold bg-emerald-100/60 p-2 rounded-lg border border-emerald-200 mt-2">
                  ✨ Khi thấy <em>"Success. No rows returned"</em>, 4 bảng <code className="font-mono">classes</code>, <code className="font-mono">students</code>, <code className="font-mono">attempts</code>, <code className="font-mono">error_events</code> đã được tạo thành công!
                </p>
              </div>

              <div className="pt-1 flex items-center justify-between">
                <a
                  href="https://supabase.com/dashboard"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-blue-700 font-black hover:underline"
                >
                  <span>Mở Supabase Dashboard trực tiếp</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* Footer actions */}
          <div className="bg-slate-50 p-6 border-t-2 border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleClear}
                className="text-xs font-black text-slate-500 hover:text-rose-600 px-3 py-2 rounded-xl transition-colors cursor-pointer"
              >
                Xóa cấu hình
              </button>
            </div>

            <div className="flex items-center gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={handleTestConnection}
                disabled={isTesting || !url.trim() || !anonKey.trim()}
                className="text-xs font-black uppercase px-4 py-2.5 rounded-xl border-2 border-slate-300 cursor-pointer flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                <span>{isTesting ? 'Đang kiểm tra...' : 'Kiểm tra kết nối'}</span>
              </Button>

              <Button
                type="button"
                onClick={handleSave}
                disabled={!url.trim() || !anonKey.trim()}
                className="text-xs font-black uppercase px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white border-2 border-b-4 border-emerald-900 cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Lưu & Kích hoạt</span>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
