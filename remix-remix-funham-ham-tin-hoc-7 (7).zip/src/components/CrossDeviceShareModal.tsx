import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  QrCode, 
  Smartphone, 
  Monitor, 
  Copy, 
  Check, 
  X, 
  ExternalLink, 
  Share2, 
  Sparkles,
  Wifi,
  ShieldCheck,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { Button } from './ui/Button';
import { getSupabaseConfig } from '../services/supabaseClient';

interface CrossDeviceShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  defaultRole?: 'student' | 'teacher';
}

export function CrossDeviceShareModal({ 
  isOpen, 
  onClose,
  title = 'KẾT NỐI HỌC TẬP TRÊN ĐIỆN THOẠI & MÁY TÍNH',
  defaultRole = 'student'
}: CrossDeviceShareModalProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'qr' | 'guide'>('qr');
  const [currentUrl, setCurrentUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentUrl(window.location.origin);
    }
  }, []);

  if (!isOpen) return null;

  const appUrl = currentUrl || 'https://resonant-hotteok-4208b8.netlify.app';
  const config = getSupabaseConfig();
  
  let studentUrl = `${appUrl}/login`;
  if (config.url && config.anonKey) {
    studentUrl += `?supabase_url=${encodeURIComponent(config.url)}&supabase_key=${encodeURIComponent(config.anonKey)}`;
  }
  const teacherUrl = `${appUrl}/teacher`;

  const targetUrl = defaultRole === 'teacher' ? teacherUrl : studentUrl;

  // Generate QR Code URL via high-reliability SVG/PNG API
  const qrCodeImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(targetUrl)}&margin=10&color=1e1b4b`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(targetUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (e) {
      // Fallback copy
      const el = document.createElement('textarea');
      el.value = targetUrl;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-white rounded-3xl border-4 border-slate-300 shadow-2xl max-w-xl w-full overflow-hidden text-slate-900 my-8"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center text-2xl shadow-inner">
                <Smartphone className="w-6 h-6 text-yellow-300" />
              </div>
              <div>
                <h3 className="text-xl md:text-2xl font-black uppercase tracking-wider text-yellow-300 drop-shadow">
                  {title}
                </h3>
                <p className="text-xs text-blue-100 font-bold">
                  Học tập mượt mà trên 2 Máy tính & Điện thoại di động
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Sub-Tabs */}
          <div className="flex border-b-2 border-slate-100 bg-slate-50 p-2 gap-2">
            <button
              onClick={() => setActiveTab('qr')}
              className={`flex-1 py-2.5 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'qr'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>Mã QR Quét Vào Học</span>
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`flex-1 py-2.5 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'guide'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span>Hướng Dẫn 2 Máy Tính & ĐT</span>
            </button>
          </div>

          {/* Body */}
          <div className="p-6 md:p-8 space-y-6 max-h-[75vh] overflow-y-auto">
            {activeTab === 'qr' ? (
              <div className="space-y-6 text-center">
                {/* QR Code Container */}
                <div className="inline-block p-4 bg-white rounded-3xl border-4 border-dashed border-indigo-300 shadow-xl relative group">
                  <img
                    src={qrCodeImageUrl}
                    alt="Mã QR mở ứng dụng trên điện thoại"
                    className="w-52 h-52 md:w-60 md:h-60 mx-auto rounded-2xl block object-contain"
                  />
                  <div className="mt-3 flex items-center justify-center gap-1.5 text-indigo-900 font-black text-xs uppercase">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Dùng Camera Điện Thoại Quét Mã</span>
                  </div>
                </div>

                {/* Direct Link box */}
                <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-2 text-left">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black uppercase text-slate-500">
                      Đường dẫn truy cập trực tiếp:
                    </span>
                    <span className="text-[11px] font-black text-emerald-700 flex items-center gap-1">
                      <Wifi className="w-3 h-3" /> Sẵn sàng hoạt động
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={targetUrl}
                      className="flex-1 bg-white border-2 border-slate-300 px-3.5 py-2.5 rounded-xl font-mono text-xs font-bold text-slate-800 select-all"
                    />
                    <Button
                      onClick={handleCopyLink}
                      className={`px-4 py-2.5 rounded-xl font-black text-xs uppercase flex items-center gap-1.5 cursor-pointer shadow-sm transition-transform active:scale-95 ${
                        copied ? 'bg-emerald-600 text-white' : 'bg-blue-600 hover:bg-blue-500 text-white'
                      }`}
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      <span>{copied ? 'Đã sao chép' : 'Sao chép'}</span>
                    </Button>
                  </div>
                </div>

                {/* Quick device pills */}
                <div className="grid grid-cols-2 gap-3 text-left">
                  <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-1">
                    <div className="font-black text-xs uppercase text-blue-900 flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-blue-600" />
                      <span>Trên Điện thoại</span>
                    </div>
                    <p className="text-[11px] text-blue-800 font-medium leading-relaxed">
                      Làm bài trắc nghiệm, luyện tập thích ứng, chẩn đoán lỗi bằng AI mọi lúc mọi nơi.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-purple-50/70 border border-purple-200 space-y-1">
                    <div className="font-black text-xs uppercase text-purple-900 flex items-center gap-1.5">
                      <Monitor className="w-4 h-4 text-purple-600" />
                      <span>Trên Máy tính</span>
                    </div>
                    <p className="text-[11px] text-purple-800 font-medium leading-relaxed">
                      Thao tác bảng tính đầy đủ, xem bảng điều khiển giáo viên và xuất báo cáo CSV/PDF.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-5 text-xs text-slate-700 leading-relaxed">
                {/* Scenario 1: Học sinh dùng Điện thoại, Giáo viên xem trên Máy tính */}
                <div className="p-4 rounded-2xl bg-indigo-50 border-2 border-indigo-200 space-y-2">
                  <div className="font-black text-sm uppercase text-indigo-950 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white text-xs flex items-center justify-center">1</span>
                    <span>Tình huống 1: Học sinh làm trên Điện thoại ➔ Giáo viên xem trên Máy tính</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-indigo-900 font-medium pl-1">
                    <li>Học sinh dùng điện thoại mở camera quét mã QR, nhập Mã học sinh (ví dụ: <strong className="font-mono">HS01</strong>) và Lớp (ví dụ: <strong className="font-mono">7A1</strong>).</li>
                    <li>Học sinh làm Khảo sát đầu vào hoặc luyện tập thích ứng rồi bấm <strong>"Nộp bài"</strong>.</li>
                    <li>Giáo viên ngồi ở máy tính mở <strong className="font-mono">/teacher</strong>, bấm <strong>"🔄 Làm mới dữ liệu"</strong> là thấy điểm số và lỗi công thức hiển thị ngay.</li>
                  </ul>
                </div>

                {/* Scenario 2: Hai học sinh làm trên 2 Máy tính khác nhau */}
                <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-200 space-y-2">
                  <div className="font-black text-sm uppercase text-emerald-950 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white text-xs flex items-center justify-center">2</span>
                    <span>Tình huống 2: Hai học sinh làm trên 2 Máy tính đồng thời</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-emerald-900 font-medium pl-1">
                    <li><strong>Máy tính A:</strong> Học sinh 1 đăng nhập mã <strong className="font-mono">HS01</strong> - làm bài tập.</li>
                    <li><strong>Máy tính B:</strong> Học sinh 2 đăng nhập mã <strong className="font-mono">HS02</strong> - làm bài tập.</li>
                    <li>Dữ liệu 2 em được tách biệt hoàn toàn theo mã định danh, không bị ghi đè lên nhau.</li>
                  </ul>
                </div>

                {/* Scenario 3: Mẹo cài đặt App vào màn hình chính điện thoại */}
                <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 space-y-2">
                  <div className="font-black text-sm uppercase text-amber-950 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-amber-600 text-white text-xs flex items-center justify-center">3</span>
                    <span>Cài đặt ứng dụng vào màn hình chính (Dùng như App thực thụ)</span>
                  </div>
                  <div className="space-y-1.5 text-amber-900 font-medium">
                    <p><strong>• Trên iPhone (Safari):</strong> Bấm biểu tượng <span className="bg-white px-1.5 py-0.5 rounded border border-amber-300 font-bold">Chia sẻ (Share)</span> ở dưới đáy màn hình ➔ Chọn <strong>"Thêm vào Màn hình chính" (Add to Home Screen)</strong>.</p>
                    <p><strong>• Trên Android (Chrome):</strong> Bấm biểu tượng <span className="bg-white px-1.5 py-0.5 rounded border border-amber-300 font-bold">3 chấm (Menu)</span> ở góc trên bên phải ➔ Chọn <strong>"Cài đặt ứng dụng"</strong> hoặc <strong>"Thêm vào màn hình chính"</strong>.</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="bg-slate-50 p-5 border-t-2 border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-black text-slate-600">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Dữ liệu đồng bộ máy chủ bảo mật</span>
            </div>
            <Button
              onClick={onClose}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-black uppercase cursor-pointer"
            >
              Đóng
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
