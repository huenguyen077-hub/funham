import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  Users, 
  FileQuestion, 
  Target, 
  LogOut, 
  QrCode, 
  Smartphone, 
  Menu, 
  X,
  Sparkles 
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { cn } from '../../utils';
import { CrossDeviceShareModal } from '../CrossDeviceShareModal';

export function TeacherLayout() {
  const { logout, user } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();

  const [showShareModal, setShowShareModal] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navItems = [
    { path: '/teacher', emoji: '🏠', label: 'TỔNG QUAN', color: 'from-blue-500 to-indigo-600', border: 'border-blue-800', shadow: 'shadow-blue-500/40' },
    { path: '/teacher/evidence', emoji: '📊', label: 'DỮ LIỆU ĐÁNH GIÁ', color: 'from-rose-500 to-red-600', border: 'border-rose-800', shadow: 'shadow-rose-500/40' },
    { path: '/teacher/students', emoji: '👥', label: 'HỌC SINH', color: 'from-purple-500 to-pink-600', border: 'border-purple-800', shadow: 'shadow-purple-500/40' },
    { path: '/teacher/questions', emoji: '❓', label: 'NGÂN HÀNG CH', color: 'from-amber-500 to-orange-600', border: 'border-amber-800', shadow: 'shadow-amber-500/40' },
    { path: '/teacher/assignments', emoji: '🎯', label: 'GIAO BÀI', color: 'from-emerald-500 to-teal-600', border: 'border-emerald-800', shadow: 'shadow-emerald-500/40' },
  ];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden flex-col md:flex-row">
      {/* Mobile Top Header */}
      <header className="md:hidden bg-white border-b-2 border-slate-200 px-4 py-3 flex items-center justify-between shadow-sm z-30 shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setMobileDrawerOpen(true)}
            className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 cursor-pointer transition-colors"
            aria-label="Mở menu danh mục"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-black text-purple-600 tracking-wider">FUNHÀM</h1>
            <div className="text-[10px] font-bold text-slate-500 -mt-1">
              Cổng Giáo Viên • {user?.name || 'Thầy/Cô'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowShareModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-700 font-black text-[11px] uppercase flex items-center gap-1 cursor-pointer shadow-sm active:scale-95 transition-transform"
          >
            <QrCode className="w-3.5 h-3.5 text-purple-600" />
            <span>Chiếu QR</span>
          </button>

          <button
            onClick={handleLogout}
            className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center cursor-pointer active:scale-95"
            title="Đăng xuất"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Sidebar for Desktop */}
      <aside className="w-80 flex-col bg-white border-r-4 border-slate-300 shadow-2xl hidden md:flex shrink-0">
        <div className="p-6 text-center border-b-2 border-slate-100 bg-gradient-to-b from-purple-50/50 to-white">
          <h1 
            className="text-4xl font-black tracking-wider uppercase cursor-pointer"
            onClick={() => navigate('/teacher')}
            style={{
              color: '#9333ea',
              textShadow: '3px 3px 0px #7e22ce, 6px 6px 15px rgba(147,51,234,0.3)'
            }}
          >
            FUNHÀM
          </h1>
          <p className="text-xs font-black text-slate-500 uppercase tracking-widest mt-1.5">
            Cổng Giáo Viên
          </p>

          {/* Project QR to Classroom Screen */}
          <button
            onClick={() => setShowShareModal(true)}
            className="mt-3 w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 text-white text-xs font-black uppercase flex items-center justify-center gap-2 cursor-pointer shadow-md hover:opacity-95 transition-all"
          >
            <QrCode className="w-4 h-4 text-yellow-300" />
            <span>📱 Chiếu Mã QR Cho Cả Lớp Quét</span>
          </button>
        </div>
        
        <nav className="flex-1 p-5 space-y-3.5 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={cn(
                  "w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl font-black uppercase text-sm tracking-wider transition-all duration-200 border-3 border-b-6 active:border-b-2 active:translate-y-1 shadow-md cursor-pointer",
                  isActive 
                    ? cn("bg-gradient-to-r text-white scale-102 ring-4 ring-offset-1 ring-purple-400/40", item.color, item.border, item.shadow)
                    : "bg-white text-slate-800 border-slate-300 hover:bg-slate-50 hover:border-purple-400"
                )}
                style={{
                  textShadow: isActive ? '0 2px 4px rgba(0,0,0,0.4)' : '0 1px 2px rgba(0,0,0,0.1)'
                }}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-md border-2 border-white shrink-0",
                  isActive ? "bg-white/25 text-white" : "bg-gradient-to-tr from-slate-100 to-slate-200 text-slate-900"
                )}>
                  {item.emoji}
                </div>
                <span className="text-sm font-black tracking-wider text-left flex-1">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-5 border-t-3 border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3 px-3.5 py-3 bg-gradient-to-r from-purple-100 via-pink-50 to-purple-100 rounded-2xl mb-3 border-2 border-b-4 border-purple-400 shadow-sm">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-inner border border-white shrink-0">
              👩‍🏫
            </div>
            <div className="flex-1 min-w-0">
              <div 
                className="text-sm font-black uppercase tracking-wide text-slate-900 truncate"
              >
                {user?.name || 'Giáo viên'}
              </div>
              <div className="text-[11px] font-black text-purple-700 uppercase tracking-widest flex items-center gap-1">
                <span>⭐ Quản Trị Viên</span>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 py-3 text-xs font-black uppercase tracking-wider text-red-700 bg-white border-2 border-red-300 border-b-4 hover:bg-red-50 rounded-xl transition-all shadow-sm active:translate-y-0.5 cursor-pointer"
          >
            <LogOut className="w-4 h-4 stroke-[3]" />
            Đăng xuất
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          className="p-4 sm:p-6 md:p-10 max-w-7xl mx-auto pb-28 md:pb-10"
        >
          <Outlet />
        </motion.div>
      </main>

      {/* Bottom Nav for Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t-2 border-slate-200 pb-safe z-40 shadow-xl">
        <div className="flex justify-around p-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={cn(
                  "flex flex-col items-center py-2 px-2 rounded-xl min-w-[56px] transition-all cursor-pointer",
                  isActive ? "text-purple-700 font-black bg-purple-50" : "text-slate-500 font-bold"
                )}
              >
                <span className="text-xl mb-1">{item.emoji}</span>
                <span className="text-[9px] uppercase tracking-tight">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Drawer (Slide-over) */}
      <AnimatePresence>
        {mobileDrawerOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex justify-start">
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col overflow-hidden"
            >
              {/* Drawer Header */}
              <div className="bg-gradient-to-r from-purple-700 to-indigo-800 p-5 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shadow-inner">
                    👩‍🏫
                  </div>
                  <div>
                    <h3 className="font-black text-base uppercase text-yellow-300">
                      {user?.name || 'Giáo viên'}
                    </h3>
                    <p className="text-xs text-purple-100 font-bold">
                      Bảng Điều Khiển & Thu Minh Chứng
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Navigation List */}
              <div className="flex-1 p-4 space-y-2 overflow-y-auto">
                <div className="text-[11px] font-black uppercase text-slate-400 px-2 tracking-wider">
                  QUẢN LÝ GIÁO VIÊN
                </div>
                {navItems.map((item) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <button
                      key={item.path}
                      onClick={() => {
                        navigate(item.path);
                        setMobileDrawerOpen(false);
                      }}
                      className={cn(
                        "w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all text-left",
                        isActive
                          ? "bg-purple-600 text-white shadow-md"
                          : "bg-slate-50 text-slate-800 hover:bg-slate-100"
                      )}
                    >
                      <span className="text-xl">{item.emoji}</span>
                      <span className="flex-1">{item.label}</span>
                    </button>
                  );
                })}

                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <button
                    onClick={() => {
                      setMobileDrawerOpen(false);
                      setShowShareModal(true);
                    }}
                    className="w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase text-purple-700 bg-purple-50 border border-purple-200"
                  >
                    <QrCode className="w-4 h-4 text-purple-600" />
                    <span>Chiếu Mã QR Cho Cả Lớp Quét</span>
                  </button>
                </div>
              </div>

              {/* Drawer Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-200">
                <button
                  onClick={handleLogout}
                  className="w-full py-3 bg-white border-2 border-red-300 text-red-700 font-black text-xs uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-sm active:bg-red-50"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Đăng xuất</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cross-Device Share / QR Modal */}
      <CrossDeviceShareModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title="CHIẾU MÃ QR CHO HỌC SINH QUÉT VÀO HỌC"
        defaultRole="student"
      />
    </div>
  );
}
