import { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  BookOpen, 
  Gamepad2, 
  Trophy, 
  Award, 
  LogOut, 
  Layers, 
  Smartphone, 
  Menu, 
  X, 
  QrCode, 
  Sparkles,
  Flame,
  CheckCircle2
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { useDataStore } from '../../store/dataStore';
import { Student } from '../../types';
import { cn } from '../../utils';
import { CrossDeviceShareModal } from '../CrossDeviceShareModal';

export function StudentLayout() {
  const { logout, user } = useAuthStore();
  const { registerStudent } = useEvidenceStore();
  const { students, addStudent } = useDataStore();
  const navigate = useNavigate();
  const location = useLocation();

  const [showShareModal, setShowShareModal] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  // Close drawer when location changes
  useEffect(() => {
    setMobileDrawerOpen(false);
  }, [location.pathname]);

  // Tự động cập nhật bảng vinh danh và danh sách quản lý khi học sinh đăng nhập hệ thống
  useEffect(() => {
    if (user && user.role === 'student') {
      const student = user as Student;
      registerStudent({
        studentId: student.id || 'hs_baonam',
        studentName: student.name,
        className: student.className || '7A1',
        xp: student.xp,
      });

      const exists = students.some(s => s.name.toLowerCase() === student.name.toLowerCase());
      if (!exists) {
        addStudent({
          id: student.id || `hs_${Date.now()}`,
          name: student.name,
          role: 'student',
          className: student.className || '7A1',
          xp: student.xp || 950,
          level: student.level || 6,
          score: student.score || 92,
          streak: student.streak || 5,
          badges: student.badges || ['first_step', 'speed_master', 'perfect_score'],
          completedAssignments: student.completedAssignments || ['asm1'],
          createdAt: new Date().toISOString(),
        });
      }
    }
  }, [user, registerStudent, students, addStudent]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navItems = [
    { path: '/student', icon: Home, label: 'BẢNG ĐIỀU KHIỂN', shortLabel: 'Trang chủ', emoji: '🏠', color: 'from-blue-500 to-cyan-500', border: 'border-blue-700', shadow: 'shadow-blue-500/30' },
    { path: '/student/doctor', icon: BookOpen, label: 'TRỢ LÝ AI KHÁM LỖI', shortLabel: 'Khám lỗi AI', emoji: '🩺', color: 'from-teal-500 to-emerald-600', border: 'border-teal-700', shadow: 'shadow-teal-500/30' },
    { path: '/student/assessment', icon: BookOpen, label: 'KHẢO SÁT & ĐÁNH GIÁ', shortLabel: 'Khảo sát', emoji: '📝', color: 'from-indigo-500 to-blue-600', border: 'border-indigo-700', shadow: 'shadow-indigo-500/30' },
    { path: '/student/adaptive', icon: Layers, label: 'LUYỆN BỔ TRỢ AI', shortLabel: 'Bổ trợ AI', emoji: '🎯', color: 'from-cyan-500 to-teal-600', border: 'border-cyan-700', shadow: 'shadow-cyan-500/30' },
    { path: '/student/lesson', icon: BookOpen, label: 'HỌC BÀI', shortLabel: 'Học bài', emoji: '📖', color: 'from-emerald-500 to-teal-600', border: 'border-emerald-700', shadow: 'shadow-emerald-500/30' },
    { path: '/student/tiers', icon: Layers, label: 'LEO THÁP 4 TẦNG', shortLabel: 'Leo tháp', emoji: '🏰', color: 'from-rose-500 to-amber-600', border: 'border-rose-700', shadow: 'shadow-rose-500/30' },
    { path: '/student/game', icon: Gamepad2, label: 'TRÒ CHƠI', shortLabel: 'Trò chơi', emoji: '🎮', color: 'from-purple-500 to-pink-600', border: 'border-purple-700', shadow: 'shadow-purple-500/30' },
    { path: '/student/leaderboard', icon: Trophy, label: 'XẾP HẠNG', shortLabel: 'Xếp hạng', emoji: '🏆', color: 'from-amber-500 to-orange-600', border: 'border-amber-700', shadow: 'shadow-amber-500/30' },
  ];

  const student = (user as Student) || { name: 'Học sinh', className: '7A1', xp: 950 };
  const isFemale = /(thị|hoa|lan|linh|hương|mai|thảo|ngọc|diệu|nhi|quỳnh|vy|yến|hằng|thủy|trang|phương|nhung|hà|châu|giang|hiền|ân|an)/i.test(user?.name || '');
  const genderEmoji = isFemale ? '👧🌸' : '👦⚽';

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden flex-col md:flex-row">
      {/* Mobile Top Header (Shown on phone/tablet) */}
      <header className="md:hidden bg-white border-b-2 border-slate-200 px-4 py-3 flex items-center justify-between shadow-sm z-30 shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setMobileDrawerOpen(true)}
            className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 cursor-pointer transition-colors"
            aria-label="Mở menu danh mục"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-black text-blue-600 tracking-wider">FUNHÀM</h1>
            <div className="text-[10px] font-bold text-slate-500 -mt-1">
              {student.name} • {student.className || '7A1'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowShareModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 font-black text-[11px] uppercase flex items-center gap-1 cursor-pointer shadow-sm active:scale-95 transition-transform"
          >
            <QrCode className="w-3.5 h-3.5 text-indigo-600" />
            <span>Mã QR</span>
          </button>

          <button
            onClick={handleLogout}
            className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center cursor-pointer active:scale-95"
            title="Đăng xuất"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex w-80 flex-col bg-white border-r-4 border-slate-300 shadow-2xl shrink-0">
        <div className="p-6 text-center border-b-2 border-slate-100 bg-gradient-to-b from-blue-50/50 to-white">
          <h1 
            className="text-4xl font-black tracking-wider uppercase cursor-pointer"
            onClick={() => navigate('/student')}
            style={{
              color: '#2563eb',
              textShadow: '3px 3px 0px #1d4ed8, 6px 6px 15px rgba(37,99,235,0.3)'
            }}
          >
            FUNHÀM
          </h1>
          <p className="text-xs font-black text-slate-500 uppercase tracking-widest mt-1.5">
            Học Hàm Bảng Tính Lớp 7
          </p>

          {/* Cross-device connect button for desktop */}
          <button
            onClick={() => setShowShareModal(true)}
            className="mt-3 w-full py-2 px-3 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border border-blue-200 text-blue-800 text-xs font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all"
          >
            <Smartphone className="w-4 h-4 text-blue-600" />
            <span>Học Trên Điện Thoại (QR)</span>
          </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-2.5 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={cn(
                  "w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl font-black uppercase text-sm tracking-wider transition-all duration-200 border-3 border-b-6 active:border-b-2 active:translate-y-1 shadow-md cursor-pointer",
                  isActive 
                    ? cn("bg-gradient-to-r text-white scale-102 ring-4 ring-offset-1 ring-blue-400/40", item.color, item.border, item.shadow)
                    : "bg-white text-slate-800 border-slate-300 hover:bg-slate-50 hover:border-blue-400"
                )}
                style={{
                  textShadow: isActive ? '0 2px 4px rgba(0,0,0,0.4)' : '0 1px 2px rgba(0,0,0,0.1)'
                }}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-md border-2 border-white shrink-0",
                  isActive ? "bg-white/25 text-white" : "bg-gradient-to-tr from-slate-100 to-slate-200 text-slate-900"
                )}>
                  {item.emoji}
                </div>
                <span className="text-sm font-black tracking-wider text-left flex-1">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-5 border-t-3 border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3 px-3.5 py-3 bg-gradient-to-r from-blue-100 via-cyan-50 to-blue-100 rounded-2xl mb-3 border-2 border-b-4 border-blue-400 shadow-sm">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-400 to-pink-500 flex items-center justify-center text-white font-black text-xl shadow-inner border border-white shrink-0">
              {genderEmoji}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-black uppercase tracking-wide text-slate-900 truncate">
                {user?.name}
              </div>
              <div className="text-[11px] font-black text-blue-700 uppercase tracking-widest flex items-center gap-1">
                <span>⭐ Lớp {student.className || '7A1'}</span>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 py-3 text-xs font-black uppercase tracking-wider text-red-700 bg-white border-2 border-red-300 border-b-4 hover:bg-red-50 rounded-xl transition-all shadow-sm active:translate-y-0.5 cursor-pointer"
          >
            <LogOut className="w-4 h-4 stroke-[3]" />
            Đăng xuất
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          className="p-4 sm:p-6 md:p-10 max-w-7xl mx-auto pb-28 md:pb-10"
        >
          <Outlet />
        </motion.div>
      </main>

      {/* Streamlined Bottom Nav for Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t-2 border-slate-200 z-40 shadow-xl pb-safe">
        <div className="grid grid-cols-5 p-1 gap-1">
          {[
            { path: '/student', emoji: '🏠', label: 'Trang chủ' },
            { path: '/student/doctor', emoji: '🩺', label: 'Khám lỗi' },
            { path: '/student/assessment', emoji: '📝', label: 'Khảo sát' },
            { path: '/student/game', emoji: '🎮', label: 'Trò chơi' },
          ].map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={cn(
                  "flex flex-col items-center py-2 px-1 rounded-xl transition-all cursor-pointer",
                  isActive ? "bg-blue-50 text-blue-700 font-black scale-102" : "text-slate-500 font-bold"
                )}
              >
                <span className="text-xl leading-none mb-1">{item.emoji}</span>
                <span className="text-[10px] tracking-tight">{item.label}</span>
              </button>
            );
          })}

          {/* "Thêm..." button to open mobile drawer */}
          <button
            onClick={() => setMobileDrawerOpen(true)}
            className="flex flex-col items-center py-2 px-1 rounded-xl text-slate-600 font-black cursor-pointer hover:bg-slate-50"
          >
            <Menu className="w-5 h-5 mb-1 text-slate-700" />
            <span className="text-[10px]">Tất cả</span>
          </button>
        </div>
      </nav>

      {/* Mobile Drawer (Slide-over) */}
      <AnimatePresence>
        {mobileDrawerOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex justify-start">
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col overflow-hidden"
            >
              {/* Drawer Header */}
              <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-5 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shadow-inner">
                    {genderEmoji}
                  </div>
                  <div>
                    <h3 className="font-black text-base uppercase text-yellow-300">
                      {student.name}
                    </h3>
                    <p className="text-xs text-blue-100 font-bold">
                      Lớp {student.className || '7A1'} • Cổng Học Sinh
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Navigation List */}
              <div className="flex-1 p-4 space-y-2 overflow-y-auto">
                <div className="text-[11px] font-black uppercase text-slate-400 px-2 tracking-wider">
                  DANH MỤC HỌC TẬP
                </div>
                {navItems.map((item) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <button
                      key={item.path}
                      onClick={() => {
                        navigate(item.path);
                        setMobileDrawerOpen(false);
                      }}
                      className={cn(
                        "w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all text-left",
                        isActive
                          ? "bg-blue-600 text-white shadow-md"
                          : "bg-slate-50 text-slate-800 hover:bg-slate-100"
                      )}
                    >
                      <span className="text-xl">{item.emoji}</span>
                      <span className="flex-1">{item.label}</span>
                    </button>
                  );
                })}

                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <button
                    onClick={() => {
                      setMobileDrawerOpen(false);
                      setShowShareModal(true);
                    }}
                    className="w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-black text-xs uppercase text-indigo-700 bg-indigo-50 border border-indigo-200"
                  >
                    <Smartphone className="w-4 h-4 text-indigo-600" />
                    <span>Mã QR Chia Sẻ Vào ĐT / Máy Khác</span>
                  </button>
                </div>
              </div>

              {/* Drawer Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-200">
                <button
                  onClick={handleLogout}
                  className="w-full py-3 bg-white border-2 border-red-300 text-red-700 font-black text-xs uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-sm active:bg-red-50"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Đăng xuất</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cross-Device Share / QR Modal */}
      <CrossDeviceShareModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title="KẾT NỐI HỌC TRÊN ĐIỆN THOẠI & MÁY TÍNH"
        defaultRole="student"
      />
    </div>
  );
}
