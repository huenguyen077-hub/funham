import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, RotateCcw } from 'lucide-react';

const SCENES_MAP: Record<string, any> = {
  sum: {
    id: 'sum',
    duration: 5000,
    text: "Hàm SUM giúp tính tổng các giá trị. Ví dụ: =SUM(10, 20, 30)",
    functionName: "SUM",
    formula: "=SUM(10, 20, 30)",
    result: "60",
    animation: "calculate"
  },
  average: {
    id: 'average',
    duration: 5000,
    text: "Hàm AVERAGE tính trung bình cộng. Ví dụ: =AVERAGE(10, 20, 30)",
    functionName: "AVERAGE",
    formula: "=AVERAGE(10, 20, 30)",
    result: "20",
    animation: "calculate"
  },
  max: {
    id: 'max',
    duration: 5000,
    text: "Hàm MAX tìm giá trị lớn nhất. Số lớn nhất là 30.",
    functionName: "MAX",
    formula: "=MAX(10, 20, 30)",
    result: "30",
    animation: "highlight-max"
  },
  min: {
    id: 'min',
    duration: 5000,
    text: "Hàm MIN tìm giá trị nhỏ nhất. Số nhỏ nhất là 10.",
    functionName: "MIN",
    formula: "=MIN(10, 20, 30)",
    result: "10",
    animation: "highlight-min"
  },
  count: {
    id: 'count',
    duration: 5000,
    text: "Hàm COUNT đếm số ô chứa dữ liệu số. Ở đây có 3 ô.",
    functionName: "COUNT",
    formula: "=COUNT(A1:A3)",
    result: "3",
    animation: "count"
  }
};

export function FunctionVideo({ functionId }: { functionId: string }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showResult, setShowResult] = useState(false);
  
  const progressInterval = useRef<NodeJS.Timeout | null>(null);
  const animationTimer = useRef<NodeJS.Timeout | null>(null);

  const scene = SCENES_MAP[functionId.toLowerCase()] || SCENES_MAP['sum'];

  const startTimers = () => {
    const sceneStartTime = Date.now() - (progress / 100) * scene.duration;
    
    progressInterval.current = setInterval(() => {
      const elapsed = Date.now() - sceneStartTime;
      const newProgress = (elapsed / scene.duration) * 100;
      
      if (newProgress >= 100) {
        setIsPlaying(false);
        setProgress(100);
        setShowResult(true);
        if (progressInterval.current) clearInterval(progressInterval.current);
      } else {
        setProgress(newProgress);
      }
    }, 50);

    if (!showResult) {
      const timeRemaining = scene.duration - (progress / 100) * scene.duration;
      if (timeRemaining > 2000) {
         animationTimer.current = setTimeout(() => {
           setShowResult(true);
         }, timeRemaining - 2000);
      } else {
         setShowResult(true);
      }
    }
  };

  const clearTimers = () => {
    if (progressInterval.current) clearInterval(progressInterval.current);
    if (animationTimer.current) clearTimeout(animationTimer.current);
  };

  useEffect(() => {
    if (isPlaying) {
      startTimers();
    } else {
      clearTimers();
    }
    return clearTimers;
  }, [isPlaying]);

  const togglePlay = () => {
    if (progress >= 100) {
      setProgress(0);
      setShowResult(false);
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="relative w-full h-full bg-slate-900 flex flex-col items-center justify-center overflow-hidden">
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:2rem_2rem] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_70%,transparent_100%)] opacity-20" />

      {!isPlaying && progress === 0 && (
        <div className="absolute inset-0 z-30 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center">
           <button
             onClick={togglePlay}
             className="w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-500 flex items-center justify-center text-white transition-transform hover:scale-110"
           >
             <Play className="w-8 h-8 ml-1" />
           </button>
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={scene.id}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative z-10 w-full max-w-lg p-6"
        >
          <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 shadow-2xl">
            <div className="text-center mb-6">
              <span className="inline-block px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 font-bold text-xs tracking-widest mb-2">
                MÔ PHỎNG HÀM {scene.functionName}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-6">
              {[10, 20, 30].map((num, i) => {
                let isHighlight = false;
                if (showResult) {
                  if (scene.animation === 'highlight-max' && num === 30) isHighlight = true;
                  if (scene.animation === 'highlight-min' && num === 10) isHighlight = true;
                  if (scene.animation === 'count' || scene.animation === 'calculate') isHighlight = true;
                }

                return (
                  <motion.div
                    key={i}
                    animate={isHighlight ? { 
                      scale: 1.05, 
                      backgroundColor: 'rgba(59, 130, 246, 0.2)',
                      borderColor: 'rgba(59, 130, 246, 0.5)'
                    } : { 
                      scale: 1,
                      backgroundColor: 'rgba(30, 41, 59, 1)',
                      borderColor: 'rgba(51, 65, 85, 1)'
                    }}
                    className="aspect-square flex items-center justify-center text-2xl font-black text-white rounded-xl border-2 transition-colors"
                  >
                    {num}
                  </motion.div>
                );
              })}
            </div>

            <div className="h-16 bg-slate-900 rounded-xl border border-slate-700 flex items-center px-4 relative overflow-hidden">
              <div className="font-mono text-sm text-slate-300 mr-3">fx</div>
              <div className="font-mono text-sm md:text-base text-green-400 flex-1">{scene.formula}</div>
              
              <AnimatePresence>
                {showResult && (
                  <motion.div
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="absolute right-4 flex items-center bg-slate-900 pl-2"
                  >
                    <span className="text-slate-500 mr-2">=</span>
                    <span className="text-xl font-black text-white">{scene.result}</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Subtitles Overlay */}
      <div className="absolute bottom-12 left-4 right-4 text-center z-20 pointer-events-none">
        <motion.div
          key={scene.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-block bg-black/60 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10 max-w-sm mx-auto"
        >
          <p className="text-white text-sm font-medium shadow-black drop-shadow-md">
            {scene.text}
          </p>
        </motion.div>
      </div>

      {/* Mini Controls */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-800">
        <motion.div 
          className="h-full bg-blue-500"
          style={{ width: `${progress}%` }}
        />
      </div>
      <button
        onClick={togglePlay}
        className="absolute bottom-3 left-4 text-slate-400 hover:text-white z-30"
      >
        {isPlaying ? <Pause className="w-5 h-5" /> : (progress >= 100 ? <RotateCcw className="w-5 h-5" /> : <Play className="w-5 h-5" />)}
      </button>
    </div>
  );
}
