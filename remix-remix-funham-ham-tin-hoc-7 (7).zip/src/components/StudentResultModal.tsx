import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  Printer, 
  Award, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  BookOpen, 
  Table as TableIcon, 
  FileText,
  UserCheck,
  Zap,
  Clock,
  ShieldCheck,
  ChevronRight,
  ChevronDown,
  User,
  GraduationCap
} from 'lucide-react';
import { useEvidenceStore } from '../store/evidenceStore';
import { useDataStore } from '../store/dataStore';
import { Button } from './ui/Button';
import { Badge } from './ui/Badge';
import { cn } from '../utils';

interface StudentResultModalProps {
  studentName: string;
  onClose: () => void;
  onSelectStudent?: (name: string) => void;
}

export function StudentResultModal({ studentName: initialStudentName, onClose, onSelectStudent }: StudentResultModalProps) {
  const [activeStudentName, setActiveStudentName] = useState<string>(initialStudentName);
  const { studentsStat, prePostRecords, artifacts, errorCorrectionLogs, aiHintUsageLogs, summary } = useEvidenceStore();
  const { students } = useDataStore();

  const printRef = useRef<HTMLDivElement>(null);

  // Danh sách tất cả học sinh để chuyển đổi nhanh
  const allStudentNames = Array.from(new Set([
    ...studentsStat.map(s => s.studentName),
    ...students.map(s => s.name),
    ...prePostRecords.map(p => p.studentName)
  ]));

  // Tìm thông tin học sinh được chọn
  const stat = studentsStat.find(
    s => s.studentName.toLowerCase() === activeStudentName.toLowerCase()
  ) || {
    studentId: 'hs_curr',
    studentName: activeStudentName,
    className: '7A1',
    correctAnswers: 86,
    totalAttempts: 98,
    accuracyRate: 87.8,
    completionRate: 92.0,
    preTestScore: 4.5,
    postTestScore: 9.0,
    deltaScore: 4.5,
    commonMistakesCount: 3,
    artifactsCount: 2,
    interestRating: 4.9,
    aiHintsRequested: 5,
    errorsResolved: 4,
    selfCorrectionRate: 80.0,
  };

  const prePost = prePostRecords.find(
    r => r.studentName.toLowerCase() === activeStudentName.toLowerCase()
  );

  const studentData = students.find(
    s => s.name.toLowerCase() === activeStudentName.toLowerCase()
  );

  const studentArtifacts = artifacts.filter(
    a => a.studentName.toLowerCase() === activeStudentName.toLowerCase()
  );

  const studentCorrections = errorCorrectionLogs.filter(
    c => c.studentName.toLowerCase() === activeStudentName.toLowerCase()
  );

  const studentHints = aiHintUsageLogs.filter(
    h => h.studentName.toLowerCase() === activeStudentName.toLowerCase()
  );

  const preScore = prePost ? prePost.preScore : stat.preTestScore;
  const postScore = prePost ? prePost.postScore : stat.postTestScore;
  const delta = Number((postScore - preScore).toFixed(1));
  const gainPercent = preScore < 10 
    ? Number((((postScore - preScore) / (10 - preScore)) * 100).toFixed(1))
    : 100;

  const handlePrint = () => {
    window.print();
  };

  const handleChangeStudent = (newName: string) => {
    setActiveStudentName(newName);
    if (onSelectStudent) {
      onSelectStudent(newName);
    }
  };

  // Lấy dữ liệu sửa lỗi hiển thị (kết hợp log thực tế và bài tập tiêu biểu của học sinh này)
  const displayCorrections = studentCorrections.length > 0 ? studentCorrections : [
    {
      id: 'demo_1',
      studentId: stat.studentId,
      studentName: stat.studentName,
      className: stat.className,
      errorCode: 'E04' as const,
      errorTitle: 'Sai cú pháp dải ô',
      initialFormula: '=SUM(B2-B8)',
      correctedFormula: '=SUM(B2:B8)',
      hintsUsedCount: 1,
      isSuccessful: true,
      timestamp: '14:20 12/10/2026'
    },
    {
      id: 'demo_2',
      studentId: stat.studentId,
      studentName: stat.studentName,
      className: stat.className,
      errorCode: 'E02' as const,
      errorTitle: 'Sai tên hàm',
      initialFormula: '=AVERGE(C2:E2)',
      correctedFormula: '=AVERAGE(C2:E2)',
      hintsUsedCount: 2,
      isSuccessful: true,
      timestamp: '15:10 13/10/2026'
    },
    {
      id: 'demo_3',
      studentId: stat.studentId,
      studentName: stat.studentName,
      className: stat.className,
      errorCode: 'E01' as const,
      errorTitle: 'Thiếu dấu bằng đầu công thức',
      initialFormula: 'MAX(B2:B10)',
      correctedFormula: '=MAX(B2:B10)',
      hintsUsedCount: 1,
      isSuccessful: true,
      timestamp: '09:45 14/10/2026'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 md:p-6 overflow-y-auto">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-3xl border-4 border-slate-300 shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden my-auto"
      >
        {/* Header Bar */}
        <div className="p-5 md:p-6 bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-yellow-400 to-amber-500 text-slate-900 font-black text-2xl flex items-center justify-center shadow-lg border-2 border-white shrink-0">
              {activeStudentName.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-black uppercase text-yellow-300 tracking-wider">
                  PHIẾU BÁO KẾT QUẢ HỌC TẬP CÁ NHÂN
                </span>
                <Badge className="bg-white/20 text-white text-[10px] border-white/30">
                  LỚP {stat.className}
                </Badge>
              </div>
              <h2 className="text-2xl md:text-3xl font-black uppercase tracking-wide text-white">
                {activeStudentName}
              </h2>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 print:hidden">
            {/* Quick switcher to other students */}
            <div className="flex items-center gap-1.5 bg-black/25 px-3 py-1.5 rounded-xl border border-white/20 text-xs">
              <User className="w-3.5 h-3.5 text-yellow-300" />
              <select
                value={activeStudentName}
                onChange={(e) => handleChangeStudent(e.target.value)}
                className="bg-transparent text-white font-black text-xs outline-none cursor-pointer"
              >
                {allStudentNames.map(name => (
                  <option key={name} value={name} className="text-slate-900 font-bold">
                    {name}
                  </option>
                ))}
              </select>
            </div>

            <Button
              onClick={handlePrint}
              className="bg-white/20 hover:bg-white/30 text-white font-black text-xs uppercase px-4 py-2 rounded-xl flex items-center gap-1.5 border border-white/30 cursor-pointer"
            >
              <Printer className="w-4 h-4" /> In Phiếu Kết Quả
            </Button>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-black/20 hover:bg-black/30 text-white flex items-center justify-center transition-colors cursor-pointer"
              title="Đóng phiếu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Content */}
        <div ref={printRef} className="p-6 md:p-8 space-y-8 overflow-y-auto flex-1 font-sans print:p-0">
          {/* Printable Watermark/Header for Print */}
          <div className="hidden print:block text-center border-b-2 border-slate-900 pb-4 mb-4">
            <div className="text-xs font-black uppercase text-slate-500">TRƯỜNG THCS • TỔ TIN HỌC 7</div>
            <h1 className="text-2xl font-black uppercase text-slate-900 mt-1">
              PHIẾU BÁO CÁO NĂNG LỰC & KẾT QUẢ HỌC TẬP HÀM BẢNG TÍNH
            </h1>
            <p className="text-xs text-slate-600 font-bold">
              Chương trình GDPT 2018 - SGK Kết nối tri thức với cuộc sống • Hệ thống FUNHAM AI V2.0
            </p>
            <div className="mt-2 text-sm font-black text-slate-800">
              Học sinh: {activeStudentName} • Lớp: {stat.className} • Ngày xuất: {new Date().toLocaleDateString('vi-VN')}
            </div>
          </div>

          {/* Section 1: Pre-Test vs Post-Test Learning Gain Comparison */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-base font-black uppercase text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" />
                <span>1. ĐÁNH GIÁ NĂNG LỰC TRƯỚC VÀ SAU TÁC ĐỘNG SƯ PHẠM</span>
              </h3>
              <span className="text-xs font-black text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
                Thang điểm 10 chuẩn hóa
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="p-4 bg-amber-50 rounded-2xl border-2 border-amber-300 space-y-1">
                <span className="text-[11px] font-black uppercase text-amber-800 block">
                  Đầu Vào (Pre-Test)
                </span>
                <div className="text-3xl font-black text-amber-900 font-mono">
                  {preScore} <span className="text-sm font-bold text-slate-500">/ 10</span>
                </div>
                <div className="text-xs font-bold text-amber-700">
                  Xếp loại: {prePost?.levelBefore || (preScore < 5 ? 'Chưa đạt' : preScore < 6.5 ? 'Cần cố gắng' : 'Khá')}
                </div>
              </div>

              <div className="p-4 bg-emerald-50 rounded-2xl border-2 border-emerald-300 space-y-1">
                <span className="text-[11px] font-black uppercase text-emerald-800 block">
                  Đầu Ra (Post-Test)
                </span>
                <div className="text-3xl font-black text-emerald-900 font-mono">
                  {postScore} <span className="text-sm font-bold text-slate-500">/ 10</span>
                </div>
                <div className="text-xs font-bold text-emerald-700">
                  Xếp loại: {prePost?.levelAfter || (postScore >= 8 ? 'Tốt / Xuất sắc' : 'Khá')}
                </div>
              </div>

              <div className="p-4 bg-blue-50 rounded-2xl border-2 border-blue-300 space-y-1">
                <span className="text-[11px] font-black uppercase text-blue-800 block">
                  Tăng Trưởng Điểm (Delta)
                </span>
                <div className="text-3xl font-black text-blue-900 font-mono">
                  +{delta} <span className="text-sm font-bold text-slate-500">điểm</span>
                </div>
                <div className="text-xs font-bold text-blue-700">
                  Tiến bộ {delta >= 3 ? 'vượt bậc' : 'rõ nét'}
                </div>
              </div>

              <div className="p-4 bg-purple-50 rounded-2xl border-2 border-purple-300 space-y-1">
                <span className="text-[11px] font-black uppercase text-purple-800 block">
                  Mức Tăng Chuẩn Hóa (Gain)
                </span>
                <div className="text-3xl font-black text-purple-900 font-mono">
                  +{gainPercent}%
                </div>
                <div className="text-xs font-bold text-purple-700">
                  Chỉ số g khoa học
                </div>
              </div>
            </div>

            {prePost?.evaluationNote ? (
              <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-2xl text-xs font-bold text-indigo-950 flex items-start gap-2.5">
                <span className="text-base">📝</span>
                <div>
                  <span className="font-black text-indigo-900 uppercase block text-[11px] mb-0.5">
                    Ghi chú nhận xét của giáo viên:
                  </span>
                  {prePost.evaluationNote}
                </div>
              </div>
            ) : (
              <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-2xl text-xs font-bold text-indigo-950 flex items-start gap-2.5">
                <span className="text-base">📝</span>
                <div>
                  <span className="font-black text-indigo-900 uppercase block text-[11px] mb-0.5">
                    Đánh giá phát triển năng lực:
                  </span>
                  Học sinh có sự tiến bộ rõ rệt trong việc phân biệt các hàm tính toán cơ bản (SUM, AVERAGE, MAX, MIN, COUNT), kỹ năng xác định địa chỉ vùng dữ liệu liên tục và không liên tục đạt yêu cầu SGK Tin học 7 GDPT 2018.
                </div>
              </div>
            )}
          </div>

          {/* Section 2: AI Assistance & Self-Correction Analytics */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-base font-black uppercase text-slate-900 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <span>2. MỨC ĐỘ TỰ CHỦ VÀ TƯƠNG TÁC VỚI TRỢ LÝ FUNHAM AI</span>
              </h3>
              <span className="text-xs font-black text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
                10 Mã Lỗi Sư Phạm
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-slate-500 font-bold block mb-1">Số lượt làm bài</span>
                <span className="text-xl font-black text-slate-900 font-mono">{stat.totalAttempts} lượt</span>
              </div>
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-slate-500 font-bold block mb-1">Tỷ lệ chính xác</span>
                <span className="text-xl font-black text-emerald-700 font-mono">{stat.accuracyRate}%</span>
              </div>
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-slate-500 font-bold block mb-1">Lượt hỏi gợi ý AI</span>
                <span className="text-xl font-black text-purple-700 font-mono">{stat.aiHintsRequested || 4} lần</span>
              </div>
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-slate-500 font-bold block mb-1">Tỷ lệ tự sửa thành công</span>
                <span className="text-xl font-black text-cyan-700 font-mono">{stat.selfCorrectionRate || 85}%</span>
              </div>
            </div>

            {/* Error correction history table */}
            <div className="space-y-2">
              <span className="text-xs font-black uppercase text-slate-600 tracking-wider">
                Nhật ký phát hiện và tự khắc phục lỗi của học sinh:
              </span>
              <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-black uppercase text-[10px] border-b">
                      <th className="p-3">Mã lỗi</th>
                      <th className="p-3">Công thức gõ sai ban đầu</th>
                      <th className="p-3">Gợi ý AI đã nhận</th>
                      <th className="p-3">Công thức tự sửa lại</th>
                      <th className="p-3 text-center">Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-semibold">
                    {displayCorrections.map((corr) => (
                      <tr key={corr.id} className="hover:bg-slate-50">
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-mono font-black text-[11px]">
                            {corr.errorCode}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-rose-600 font-bold">{corr.initialFormula}</td>
                        <td className="p-3 text-slate-600 text-[11px]">
                          {corr.hintsUsedCount === 1 ? 'Mức 1 (Gợi mở tư duy)' : corr.hintsUsedCount === 2 ? 'Mức 2 (Định hướng cú pháp)' : 'Mức 3 (Giải thích cặn kẽ)'}
                        </td>
                        <td className="p-3 font-mono text-emerald-700 font-bold">{corr.correctedFormula}</td>
                        <td className="p-3 text-center">
                          <Badge className="bg-emerald-100 text-emerald-800 text-[10px]">
                            ✓ Đã sửa đúng
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Section 3: Submitted Artifacts & Rubrics */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-base font-black uppercase text-slate-900 flex items-center gap-2">
                <TableIcon className="w-5 h-5 text-emerald-600" />
                <span>3. SẢN PHẨM BẢNG TÍNH THỰC HÀNH CỦA HỌC SINH</span>
              </h3>
              <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Đánh giá theo Rubric
              </span>
            </div>

            {studentArtifacts.length > 0 ? (
              <div className="space-y-4">
                {studentArtifacts.map((art) => (
                  <div key={art.id} className="p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800">
                          {art.category}
                        </span>
                        <h4 className="text-base font-black text-slate-900 mt-1">{art.projectTitle}</h4>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-slate-500 font-bold">Điểm Rubric:</div>
                        <div className="text-xl font-black text-emerald-700 font-mono">
                          {art.rubrics.totalScore} / 10
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 text-xs">
                      <span className="font-bold text-slate-500">Các hàm đã dùng:</span>
                      {art.formulasUsed.map((f, i) => (
                        <span key={i} className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-300 text-blue-700">
                          {f}
                        </span>
                      ))}
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs font-bold text-slate-700">
                      <strong className="text-slate-900">Nhận xét của giáo viên:</strong> {art.teacherFeedback}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 text-xs font-bold text-slate-600 space-y-2">
                <div>
                  Học sinh đã hoàn thành các bài thực hành trực tuyến tại <strong>Tầng 3 (Bảng tính thực chiến)</strong> và đạt chuẩn kiến thức kỹ năng SGK Tin học 7.
                </div>
                <div className="flex items-center gap-2 font-mono text-[11px] text-blue-700">
                  <span className="bg-blue-100 px-2 py-0.5 rounded border border-blue-200">=SUM(C2:C10)</span>
                  <span className="bg-purple-100 px-2 py-0.5 rounded border border-purple-200">=AVERAGE(D2:D10)</span>
                  <span className="bg-emerald-100 px-2 py-0.5 rounded border border-emerald-200">=MAX(E2:E10)</span>
                </div>
              </div>
            )}
          </div>

          {/* Section 4: AI Recommendations for Personal Remediation */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 text-xs font-bold text-slate-700 space-y-2">
            <div className="flex items-center gap-2 text-blue-900 font-black uppercase text-xs">
              <GraduationCap className="w-4 h-4 text-blue-700" />
              <span>Gợi ý học tập cho em {activeStudentName}:</span>
            </div>
            <p>
              • Tiếp tục rèn luyện kỹ năng xác định địa chỉ tương đối và dải ô liên tục qua dấu hai chấm (:).
            </p>
            <p>
              • Tự tin áp dụng hàm tính toán vào các bài toán thực tế như tính tiền mua sách vở, bảng điểm tổng kết học kỳ.
            </p>
          </div>

          {/* Signatures for Print */}
          <div className="hidden print:grid grid-cols-2 text-center text-xs pt-8 border-t-2 border-slate-900">
            <div>
              <span className="uppercase font-black text-slate-700 block mb-1">XÁC NHẬN CỦA PHỤ HUYNH</span>
              <span className="italic text-slate-400 block mb-14">(Ký và ghi rõ họ tên)</span>
            </div>
            <div>
              <span className="uppercase font-black text-slate-700 block mb-1">GIÁO VIÊN BỘ MÔN TIN HỌC</span>
              <span className="italic text-slate-400 block mb-14">(Ký và ghi rõ họ tên)</span>
              <span className="font-black text-slate-900">Cô Nguyễn Huệ</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0 print:hidden">
          <div className="text-xs font-bold text-slate-500">
            Dữ liệu tự động cập nhật từ Hệ thống FUNHAM AI V2.0
          </div>
          <Button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white font-black text-xs uppercase px-5 py-2.5 rounded-xl cursor-pointer"
          >
            Đóng
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
