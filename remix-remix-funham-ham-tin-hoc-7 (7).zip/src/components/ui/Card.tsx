import React from 'react';
import { cn } from '../../utils';
import { motion, HTMLMotionProps } from 'framer-motion';

export const Card = React.forwardRef<HTMLDivElement, HTMLMotionProps<"div">>(
  ({ className, children, ...props }, ref) => (
    <motion.div
      ref={ref}
      className={cn(
        "rounded-3xl border-2 border-slate-100 bg-white p-6 shadow-xl shadow-slate-200/50",
        className
      )}
      {...props}
    >
      {children}
    </motion.div>
  )
);
Card.displayName = "Card";
