import React from 'react';
import { cn } from '../../utils';
import { motion, HTMLMotionProps } from 'framer-motion';

interface ButtonProps extends HTMLMotionProps<"button"> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', children, ...props }, ref) => {
    
    const baseStyles = "inline-flex items-center justify-center rounded-2xl font-bold transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none active:scale-95";
    
    const variants = {
      primary: "bg-blue-500 text-white hover:bg-blue-600 shadow-[0_4px_0_0_rgba(37,99,235,1)] hover:shadow-[0_2px_0_0_rgba(37,99,235,1)] hover:translate-y-[2px]",
      secondary: "bg-purple-500 text-white hover:bg-purple-600 shadow-[0_4px_0_0_rgba(147,51,234,1)] hover:shadow-[0_2px_0_0_rgba(147,51,234,1)] hover:translate-y-[2px]",
      outline: "border-2 border-slate-200 bg-white text-slate-700 hover:bg-slate-50 shadow-[0_4px_0_0_rgba(226,232,240,1)] hover:shadow-[0_2px_0_0_rgba(226,232,240,1)] hover:translate-y-[2px]",
      ghost: "bg-transparent text-slate-700 hover:bg-slate-100",
      danger: "bg-red-500 text-white hover:bg-red-600 shadow-[0_4px_0_0_rgba(220,38,38,1)] hover:shadow-[0_2px_0_0_rgba(220,38,38,1)] hover:translate-y-[2px]"
    };

    const sizes = {
      sm: "h-9 px-4 text-sm",
      md: "h-11 px-6 text-base",
      lg: "h-14 px-8 text-lg"
    };

    return (
      <motion.button
        ref={ref}
        whileTap={variant !== 'ghost' ? { y: 4, boxShadow: "0 0 0 0 rgba(0,0,0,0)" } : { scale: 0.95 }}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        {...props}
      >
        {children}
      </motion.button>
    );
  }
);

Button.displayName = "Button";
