import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { soundManager } from '../../utils/sound';
import { cn } from '../../utils';
import type { Question } from '../../types';

interface MatchingPair {
  id: string;
  left: string;
  right: string;
}

interface MatchingQuestionViewProps {
  key?: React.Key;
  question: Question;
  isAnswered: boolean;
  onComplete: (isCorrect: boolean, chosenAnswer: string) => void;
}

export function MatchingQuestionView({
  question,
  isAnswered,
  onComplete,
}: MatchingQuestionViewProps) {
  // Parse options into pairs
  const pairs: MatchingPair[] = useMemo(() => {
    return (question.options || []).map((opt: string, idx: number) => {
      // Split on first occurrence of ' - ' or '-' or ':'
      const parts = opt.split(/\s*[-–—:]\s*(.+)/);
      const left = parts[0]?.trim() || opt;
      const right = parts[1]?.trim() || parts[0]?.trim() || '';
      return {
        id: `pair-${idx}`,
        left,
        right,
      };
    });
  }, [question.id, question.options]);

  const [leftItems, setLeftItems] = useState<{ id: string; text: string }[]>([]);
  const [rightItems, setRightItems] = useState<{ id: string; text: string }[]>([]);
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [selectedRight, setSelectedRight] = useState<string | null>(null);
  const [matched, setMatched] = useState<string[]>([]);
  const [shakePair, setShakePair] = useState<boolean>(false);

  useEffect(() => {
    const lefts = pairs.map((p) => ({ id: p.id, text: p.left }));
    // Shuffle right column independently so items are randomized
    const rights = [...pairs.map((p) => ({ id: p.id, text: p.right }))].sort(
      () => Math.random() - 0.5
    );
    setLeftItems(lefts);
    setRightItems(rights);
    setSelectedLeft(null);
    setSelectedRight(null);
    setMatched([]);
    setShakePair(false);
  }, [pairs]);

  const evaluatePair = (leftId: string, rightId: string) => {
    if (leftId === rightId) {
      // Correct Match!
      soundManager.playCorrect();
      const updated = [...matched, leftId];
      setMatched(updated);
      setSelectedLeft(null);
      setSelectedRight(null);
      if (updated.length === pairs.length) {
        onComplete(true, pairs.map((p) => `${p.left}-${p.right}`).join(','));
      }
    } else {
      // Wrong Match!
      soundManager.playWrong();
      setShakePair(true);
      setTimeout(() => {
        setSelectedLeft(null);
        setSelectedRight(null);
        setShakePair(false);
      }, 500);
    }
  };

  const handleSelectLeft = (id: string) => {
    if (isAnswered || matched.includes(id)) return;
    setSelectedLeft(id);
    if (selectedRight) {
      evaluatePair(id, selectedRight);
    }
  };

  const handleSelectRight = (id: string) => {
    if (isAnswered || matched.includes(id)) return;
    setSelectedRight(id);
    if (selectedLeft) {
      evaluatePair(selectedLeft, id);
    }
  };

  return (
    <div className="space-y-6 w-full">
      {/* Visual Instruction Guide for How to Play */}
      <div className="bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-pink-500/20 border-2 border-amber-400/50 p-4 md:p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 text-white shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-2xl shrink-0 shadow-md">
            🧩
          </div>
          <div>
            <div className="font-black text-sm md:text-base text-yellow-300 uppercase tracking-wide flex items-center gap-2">
              <span>HƯỚNG DẪN CÁCH CHƠI GHÉP NỐI:</span>
            </div>
            <div className="text-xs md:text-sm text-slate-200 font-bold mt-0.5">
              1. Bấm chọn ô ở cột <strong className="text-cyan-300 uppercase">TRÁI (Hàm/Biểu thức)</strong> ➔ 
              2. Bấm chọn ô tương ứng ở cột <strong className="text-pink-300 uppercase">PHẢI (Kết quả)</strong>!
            </div>
          </div>
        </div>
        <div className="bg-slate-900/90 px-5 py-2.5 rounded-2xl border-2 border-slate-700 font-mono font-black text-sm text-yellow-300 shrink-0 shadow-inner">
          ✨ TIẾN ĐỘ: {matched.length} / {pairs.length} CẶP
        </div>
      </div>

      {/* Two columns for Matching */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        {/* Left Column */}
        <div className="space-y-3">
          <div className="text-xs font-black uppercase text-cyan-300 tracking-wider px-1 flex items-center gap-2">
            <span>🟦</span> CỘT A: CÔNG THỨC / HÀM SỐ
          </div>
          {leftItems.map((item) => {
            const isMatched = matched.includes(item.id);
            const isSelected = selectedLeft === item.id;
            const isWrong = isSelected && shakePair;

            return (
              <motion.button
                key={item.id}
                type="button"
                disabled={isMatched || isAnswered}
                onClick={() => handleSelectLeft(item.id)}
                animate={isWrong ? { x: [-8, 8, -8, 8, 0] } : {}}
                transition={{ duration: 0.35 }}
                className={cn(
                  "w-full p-4 md:p-5 rounded-2xl font-mono text-base md:text-xl font-black transition-all duration-200 flex items-center justify-between text-left relative overflow-hidden border-3 border-b-6 shadow-md",
                  isMatched
                    ? "bg-emerald-950/80 border-emerald-500 text-emerald-300 cursor-default opacity-85 shadow-none border-b-3"
                    : isWrong
                    ? "bg-red-900/90 border-red-500 text-white"
                    : isSelected
                    ? "bg-gradient-to-r from-amber-400 to-yellow-500 border-yellow-700 text-slate-950 scale-102 shadow-2xl ring-4 ring-yellow-400/50"
                    : "bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 border-indigo-950 text-white hover:scale-[1.01] active:scale-98 cursor-pointer"
                )}
              >
                <span>{item.text}</span>
                {isMatched ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500 text-slate-950 rounded-lg text-xs font-sans font-black uppercase shrink-0">
                    <Check className="w-3.5 h-3.5" /> Đúng
                  </span>
                ) : isSelected ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-950 text-yellow-300 rounded-lg text-xs font-sans font-black uppercase shrink-0 animate-pulse">
                    Đang chọn 👆
                  </span>
                ) : null}
              </motion.button>
            );
          })}
        </div>

        {/* Right Column */}
        <div className="space-y-3">
          <div className="text-xs font-black uppercase text-pink-300 tracking-wider px-1 flex items-center gap-2">
            <span>🟪</span> CỘT B: KẾT QUẢ / Ý NGHĨA
          </div>
          {rightItems.map((item) => {
            const isMatched = matched.includes(item.id);
            const isSelected = selectedRight === item.id;
            const isWrong = isSelected && shakePair;

            return (
              <motion.button
                key={item.id}
                type="button"
                disabled={isMatched || isAnswered}
                onClick={() => handleSelectRight(item.id)}
                animate={isWrong ? { x: [-8, 8, -8, 8, 0] } : {}}
                transition={{ duration: 0.35 }}
                className={cn(
                  "w-full p-4 md:p-5 rounded-2xl font-mono text-base md:text-xl font-black transition-all duration-200 flex items-center justify-between text-left relative overflow-hidden border-3 border-b-6 shadow-md",
                  isMatched
                    ? "bg-emerald-950/80 border-emerald-500 text-emerald-300 cursor-default opacity-85 shadow-none border-b-3"
                    : isWrong
                    ? "bg-red-900/90 border-red-500 text-white"
                    : isSelected
                    ? "bg-gradient-to-r from-amber-400 to-yellow-500 border-yellow-700 text-slate-950 scale-102 shadow-2xl ring-4 ring-yellow-400/50"
                    : "bg-gradient-to-r from-purple-600 to-pink-700 hover:from-purple-500 hover:to-pink-600 border-purple-950 text-white hover:scale-[1.01] active:scale-98 cursor-pointer"
                )}
              >
                <span>{item.text}</span>
                {isMatched ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500 text-slate-950 rounded-lg text-xs font-sans font-black uppercase shrink-0">
                    <Check className="w-3.5 h-3.5" /> Đúng
                  </span>
                ) : isSelected ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-950 text-yellow-300 rounded-lg text-xs font-sans font-black uppercase shrink-0 animate-pulse">
                    Đang chọn 👆
                  </span>
                ) : null}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
