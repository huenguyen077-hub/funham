import React, { useState, useEffect } from 'react';
import { Button } from '../ui/Button';
import type { Question } from '../../types';

interface OrderingQuestionViewProps {
  key?: React.Key;
  question: Question;
  isAnswered: boolean;
  onComplete: (isCorrect: boolean, chosenAnswer: string) => void;
}

export function OrderingQuestionView({
  question,
  isAnswered,
  onComplete,
}: OrderingQuestionViewProps) {
  const [items, setItems] = useState<string[]>([]);

  useEffect(() => {
    const original = [...(question.options || [])];
    const shuffled = [...original].sort(() => Math.random() - 0.5);
    setItems(shuffled);
  }, [question.id, question.options]);

  const moveUp = (index: number) => {
    if (index === 0 || isAnswered) return;
    const next = [...items];
    const temp = next[index - 1];
    next[index - 1] = next[index];
    next[index] = temp;
    setItems(next);
  };

  const moveDown = (index: number) => {
    if (index === items.length - 1 || isAnswered) return;
    const next = [...items];
    const temp = next[index + 1];
    next[index + 1] = next[index];
    next[index] = temp;
    setItems(next);
  };

  const handleConfirm = () => {
    const chosen = items.join(', ');
    const normalize = (s: string) => s.toLowerCase().replace(/[\s,]+/g, '');
    const isCorrect = normalize(chosen) === normalize(typeof question.answer === 'string' ? question.answer : question.answer.join(','));
    onComplete(isCorrect, chosen);
  };

  return (
    <div className="space-y-5 w-full">
      <div className="bg-amber-500/20 border-2 border-amber-400/50 p-4 rounded-2xl flex items-center gap-3 text-white shadow-md">
        <span className="text-2xl">💡</span>
        <div className="text-xs md:text-sm text-slate-200 font-bold">
          <strong className="text-yellow-300 uppercase">CÁCH CHƠI SẮP XẾP:</strong> Bấm nút <strong className="text-cyan-300">▲ LÊN</strong> hoặc <strong className="text-pink-300">▼ XUỐNG</strong> ở từng ô để đổi vị trí, sau đó bấm <strong className="text-emerald-300">"XÁC NHẬN THỨ TỰ"</strong>!
        </div>
      </div>

      <div className="space-y-3">
        {items.map((item, idx) => (
          <div
            key={idx}
            className="flex items-center justify-between p-4 md:p-5 bg-slate-800 border-3 border-indigo-950 rounded-2xl text-white gap-3 shadow-md"
          >
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-xl bg-indigo-600 text-white font-black text-sm flex items-center justify-center shrink-0 shadow">
                {idx + 1}
              </span>
              <span className="font-bold text-base md:text-lg">{item}</span>
            </div>
            {!isAnswered && (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => moveUp(idx)}
                  className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-30 disabled:cursor-not-allowed text-white font-black text-xs rounded-xl border-2 border-cyan-800 transition-all active:scale-95 cursor-pointer"
                >
                  ▲ Lên
                </button>
                <button
                  type="button"
                  disabled={idx === items.length - 1}
                  onClick={() => moveDown(idx)}
                  className="px-3 py-2 bg-pink-600 hover:bg-pink-500 disabled:opacity-30 disabled:cursor-not-allowed text-white font-black text-xs rounded-xl border-2 border-pink-800 transition-all active:scale-95 cursor-pointer"
                >
                  ▼ Xuống
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {!isAnswered && (
        <Button
          onClick={handleConfirm}
          className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black uppercase text-base rounded-2xl border-3 border-b-6 border-emerald-900 shadow-xl active:scale-98 transition-all"
        >
          ✅ XÁC NHẬN THỨ TỰ NÀY
        </Button>
      )}
    </div>
  );
}
