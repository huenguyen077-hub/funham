import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, XCircle, Sparkles, ChevronRight, RotateCcw, Trophy, Award, BookOpen, Layers } from 'lucide-react';
import { COGNITIVE_LEVELS, COGNITIVE_QUESTIONS } from '../data/cognitiveLevels';
import { CognitiveLevel, QuestionTopic } from '../types';
import { Button } from './ui/Button';
import { cn } from '../utils';
import confetti from 'canvas-confetti';
import { soundManager } from '../utils/sound';

interface CognitiveLevelsPracticeProps {
  initialLevel?: CognitiveLevel;
  filterTopic?: QuestionTopic;
  title?: string;
  subtitle?: string;
  isGameMode?: boolean;
}

export function CognitiveLevelsPractice({
  initialLevel = 1,
  filterTopic,
  title = "HỆ THỐNG CÂU HỎI 6 MỨC ĐỘ NHẬN THỨC",
  subtitle = "Rèn luyện từ mức nhận biết, cú pháp đến phát hiện lỗi và vận dụng thực tế",
  isGameMode = false
}: CognitiveLevelsPracticeProps) {
  const [activeLevel, setActiveLevel] = useState<CognitiveLevel>(initialLevel);
  const [selectedTopic, setSelectedTopic] = useState<string>(filterTopic || 'ALL');
  const [questionIndex, setQuestionIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);

  // Filter questions by active level and topic
  const currentQuestions = COGNITIVE_QUESTIONS.filter((q) => {
    const matchLevel = q.cognitiveLevel === activeLevel;
    const matchTopic = selectedTopic === 'ALL' || q.topic === selectedTopic;
    return matchLevel && matchTopic;
  });

  const activeLevelInfo = COGNITIVE_LEVELS.find((l) => l.level === activeLevel) || COGNITIVE_LEVELS[0];
  const currentQ = currentQuestions[questionIndex] || currentQuestions[0];

  const handleSelectOption = (opt: string) => {
    if (isAnswered || !currentQ) return;
    setSelectedOption(opt);
    setIsAnswered(true);

    const isCorrect = opt === currentQ.answer;
    if (isCorrect) {
      soundManager.playCorrect();
      setScore((prev) => prev + currentQ.points);
      setStreak((prev) => prev + 1);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
      if (!completedLevels.includes(activeLevel)) {
        setCompletedLevels((prev) => [...prev, activeLevel]);
      }
    } else {
      soundManager.playWrong();
      setStreak(0);
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    if (questionIndex < currentQuestions.length - 1) {
      setQuestionIndex((prev) => prev + 1);
    } else {
      // Loop or stay
      setQuestionIndex(0);
    }
  };

  const handleSwitchLevel = (lvl: CognitiveLevel) => {
    setActiveLevel(lvl);
    setQuestionIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
  };

  return (
    <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 border-4 border-b-8 border-indigo-950 shadow-2xl space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase tracking-widest mb-1.5 border border-yellow-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>CHUẨN NĂNG LỰC TIN HỌC 7</span>
          </div>
          <h3 className="text-xl md:text-3xl font-black uppercase tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-300 to-cyan-300">
            {title}
          </h3>
          <p className="text-slate-400 text-xs md:text-sm font-bold mt-1">
            {subtitle}
          </p>
        </div>

        {/* Score & Streak */}
        <div className="flex items-center gap-3 bg-slate-950 px-4 py-2.5 rounded-2xl border-2 border-slate-800">
          <div className="text-center px-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Điểm thưởng</span>
            <span className="font-mono text-lg font-black text-amber-400">+{score} XP</span>
          </div>
          <div className="w-[1px] h-8 bg-slate-800" />
          <div className="text-center px-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Chuỗi đúng</span>
            <span className="font-mono text-lg font-black text-emerald-400">🔥 {streak}</span>
          </div>
        </div>
      </div>

      {/* 6 Level Selector Bar */}
      <div>
        <div className="text-xs font-black uppercase text-slate-400 mb-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-cyan-400" /> Chọn mức độ nhận thức (1 - 6):
          </span>
          <span className="text-indigo-300 font-bold">
            Hoàn thành: {completedLevels.length}/6 mức
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {COGNITIVE_LEVELS.map((lvl) => {
            const isActive = activeLevel === lvl.level;
            const isDone = completedLevels.includes(lvl.level);
            return (
              <button
                key={lvl.level}
                onClick={() => handleSwitchLevel(lvl.level)}
                className={cn(
                  "p-3 rounded-2xl border-2 transition-all text-left flex flex-col justify-between relative group cursor-pointer",
                  isActive
                    ? `bg-gradient-to-br ${lvl.color} text-white border-white scale-[1.03] shadow-lg shadow-cyan-500/20 ring-2 ring-cyan-400`
                    : "bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-600 hover:bg-slate-800/60"
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-lg">{lvl.icon}</span>
                  {isDone && (
                    <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded-full font-black border border-emerald-500/40">
                      ✓ Đạt
                    </span>
                  )}
                </div>
                <div>
                  <div className="font-black text-xs uppercase leading-tight line-clamp-1">
                    Mức {lvl.level}
                  </div>
                  <div className={cn("text-[11px] font-bold line-clamp-1 mt-0.5", isActive ? "text-white" : "text-slate-400")}>
                    {lvl.name}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Level Description Card */}
      <div className={cn("p-4 rounded-2xl border-2 flex items-center gap-3.5", activeLevelInfo.bgDark, activeLevelInfo.border)}>
        <span className="text-3xl p-2 bg-slate-900 rounded-xl border border-slate-700 shrink-0">
          {activeLevelInfo.icon}
        </span>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-black text-sm uppercase tracking-wider text-white">
              {activeLevelInfo.badge}: {activeLevelInfo.name}
            </span>
          </div>
          <p className="text-xs text-slate-300 font-bold mt-0.5">
            {activeLevelInfo.shortDesc}
          </p>
        </div>
      </div>

      {/* Topic Filter Chips */}
      {!filterTopic && (
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-xs font-black uppercase text-slate-400 mr-1">Lọc hàm:</span>
          {['ALL', 'SUM', 'AVERAGE', 'MIN', 'MAX', 'COUNT'].map((t) => (
            <button
              key={t}
              onClick={() => {
                setSelectedTopic(t);
                setQuestionIndex(0);
                setSelectedOption(null);
                setIsAnswered(false);
              }}
              className={cn(
                "px-3 py-1 rounded-xl text-xs font-black uppercase transition-all cursor-pointer",
                selectedTopic === t
                  ? "bg-cyan-500 text-slate-950 font-black shadow-md scale-105"
                  : "bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
              )}
            >
              {t === 'ALL' ? 'Tất cả hàm' : t}
            </button>
          ))}
        </div>
      )}

      {/* Interactive Question Card */}
      {currentQ ? (
        <div className="bg-slate-950 p-6 md:p-8 rounded-3xl border-3 border-indigo-900/60 shadow-inner space-y-6">
          {/* Question Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-indigo-600/30 text-indigo-300 rounded-full text-xs font-black border border-indigo-500/40">
                Câu {questionIndex + 1}/{currentQuestions.length}
              </span>
              <span className="px-2.5 py-0.5 bg-slate-800 text-slate-300 rounded-full text-xs font-black uppercase">
                Hàm: {currentQ.topic}
              </span>
            </div>
            <span className="font-mono text-xs font-black text-yellow-400">
              +{currentQ.points} Điểm
            </span>
          </div>

          {/* Question Content */}
          <div className="space-y-3">
            <h4 className="text-base md:text-lg font-bold text-white leading-relaxed">
              {currentQ.content}
            </h4>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {currentQ.options?.map((opt, idx) => {
              const isSelected = selectedOption === opt;
              const isCorrectAnswer = opt === currentQ.answer;

              let btnStyle = "bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-600 hover:bg-slate-850";
              if (isAnswered) {
                if (isCorrectAnswer) {
                  btnStyle = "bg-emerald-950 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500";
                } else if (isSelected) {
                  btnStyle = "bg-rose-950 border-rose-500 text-rose-200 ring-2 ring-rose-500";
                } else {
                  btnStyle = "bg-slate-900/50 border-slate-800 text-slate-500 opacity-60";
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(opt)}
                  disabled={isAnswered}
                  className={cn(
                    "p-4 rounded-2xl border-2 transition-all font-bold text-sm text-left flex items-center justify-between gap-3 cursor-pointer",
                    btnStyle
                  )}
                >
                  <span className="flex-1 font-mono">{opt}</span>
                  {isAnswered && (
                    <span>
                      {isCorrectAnswer && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                      {isSelected && !isCorrectAnswer && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Feedback & Explanation */}
          <AnimatePresence>
            {isAnswered && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={cn(
                  "p-5 rounded-2xl border-2 space-y-3",
                  selectedOption === currentQ.answer
                    ? "bg-emerald-950/80 border-emerald-500/80 text-emerald-200"
                    : "bg-rose-950/80 border-rose-500/80 text-rose-200"
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="font-black text-sm uppercase flex items-center gap-2">
                    {selectedOption === currentQ.answer ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        <span>Chính xác! (+{currentQ.points} XP)</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5 text-rose-400" />
                        <span>Chưa chính xác! Đáp án đúng là: {currentQ.answer}</span>
                      </>
                    )}
                  </div>
                  <Button
                    onClick={handleNext}
                    className="bg-white hover:bg-slate-100 text-slate-950 font-black text-xs uppercase px-4 py-2 rounded-xl"
                  >
                    {questionIndex < currentQuestions.length - 1 ? 'Câu tiếp theo →' : 'Làm lại loạt này 🔄'}
                  </Button>
                </div>

                <div className="text-xs text-slate-200 font-bold border-t border-white/10 pt-2 leading-relaxed">
                  💡 <span className="font-black">Giải thích chuyên sâu:</span> {currentQ.explanation}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center p-8 bg-slate-950 rounded-3xl border-2 border-slate-800">
          <p className="text-slate-400 text-sm font-bold">Không tìm thấy câu hỏi phù hợp cho bộ lọc này.</p>
          <Button
            onClick={() => setSelectedTopic('ALL')}
            className="mt-3 bg-cyan-500 text-slate-950 font-black text-xs uppercase"
          >
            Hiện tất cả câu hỏi
          </Button>
        </div>
      )}
    </div>
  );
}
