import React from 'react';
import { motion } from 'framer-motion';
import { Award, Lock } from 'lucide-react';
import { cn } from '../utils';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  unlocked: boolean;
}

const achievements: Achievement[] = [
  { id: '1', title: 'Học tập chăm chỉ', description: 'Hoàn thành 5 bài tập đầu tiên', icon: <Award className="w-6 h-6" />, unlocked: true },
  { id: '2', title: 'Giải bài xuất sắc', description: 'Đạt điểm 10 trong một bài kiểm tra', icon: <Award className="w-6 h-6" />, unlocked: false },
  { id: '3', title: 'Chuyên gia AI', description: 'Sử dụng gợi ý AI hiệu quả', icon: <Award className="w-6 h-6" />, unlocked: false },
  { id: '4', title: 'Người giải cứu', description: 'Tự sửa lỗi thành công 10 lần', icon: <Award className="w-6 h-6" />, unlocked: true },
];

export function Achievements() {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
        <Award className="w-6 h-6 text-yellow-500" />
        Thành tựu của bạn
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {achievements.map((achievement) => (
          <motion.div
            key={achievement.id}
            whileHover={{ scale: 1.05 }}
            className={cn(
              "p-4 rounded-2xl border-2 space-y-2 transition-colors",
              achievement.unlocked 
                ? "bg-yellow-50 border-yellow-200 text-yellow-900" 
                : "bg-slate-100 border-slate-200 text-slate-400"
            )}
          >
            <div className={cn("p-2 rounded-full w-fit", achievement.unlocked ? "bg-yellow-200" : "bg-slate-200")}>
              {achievement.unlocked ? achievement.icon : <Lock className="w-6 h-6" />}
            </div>
            <h3 className="font-bold text-sm">{achievement.title}</h3>
            <p className="text-xs">{achievement.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
