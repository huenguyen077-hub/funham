import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  ArrowRight, 
  AlertTriangle, 
  Check, 
  X, 
  Table as TableIcon, 
  BookOpen, 
  Lightbulb, 
  Layers, 
  RotateCcw,
  Trophy
} from 'lucide-react';
import { 
  TIER_1_QUESTIONS, 
  TIER_2_QUESTIONS, 
  TIER_3_QUESTIONS, 
  TIER_4_QUESTIONS,
  Tier1Question,
  Tier2Question,
  Tier3Question,
  Tier4BugQuestion
} from '../data/fourTiersData';
import { Button } from './ui/Button';
import { cn } from '../utils';
import confetti from 'canvas-confetti';
import { soundManager } from '../utils/sound';
import { useEvidenceStore } from '../store/evidenceStore';
import { useAuthStore } from '../store/authStore';
import { Link } from 'react-router-dom';

interface FourTiersLearningProps {
  initialTier?: 1 | 2 | 3 | 4;
}

export function FourTiersLearning({ initialTier = 1 }: FourTiersLearningProps) {
  const [activeTier, setActiveTier] = useState<1 | 2 | 3 | 4>(initialTier);

  // States for Tier 1
  const [t1Index, setT1Index] = useState(0);
  const [t1Selected, setT1Selected] = useState<string | null>(null);
  const [t1Answered, setT1Answered] = useState(false);

  // States for Tier 2
  const [t2Index, setT2Index] = useState(0);
  const [t2Selected, setT2Selected] = useState<string | null>(null);
  const [t2Answered, setT2Answered] = useState(false);

  // States for Tier 3
  const [t3Index, setT3Index] = useState(0);
  const [t3FormulaInput, setT3FormulaInput] = useState<string>('');
  const [t3SelectedOption, setT3SelectedOption] = useState<string | null>(null);
  const [t3Answered, setT3Answered] = useState(false);
  const [t3IsCorrect, setT3IsCorrect] = useState<boolean | null>(null);

  // States for Tier 4 (Phát hiện & Sửa lỗi 2 bước sư phạm)
  const [t4Index, setT4Index] = useState(0);
  const [t4Judgement, setT4Judgement] = useState<boolean | null>(null); // true = ĐÚNG, false = SAI
  const [t4JudgeSubmitted, setT4JudgeSubmitted] = useState(false);
  const [t4FixSelected, setT4FixSelected] = useState<string | null>(null);
  const [t4FixSubmitted, setT4FixSubmitted] = useState(false);

  // Score & Progress
  const [totalXp, setTotalXp] = useState(0);
  const [completedTiers, setCompletedTiers] = useState<number[]>([]);

  const { user } = useAuthStore();
  const { recordAttempt } = useEvidenceStore();

  const triggerSuccess = (xp: number, tierNum: number) => {
    soundManager.playCorrect();
    setTotalXp((prev) => prev + xp);
    confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 } });
    if (!completedTiers.includes(tierNum)) {
      setCompletedTiers((prev) => [...prev, tierNum]);
    }
  };

  // Tier 1 Handler
  const currentT1: Tier1Question = TIER_1_QUESTIONS[t1Index];
  const handleT1Select = (opt: string) => {
    if (t1Answered) return;
    setT1Selected(opt);
    setT1Answered(true);
    const isCorrect = opt === currentT1.correctAnswer;
    recordAttempt({
      studentId: user?.id || 'hs_01',
      studentName: user?.name || 'Nguyễn Văn An',
      className: '7A1',
      isCorrect,
      topic: 'T1_NHAN_BIET'
    });
    if (isCorrect) {
      triggerSuccess(15, 1);
    } else {
      soundManager.playWrong();
    }
  };

  // Tier 2 Handler
  const currentT2: Tier2Question = TIER_2_QUESTIONS[t2Index];
  const handleT2Select = (opt: string) => {
    if (t2Answered) return;
    setT2Selected(opt);
    setT2Answered(true);
    const isCorrect = opt === currentT2.correctAnswer;
    recordAttempt({
      studentId: user?.id || 'hs_01',
      studentName: user?.name || 'Nguyễn Văn An',
      className: '7A1',
      isCorrect,
      topic: 'T2_HIEU',
      mistakePattern: !isCorrect ? opt : undefined
    });
    if (isCorrect) {
      triggerSuccess(20, 2);
    } else {
      soundManager.playWrong();
    }
  };

  // Tier 3 Handler
  const currentT3: Tier3Question = TIER_3_QUESTIONS[t3Index];
  const handleT3Select = (opt: string) => {
    if (t3Answered) return;
    setT3SelectedOption(opt);
    setT3FormulaInput(opt);
    setT3Answered(true);
    const isOk = currentT3.acceptedFormulas.includes(opt.trim().replace(/\s+/g, '')) || 
                 currentT3.acceptedFormulas.includes(opt.trim());
    setT3IsCorrect(isOk);
    recordAttempt({
      studentId: user?.id || 'hs_01',
      studentName: user?.name || 'Nguyễn Văn An',
      className: '7A1',
      isCorrect: isOk,
      topic: 'T3_VAN_DUNG',
      mistakePattern: !isOk ? opt : undefined
    });
    if (isOk) {
      triggerSuccess(25, 3);
    } else {
      soundManager.playWrong();
    }
  };

  // Tier 4 Handler
  const currentT4: Tier4BugQuestion = TIER_4_QUESTIONS[t4Index];
  const handleT4Judge = (verdict: boolean) => {
    if (t4JudgeSubmitted) return;
    setT4Judgement(verdict);
    setT4JudgeSubmitted(true);
    // Correct judgement: the formula in currentT4 is indeed buggy (isCorrect: false)
    if (verdict === currentT4.isCorrect) {
      soundManager.playCorrect();
    } else {
      soundManager.playWrong();
    }
  };

  const handleT4FixSelect = (opt: string) => {
    if (t4FixSubmitted) return;
    setT4FixSelected(opt);
    setT4FixSubmitted(true);
    const isCorrect = opt === currentT4.correctFormula;
    recordAttempt({
      studentId: user?.id || 'hs_01',
      studentName: user?.name || 'Nguyễn Văn An',
      className: '7A1',
      isCorrect,
      topic: 'T4_SUA_LOI',
      mistakePattern: currentT4.buggyFormula
    });
    if (isCorrect) {
      triggerSuccess(30, 4);
    } else {
      soundManager.playWrong();
    }
  };

  const resetTier4 = () => {
    setT4Judgement(null);
    setT4JudgeSubmitted(false);
    setT4FixSelected(null);
    setT4FixSubmitted(false);
  };

  return (
    <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 border-4 border-b-8 border-indigo-950 shadow-2xl space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-amber-400/20 to-orange-400/20 text-amber-300 rounded-full text-xs font-black uppercase tracking-widest mb-1.5 border border-amber-400/30">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>KHUNG ĐÁNH GIÁ NĂNG LỰC TIN HỌC 7</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black uppercase tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-300 to-cyan-300">
            4 CẤP ĐỘ NĂNG LỰC HÀM BẢNG TÍNH
          </h2>
          <p className="text-slate-300 text-xs md:text-sm font-bold mt-1">
            Từ Nhận biết ➔ Hiểu cú pháp ➔ Vận dụng bảng tính thực tế ➔ Phát hiện & sửa lỗi
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Link
            to="/student/portfolio"
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-black uppercase transition-colors"
          >
            <span>📊 Xem Minh Chứng Của Em</span>
          </Link>

          <div className="flex items-center gap-3 bg-slate-950 px-4 py-2 rounded-2xl border-2 border-slate-800">
            <div className="text-center px-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Điểm thưởng</span>
              <span className="font-mono text-lg font-black text-amber-400">+{totalXp} XP</span>
            </div>
            <div className="w-[1px] h-8 bg-slate-800" />
            <div className="text-center px-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Đã hoàn thành</span>
              <span className="font-mono text-lg font-black text-cyan-400">{completedTiers.length}/4 Cấp</span>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Evidence Gathering Notice */}
      <div className="bg-slate-950/80 border border-indigo-500/30 px-4 py-2 rounded-2xl flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-bold">
            FUNHAM đang tự động ghi nhận minh chứng: <strong className="text-emerald-300">Số câu đúng</strong> • <strong className="text-blue-300">Số lần làm</strong> • <strong className="text-rose-300">Khắc phục lỗi sai</strong>.
          </span>
        </div>
        <Link to="/student/portfolio" className="text-cyan-300 font-black hover:underline hidden sm:inline">
          Hồ sơ minh chứng ➔
        </Link>
      </div>

      {/* 4 Tiers Navigation Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            tier: 1 as const,
            title: 'CẤP 1: NHẬN BIẾT',
            desc: 'Chức năng các hàm (SUM, AVERAGE...)',
            icon: '🔍',
            color: 'from-blue-600 to-cyan-600',
            activeBorder: 'border-cyan-400'
          },
          {
            tier: 2 as const,
            title: 'CẤP 2: HIỂU CÚ PHÁP',
            desc: 'Hiểu cú pháp: =SUM(B2:B8)',
            icon: '💡',
            color: 'from-indigo-600 to-purple-600',
            activeBorder: 'border-purple-400'
          },
          {
            tier: 3 as const,
            title: 'CẤP 3: VẬN DỤNG',
            desc: 'Bảng điểm thực tế (Toán, Văn, Tin)',
            icon: '📊',
            color: 'from-emerald-600 to-teal-600',
            activeBorder: 'border-emerald-400'
          },
          {
            tier: 4 as const,
            title: 'CẤP 4: SỬA LỖI',
            desc: 'Phát hiện lỗi =SUM(B2-B8) & sửa đúng',
            icon: '🕵️‍♂️',
            color: 'from-rose-600 to-red-600',
            activeBorder: 'border-rose-400'
          },
        ].map((item) => {
          const isActive = activeTier === item.tier;
          const isDone = completedTiers.includes(item.tier);
          return (
            <button
              key={item.tier}
              onClick={() => setActiveTier(item.tier)}
              className={cn(
                "p-3.5 md:p-4 rounded-2xl border-2 transition-all text-left flex flex-col justify-between cursor-pointer relative group",
                isActive
                  ? `bg-gradient-to-br ${item.color} text-white border-white scale-[1.02] shadow-xl shadow-cyan-500/20 ring-4 ring-cyan-400/40`
                  : "bg-slate-950/90 border-slate-800 text-slate-300 hover:border-slate-600 hover:bg-slate-800/60"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">{item.icon}</span>
                {isDone && (
                  <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full font-black border border-emerald-500/40 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Đạt
                  </span>
                )}
              </div>
              <div>
                <div className="font-black text-xs md:text-sm uppercase tracking-wider leading-tight">
                  {item.title}
                </div>
                <div className={cn("text-[11px] font-bold mt-1 line-clamp-1", isActive ? "text-white/90" : "text-slate-400")}>
                  {item.desc}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* ===================== TẦNG 1: NHẬN BIẾT ===================== */}
      {activeTier === 1 && (
        <div className="bg-slate-950 p-6 md:p-8 rounded-3xl border-3 border-blue-900/60 shadow-inner space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black flex items-center justify-center text-sm">
                1
              </span>
              <div>
                <h3 className="font-black text-base text-blue-300 uppercase">
                  TẦNG 1: NHẬN BIẾT TÊN VÀ CHỨC NĂNG HÀM
                </h3>
                <span className="text-xs text-slate-400 font-bold">
                  Câu hỏi {t1Index + 1}/{TIER_1_QUESTIONS.length}
                </span>
              </div>
            </div>
            <div className="flex gap-2">
              {TIER_1_QUESTIONS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setT1Index(i);
                    setT1Selected(null);
                    setT1Answered(false);
                  }}
                  className={cn(
                    "w-7 h-7 rounded-lg text-xs font-black transition-all",
                    t1Index === i ? "bg-blue-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-blue-950/40 border-2 border-blue-800/60 rounded-2xl">
            <span className="text-xs font-black uppercase text-blue-400 block mb-1">Ví dụ trọng tâm:</span>
            <h4 className="text-lg md:text-xl font-black text-white">
              {currentT1.question}
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {currentT1.options.map((opt, idx) => {
              const isSelected = t1Selected === opt;
              const isCorrect = opt === currentT1.correctAnswer;
              let style = "bg-slate-900 border-slate-800 text-slate-200 hover:border-blue-500 hover:bg-slate-850";
              if (t1Answered) {
                if (isCorrect) {
                  style = "bg-emerald-950 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500";
                } else if (isSelected) {
                  style = "bg-rose-950 border-rose-500 text-rose-200 ring-2 ring-rose-500";
                } else {
                  style = "bg-slate-900/50 border-slate-800 text-slate-500 opacity-60";
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleT1Select(opt)}
                  disabled={t1Answered}
                  className={cn(
                    "p-4 rounded-2xl border-2 transition-all font-bold text-sm text-left flex items-center justify-between cursor-pointer",
                    style
                  )}
                >
                  <span>{opt}</span>
                  {t1Answered && (
                    <span>
                      {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                      {isSelected && !isCorrect && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {t1Answered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "p-4 rounded-2xl border-2 space-y-2",
                t1Selected === currentT1.correctAnswer
                  ? "bg-emerald-950/80 border-emerald-500 text-emerald-200"
                  : "bg-rose-950/80 border-rose-500 text-rose-200"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="font-black text-sm uppercase flex items-center gap-2">
                  {t1Selected === currentT1.correctAnswer ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <span>Chính xác! (+15 XP)</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-rose-400" />
                      <span>Chưa đúng! Đáp án chuẩn: {currentT1.correctAnswer}</span>
                    </>
                  )}
                </span>
                <Button
                  onClick={() => {
                    if (t1Index < TIER_1_QUESTIONS.length - 1) {
                      setT1Index((prev) => prev + 1);
                      setT1Selected(null);
                      setT1Answered(false);
                    } else {
                      setActiveTier(2); // Auto promote to Tier 2
                    }
                  }}
                  className="bg-white hover:bg-slate-100 text-slate-950 font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  {t1Index < TIER_1_QUESTIONS.length - 1 ? 'Câu tiếp theo ➔' : 'Tiến lên TẦNG 2 ➔'}
                </Button>
              </div>
              <p className="text-xs font-bold text-slate-200 border-t border-white/10 pt-2">
                💡 <span className="font-black">Giải thích:</span> {currentT1.explanation}
              </p>
            </motion.div>
          )}
        </div>
      )}

      {/* ===================== TẦNG 2: HIỂU ===================== */}
      {activeTier === 2 && (
        <div className="bg-slate-950 p-6 md:p-8 rounded-3xl border-3 border-indigo-900/60 shadow-inner space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-black flex items-center justify-center text-sm">
                2
              </span>
              <div>
                <h3 className="font-black text-base text-indigo-300 uppercase">
                  TẦNG 2: THÔNG HIỂU CÚ PHÁP VÀ KHỐI VÙNG Ô
                </h3>
                <span className="text-xs text-slate-400 font-bold">
                  Câu hỏi {t2Index + 1}/{TIER_2_QUESTIONS.length}
                </span>
              </div>
            </div>
            <div className="flex gap-2">
              {TIER_2_QUESTIONS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setT2Index(i);
                    setT2Selected(null);
                    setT2Answered(false);
                  }}
                  className={cn(
                    "w-7 h-7 rounded-lg text-xs font-black transition-all",
                    t2Index === i ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-indigo-950/40 border-2 border-indigo-800/60 rounded-2xl space-y-2">
            <div className="text-xs font-black uppercase text-indigo-400 flex items-center gap-2">
              <span>🎯 Tình huống:</span>
              <span className="text-slate-300">{currentT2.situation}</span>
            </div>
            <h4 className="text-lg md:text-xl font-black text-white">
              {currentT2.question}
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {currentT2.options.map((opt, idx) => {
              const isSelected = t2Selected === opt;
              const isCorrect = opt === currentT2.correctAnswer;
              let style = "bg-slate-900 border-slate-800 text-slate-200 hover:border-indigo-500 hover:bg-slate-850";
              if (t2Answered) {
                if (isCorrect) {
                  style = "bg-emerald-950 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500";
                } else if (isSelected) {
                  style = "bg-rose-950 border-rose-500 text-rose-200 ring-2 ring-rose-500";
                } else {
                  style = "bg-slate-900/50 border-slate-800 text-slate-500 opacity-60";
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleT2Select(opt)}
                  disabled={t2Answered}
                  className={cn(
                    "p-4 rounded-2xl border-2 transition-all font-mono font-bold text-sm text-left flex items-center justify-between cursor-pointer",
                    style
                  )}
                >
                  <span>{opt}</span>
                  {t2Answered && (
                    <span>
                      {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                      {isSelected && !isCorrect && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {t2Answered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "p-5 rounded-2xl border-2 space-y-2",
                t2Selected === currentT2.correctAnswer
                  ? "bg-emerald-950/80 border-emerald-500 text-emerald-200"
                  : "bg-rose-950/80 border-rose-500 text-rose-200"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="font-black text-sm uppercase flex items-center gap-2">
                  {t2Selected === currentT2.correctAnswer ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <span>Chính xác! (+20 XP)</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-rose-400" />
                      <span>Chưa đúng! Đáp án chuẩn: {currentT2.correctAnswer}</span>
                    </>
                  )}
                </span>
                <Button
                  onClick={() => {
                    if (t2Index < TIER_2_QUESTIONS.length - 1) {
                      setT2Index((prev) => prev + 1);
                      setT2Selected(null);
                      setT2Answered(false);
                    } else {
                      setActiveTier(3); // Promote to Tier 3
                    }
                  }}
                  className="bg-white hover:bg-slate-100 text-slate-950 font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  {t2Index < TIER_2_QUESTIONS.length - 1 ? 'Câu tiếp theo ➔' : 'Tiến lên TẦNG 3 ➔'}
                </Button>
              </div>

              <div className="border-t border-white/10 pt-2 space-y-1">
                <div className="text-xs font-bold text-slate-200">
                  📌 <span className="font-black text-amber-300">Quy tắc cú pháp:</span> {currentT2.syntaxRule}
                </div>
                <div className="text-xs font-bold text-slate-300">
                  💡 <span className="font-black">Học sinh cần hiểu:</span> {currentT2.explanation}
                </div>
              </div>
            </motion.div>
          )}
        </div>
      )}

      {/* ===================== TẦNG 3: VẬN DỤNG ===================== */}
      {activeTier === 3 && (
        <div className="bg-slate-950 p-6 md:p-8 rounded-3xl border-3 border-emerald-900/60 shadow-inner space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-emerald-600 text-white font-black flex items-center justify-center text-sm">
                3
              </span>
              <div>
                <h3 className="font-black text-base text-emerald-300 uppercase">
                  TẦNG 3: VẬN DỤNG VÀO BẢNG ĐIỂM THỰC TẾ
                </h3>
                <span className="text-xs text-slate-400 font-bold">
                  Tình huống thực hành {t3Index + 1}/{TIER_3_QUESTIONS.length}
                </span>
              </div>
            </div>
            <div className="flex gap-2">
              {TIER_3_QUESTIONS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setT3Index(i);
                    setT3FormulaInput('');
                    setT3SelectedOption(null);
                    setT3Answered(false);
                    setT3IsCorrect(null);
                  }}
                  className={cn(
                    "w-7 h-7 rounded-lg text-xs font-black transition-all",
                    t3Index === i ? "bg-emerald-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-emerald-950/40 border-2 border-emerald-800/60 rounded-2xl">
            <h4 className="text-lg font-black text-white mb-1">{currentT3.title}</h4>
            <p className="text-xs text-slate-300 font-bold leading-relaxed">{currentT3.description}</p>
          </div>

          {/* SPREADSHEET TABLE MOCKUP */}
          <div className="overflow-x-auto bg-slate-900 rounded-2xl border-2 border-slate-700 p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-xs font-black text-emerald-400 uppercase tracking-wider">
                <TableIcon className="w-4 h-4" /> BẢNG ĐIỂM HỌC TẬP LỚP 7
              </div>
              <div className="font-mono text-xs text-slate-400 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
                Ô cần nhập: <span className="font-bold text-yellow-400">{currentT3.targetCell}</span>
              </div>
            </div>

            <table className="w-full text-center border-collapse text-sm">
              <thead>
                <tr className="bg-slate-800 text-slate-300 font-mono text-xs">
                  <th className="p-2 border border-slate-700 w-12">#</th>
                  <th className="p-2 border border-slate-700">A (Họ tên)</th>
                  <th className="p-2 border border-slate-700">B (Toán)</th>
                  <th className="p-2 border border-slate-700">C (Văn)</th>
                  <th className="p-2 border border-slate-700">D (Tin)</th>
                  <th className="p-2 border border-slate-700 bg-emerald-950/70 text-emerald-300 font-black">
                    E (Tổng điểm)
                  </th>
                </tr>
              </thead>
              <tbody>
                {currentT3.tableData.map((row, idx) => {
                  const rowNum = idx + 2;
                  const isTargetRow = (currentT3.targetCell.includes(String(rowNum)));
                  return (
                    <tr key={idx} className={cn("border-b border-slate-800", isTargetRow ? "bg-slate-800/60" : "hover:bg-slate-850")}>
                      <td className="p-2.5 border border-slate-700 font-mono text-xs text-slate-500 bg-slate-950 font-bold">
                        {rowNum}
                      </td>
                      <td className="p-2.5 border border-slate-700 font-bold text-white text-left pl-4">
                        {row.name}
                      </td>
                      <td className="p-2.5 border border-slate-700 font-mono font-bold text-amber-300">
                        {row.math}
                      </td>
                      <td className="p-2.5 border border-slate-700 font-mono font-bold text-cyan-300">
                        {row.literature}
                      </td>
                      <td className="p-2.5 border border-slate-700 font-mono font-bold text-pink-300">
                        {row.it}
                      </td>
                      <td className={cn(
                        "p-2.5 border border-slate-700 font-mono font-black",
                        isTargetRow 
                          ? "bg-emerald-500/20 text-yellow-300 border-2 border-emerald-400 animate-pulse" 
                          : "text-slate-400"
                      )}>
                        {isTargetRow ? (
                          t3Answered && t3IsCorrect ? (
                            <span className="text-emerald-400 font-black text-base">{currentT3.expectedResult}</span>
                          ) : (
                            <span className="text-xs text-yellow-300 bg-yellow-400/20 px-2 py-0.5 rounded">
                              {currentT3.targetCell}
                            </span>
                          )
                        ) : (
                          idx === 0 ? 24 : idx === 1 ? 23 : 28
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Prompt and Options */}
          <div className="space-y-3">
            <div className="font-black text-sm text-yellow-300 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-400" />
              <span>{currentT3.targetPrompt}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentT3.options?.map((opt, idx) => {
                const isSelected = t3SelectedOption === opt;
                let btnStyle = "bg-slate-900 border-slate-800 text-slate-200 hover:border-emerald-500";
                if (t3Answered) {
                  if (currentT3.acceptedFormulas.includes(opt.trim())) {
                    btnStyle = "bg-emerald-950 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500";
                  } else if (isSelected) {
                    btnStyle = "bg-rose-950 border-rose-500 text-rose-200 ring-2 ring-rose-500";
                  } else {
                    btnStyle = "bg-slate-900/50 border-slate-800 text-slate-500 opacity-60";
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleT3Select(opt)}
                    disabled={t3Answered}
                    className={cn(
                      "p-3.5 rounded-2xl border-2 font-mono font-bold text-sm text-left flex items-center justify-between transition-all cursor-pointer",
                      btnStyle
                    )}
                  >
                    <span>{opt}</span>
                    {t3Answered && isSelected && (
                      t3IsCorrect ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <XCircle className="w-5 h-5 text-rose-400" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {t3Answered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "p-5 rounded-2xl border-2 space-y-2",
                t3IsCorrect
                  ? "bg-emerald-950/80 border-emerald-500 text-emerald-200"
                  : "bg-rose-950/80 border-rose-500 text-rose-200"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="font-black text-sm uppercase flex items-center gap-2">
                  {t3IsCorrect ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <span>Xuất sắc! Bảng tính hiển thị kết quả {currentT3.expectedResult} (+25 XP)</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-rose-400" />
                      <span>Chưa chính xác!</span>
                    </>
                  )}
                </span>
                <Button
                  onClick={() => {
                    if (t3Index < TIER_3_QUESTIONS.length - 1) {
                      setT3Index((prev) => prev + 1);
                      setT3FormulaInput('');
                      setT3SelectedOption(null);
                      setT3Answered(false);
                      setT3IsCorrect(null);
                    } else {
                      setActiveTier(4); // Promote to Tier 4
                    }
                  }}
                  className="bg-white hover:bg-slate-100 text-slate-950 font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  {t3Index < TIER_3_QUESTIONS.length - 1 ? 'Tình huống tiếp theo ➔' : 'Tiến lên TẦNG 4 (SỬA LỖI) ➔'}
                </Button>
              </div>
              <p className="text-xs font-bold text-slate-200 border-t border-white/10 pt-2">
                💡 <span className="font-black">Phân tích bảng tính:</span> {currentT3.explanation}
              </p>
            </motion.div>
          )}
        </div>
      )}

      {/* ===================== TẦNG 4: PHÁT HIỆN VÀ SỬA LỖI ===================== */}
      {activeTier === 4 && (
        <div className="bg-slate-950 p-6 md:p-8 rounded-3xl border-3 border-rose-900/60 shadow-inner space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-rose-600 text-white font-black flex items-center justify-center text-sm">
                4
              </span>
              <div>
                <h3 className="font-black text-base text-rose-300 uppercase">
                  TẦNG 4: PHÁT HIỆN VÀ SỬA LỖI CÔNG THỨC (GIÁ TRỊ SƯ PHẠM CAO)
                </h3>
                <span className="text-xs text-slate-400 font-bold">
                  Thử thách sửa lỗi {t4Index + 1}/{TIER_4_QUESTIONS.length}
                </span>
              </div>
            </div>
            <div className="flex gap-2">
              {TIER_4_QUESTIONS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setT4Index(i);
                    resetTier4();
                  }}
                  className={cn(
                    "w-7 h-7 rounded-lg text-xs font-black transition-all",
                    t4Index === i ? "bg-rose-500 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Bug Display Box */}
          <div className="p-6 bg-gradient-to-r from-red-950/80 via-rose-950/60 to-slate-900 border-2 border-red-500 rounded-3xl text-center space-y-2 shadow-lg">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-500/20 text-red-300 rounded-full text-xs font-black uppercase">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              <span>CÔNG THỨC BỊ HỌC SINH GÕ LỖI:</span>
            </div>
            <div className="font-mono text-3xl md:text-4xl font-black text-white tracking-wider py-2">
              {currentT4.buggyFormula}
            </div>
            <p className="text-xs text-slate-400 font-bold">
              Em hãy thực hiện quy trình 2 bước để thẩm định và khắc phục lỗi này:
            </p>
          </div>

          {/* STEP 1: VERDICT (ĐÚNG HAY SAI?) */}
          <div className="bg-slate-900/90 p-5 rounded-2xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-black text-xs uppercase text-slate-300 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-black text-xs">
                  1
                </span>
                Bước 1: Nhận định công thức này ĐÚNG hay SAI?
              </span>
              {t4JudgeSubmitted && (
                <span className="text-xs font-black text-emerald-400">✓ Đã đánh giá</span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => handleT4Judge(true)}
                disabled={t4JudgeSubmitted}
                className={cn(
                  "p-4 rounded-2xl border-2 font-black text-sm uppercase flex items-center justify-center gap-2 transition-all cursor-pointer",
                  t4JudgeSubmitted
                    ? (currentT4.isCorrect === true ? "bg-emerald-600 border-emerald-400 text-white" : "bg-slate-950/50 border-slate-800 text-slate-600")
                    : "bg-slate-950 border-slate-700 text-slate-300 hover:border-emerald-500 hover:bg-slate-800"
                )}
              >
                <Check className="w-5 h-5 text-emerald-400" />
                <span>CÔNG THỨC ĐÚNG</span>
              </button>

              <button
                onClick={() => handleT4Judge(false)}
                disabled={t4JudgeSubmitted}
                className={cn(
                  "p-4 rounded-2xl border-2 font-black text-sm uppercase flex items-center justify-center gap-2 transition-all cursor-pointer",
                  t4JudgeSubmitted
                    ? (currentT4.isCorrect === false ? "bg-red-600 border-red-400 text-white ring-2 ring-red-400" : "bg-slate-950/50 border-slate-800 text-slate-600")
                    : "bg-slate-950 border-slate-700 text-slate-300 hover:border-red-500 hover:bg-slate-800"
                )}
              >
                <X className="w-5 h-5 text-red-400" />
                <span>❌ CÔNG THỨC SAI</span>
              </button>
            </div>
          </div>

          {/* STEP 2: FIX ERROR (CHỌN CÔNG THỨC SỬA ĐÚNG) */}
          {t4JudgeSubmitted && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-900/90 p-5 rounded-2xl border-2 border-slate-800 space-y-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-black text-xs uppercase text-slate-300">
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-black text-xs">
                    2
                  </span>
                  <span>Bước 2: Chỉ rõ lỗi & chọn công thức sửa đúng chuẩn:</span>
                </div>
                <div className="text-xs text-rose-300 font-bold pl-8">
                  ⚠️ Phân loại lỗi: <span className="font-black underline">{currentT4.bugType}</span> ({currentT4.bugDescription})
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {currentT4.fixOptions.map((opt, idx) => {
                  const isSelected = t4FixSelected === opt;
                  const isCorrectFix = opt === currentT4.correctFormula;
                  let style = "bg-slate-950 border-slate-800 text-slate-200 hover:border-rose-500";
                  if (t4FixSubmitted) {
                    if (isCorrectFix) {
                      style = "bg-emerald-950 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500";
                    } else if (isSelected) {
                      style = "bg-rose-950 border-rose-500 text-rose-200 ring-2 ring-rose-500";
                    } else {
                      style = "bg-slate-950/50 border-slate-800 text-slate-500 opacity-60";
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleT4FixSelect(opt)}
                      disabled={t4FixSubmitted}
                      className={cn(
                        "p-3.5 rounded-2xl border-2 font-mono font-black text-sm text-left flex items-center justify-between transition-all cursor-pointer",
                        style
                      )}
                    >
                      <span>{opt}</span>
                      {t4FixSubmitted && (
                        <span>
                          {isCorrectFix && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                          {isSelected && !isCorrectFix && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Feedback & Pedagogical Tip */}
          {t4FixSubmitted && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-5 rounded-2xl border-2 bg-slate-900 border-emerald-500 text-white space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400 font-black text-sm uppercase">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>
                    Chính xác! Công thức được sửa chuẩn thành: <span className="font-mono text-white underline">{currentT4.correctFormula}</span> (+30 XP)
                  </span>
                </div>
                <Button
                  onClick={() => {
                    if (t4Index < TIER_4_QUESTIONS.length - 1) {
                      setT4Index((prev) => prev + 1);
                      resetTier4();
                    } else {
                      confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
                      alert('🎉 CHÚC MỪNG! BẠN ĐÃ CHINH PHỤC THÀNH CÔNG TOÀN BỘ 4 TẦNG HỌC TẬP TIN HỌC 7!');
                    }
                  }}
                  className="bg-white hover:bg-slate-100 text-slate-950 font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  {t4Index < TIER_4_QUESTIONS.length - 1 ? 'Bài sửa lỗi tiếp theo ➔' : 'Hoàn thành 4 Tầng 🏆'}
                </Button>
              </div>

              <div className="text-xs text-amber-200 font-bold bg-amber-950/60 p-3.5 rounded-xl border border-amber-500/40 leading-relaxed">
                👩‍🏫 <span className="font-black text-amber-300">Bài học kinh nghiệm:</span> {currentT4.pedagogicalTip}
              </div>
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}
