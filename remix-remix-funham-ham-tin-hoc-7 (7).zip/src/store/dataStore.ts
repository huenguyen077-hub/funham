import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Student, Question, Assignment, Achievement } from '../types';
import { mockStudents, mockQuestions, mockAssignments, mockAchievements } from '../data/mockData';

interface DataState {
  students: Student[];
  questions: Question[];
  assignments: Assignment[];
  achievements: Achievement[];
  
  // Actions
  addStudent: (student: Student) => void;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  addQuestion: (question: Question) => void;
  updateQuestion: (id: string, updates: Partial<Question>) => void;
  deleteQuestion: (id: string) => void;
  addAssignment: (assignment: Assignment) => void;
  updateAssignment: (id: string, updates: Partial<Assignment>) => void;
  deleteAssignment: (id: string) => void;
  resetData: () => void;
}

export const useDataStore = create<DataState>()(
  persist(
    (set) => ({
      students: mockStudents,
      questions: mockQuestions,
      assignments: mockAssignments,
      achievements: mockAchievements,

      addStudent: (student) => set((state) => {
        const exists = state.students.some(s => s.name.toLowerCase() === student.name.toLowerCase());
        if (exists) {
          return {
            students: state.students.map(s => s.name.toLowerCase() === student.name.toLowerCase() ? { ...s, ...student } : s)
          };
        }
        return { students: [student, ...state.students] };
      }),
      
      updateStudent: (id, updates) => set((state) => ({
        students: state.students.map(s => s.id === id ? { ...s, ...updates } : s)
      })),

      addQuestion: (question) => set((state) => ({ questions: [...state.questions, question] })),
      
      updateQuestion: (id, updates) => set((state) => ({
        questions: state.questions.map(q => q.id === id ? { ...q, ...updates } : q)
      })),
      
      deleteQuestion: (id) => set((state) => ({
        questions: state.questions.filter(q => q.id !== id)
      })),

      addAssignment: (assignment) => set((state) => ({ assignments: [...state.assignments, assignment] })),
      
      updateAssignment: (id, updates) => set((state) => ({
        assignments: state.assignments.map(a => a.id === id ? { ...a, ...updates } : a)
      })),

      deleteAssignment: (id) => set((state) => ({
        assignments: state.assignments.filter(a => a.id !== id)
      })),
      
      resetData: () => set({
        students: mockStudents,
        questions: mockQuestions,
        assignments: mockAssignments,
        achievements: mockAchievements,
      })
    }),
    {
      name: 'tin-master-data',
      onRehydrateStorage: () => (state) => {
        if (state) {
          const hasBaoNam = state.students.some(
            (s) => s.name.toLowerCase() === 'bảo nam'
          );
          if (!hasBaoNam) {
            state.students = [
              {
                id: 'hs_baonam',
                name: 'Bảo Nam',
                role: 'student',
                className: '7A1',
                xp: 950,
                level: 6,
                score: 92,
                streak: 5,
                badges: ['first_step', 'speed_master', 'perfect_score'],
                completedAssignments: ['asm1'],
                createdAt: new Date().toISOString(),
              },
              ...state.students,
            ];
          }
        }
      },
    }
  )
);
