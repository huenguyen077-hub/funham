import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, Student, Teacher } from '../types';
import { mockTeachers } from '../data/mockData';
import { useDataStore } from './dataStore';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (id: string, role: 'student' | 'teacher') => void;
  loginAs: (user: User) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (id, role) => {
        let user: User | undefined;
        if (role === 'student') {
          user = useDataStore.getState().students.find((s: Student) => s.id === id);
        } else {
          user = mockTeachers.find(t => t.id === id);
        }
        
        if (user) {
          set({ user, isAuthenticated: true });
        }
      },
      loginAs: (user) => {
        set({ user, isAuthenticated: true });
      },
      logout: () => set({ user: null, isAuthenticated: false }),
    }),
    {
      name: 'tin-master-auth',
    }
  )
);
