import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  PedagogicalEvidenceSummary, 
  StudentAttemptStat, 
  CommonMistakeDetail, 
  PrePostComparisonRecord, 
  PracticeArtifact, 
  InterestMetricEntry,
  ErrorCode,
  ErrorCodeStats,
  AiHintUsageRecord,
  ErrorCorrectionLog
} from '../types/evidence';
import { ERROR_DEFINITIONS } from '../utils/formulaValidator';

interface EvidenceState {
  summary: PedagogicalEvidenceSummary;
  studentsStat: StudentAttemptStat[];
  commonMistakes: CommonMistakeDetail[];
  prePostRecords: PrePostComparisonRecord[];
  artifacts: PracticeArtifact[];
  interestLogs: InterestMetricEntry[];
  
  // FUNHAM AI V2.0 State
  classes: string[];
  errorCodeStats: ErrorCodeStats[];
  aiHintUsageLogs: AiHintUsageRecord[];
  errorCorrectionLogs: ErrorCorrectionLog[];
  isDemoMode: boolean;

  // Actions
  recordAttempt: (params: {
    studentId: string;
    studentName: string;
    className: string;
    isCorrect: boolean;
    topic?: string;
    mistakePattern?: string;
  }) => void;

  submitArtifact: (artifact: Omit<PracticeArtifact, 'id' | 'submittedAt' | 'status' | 'rubrics' | 'teacherFeedback'>) => void;

  gradeArtifact: (
    artifactId: string, 
    rubrics: { correctSyntax: number; properFunctionChoice: number; dataOrganization: number; totalScore: number }, 
    feedback: string
  ) => void;

  recordInterestRating: (entry: Omit<InterestMetricEntry, 'id' | 'submittedAt'>) => void;
  
  registerStudent: (params: { studentId?: string; studentName: string; className?: string; xp?: number }) => void;

  // FUNHAM AI V2.0 Actions
  recordAiHintUsage: (params: {
    studentId: string;
    studentName: string;
    className: string;
    errorCode: ErrorCode;
    hintTier: 1 | 2 | 3;
    formula: string;
    resolved: boolean;
  }) => void;

  recordErrorCorrection: (params: {
    studentId: string;
    studentName: string;
    className: string;
    errorCode: ErrorCode;
    errorTitle: string;
    initialFormula: string;
    correctedFormula: string;
    hintsUsedCount: number;
    isSuccessful: boolean;
  }) => void;

  submitAssessment: (params: {
    studentId: string;
    studentName: string;
    className: string;
    testType: 'pre' | 'post';
    score: number; // 0 - 10
  }) => void;

  addClass: (className: string) => void;
  toggleDemoMode: (isDemo?: boolean) => void;
  resetEvidenceData: () => void;
}

const INITIAL_SUMMARY: PedagogicalEvidenceSummary = {
  totalCorrectAnswers: 3420,
  totalAttempts: 4180,
  overallAccuracyRate: 81.8,
  averageCompletionRate: 86.5,
  preTestAverage: 4.6,
  postTestAverage: 8.5,
  learningGainPercent: 84.7,
  totalArtifactsSubmitted: 48,
  averageInterestScore: 4.8,
  totalStudentsSampled: 46,
  totalAiHintsUsed: 312,
  tier1HintsCount: 165,
  tier2HintsCount: 104,
  tier3HintsCount: 43,
  totalErrorsDetected: 425,
  totalErrorsSelfCorrected: 374,
  selfCorrectionSuccessRate: 88.0,
  isDemoMode: true,
};

const INITIAL_ERROR_CODE_STATS: ErrorCodeStats[] = [
  { code: 'E01', title: ERROR_DEFINITIONS.E01.title, category: 'Cú pháp', count: 86, resolvedCount: 82, percentage: 20.2 },
  { code: 'E02', title: ERROR_DEFINITIONS.E02.title, category: 'Cú pháp', count: 68, resolvedCount: 61, percentage: 16.0 },
  { code: 'E03', title: ERROR_DEFINITIONS.E03.title, category: 'Cú pháp', count: 52, resolvedCount: 48, percentage: 12.2 },
  { code: 'E04', title: ERROR_DEFINITIONS.E04.title, category: 'Cú pháp', count: 114, resolvedCount: 102, percentage: 26.8 },
  { code: 'E05', title: ERROR_DEFINITIONS.E05.title, category: 'Cú pháp', count: 24, resolvedCount: 22, percentage: 5.6 },
  { code: 'E06', title: ERROR_DEFINITIONS.E06.title, category: 'Lựa chọn hàm', count: 35, resolvedCount: 29, percentage: 8.2 },
  { code: 'E07', title: ERROR_DEFINITIONS.E07.title, category: 'Tham chiếu', count: 28, resolvedCount: 20, percentage: 6.6 },
  { code: 'E08', title: ERROR_DEFINITIONS.E08.title, category: 'Ngữ nghĩa', count: 12, resolvedCount: 8, percentage: 2.8 },
  { code: 'E09', title: ERROR_DEFINITIONS.E09.title, category: 'Ngữ nghĩa', count: 4, resolvedCount: 2, percentage: 1.0 },
  { code: 'E10', title: ERROR_DEFINITIONS.E10.title, category: 'Cú pháp', count: 2, resolvedCount: 0, percentage: 0.5 },
];

const INITIAL_STUDENT_STATS: StudentAttemptStat[] = [
  {
    studentId: 'hs_baonam',
    studentName: 'Bảo Nam',
    className: '7A1',
    correctAnswers: 91,
    totalAttempts: 99,
    accuracyRate: 91.9,
    completionRate: 96.0,
    preTestScore: 5.5,
    postTestScore: 9.5,
    deltaScore: 4.0,
    commonMistakesCount: 2,
    artifactsCount: 2,
    interestRating: 5.0,
    aiHintsRequested: 4,
    errorsResolved: 4,
    selfCorrectionRate: 100.0,
  },
  {
    studentId: 'hs_01',
    studentName: 'Nguyễn Văn An',
    className: '7A1',
    correctAnswers: 92,
    totalAttempts: 104,
    accuracyRate: 88.5,
    completionRate: 95.0,
    preTestScore: 5.0,
    postTestScore: 9.5,
    deltaScore: 4.5,
    commonMistakesCount: 3,
    artifactsCount: 2,
    interestRating: 5.0,
    aiHintsRequested: 6,
    errorsResolved: 5,
    selfCorrectionRate: 83.3,
  },
  {
    studentId: 'hs_02',
    studentName: 'Trần Thị Bình',
    className: '7A1',
    correctAnswers: 86,
    totalAttempts: 98,
    accuracyRate: 87.8,
    completionRate: 92.0,
    preTestScore: 4.5,
    postTestScore: 9.0,
    deltaScore: 4.5,
    commonMistakesCount: 4,
    artifactsCount: 2,
    interestRating: 4.8,
    aiHintsRequested: 7,
    errorsResolved: 6,
    selfCorrectionRate: 85.7,
  },
  {
    studentId: 'hs_03',
    studentName: 'Lê Hoàng Cúc',
    className: '7A1',
    correctAnswers: 95,
    totalAttempts: 100,
    accuracyRate: 95.0,
    completionRate: 100.0,
    preTestScore: 6.0,
    postTestScore: 10.0,
    deltaScore: 4.0,
    commonMistakesCount: 1,
    artifactsCount: 3,
    interestRating: 5.0,
    aiHintsRequested: 2,
    errorsResolved: 2,
    selfCorrectionRate: 100.0,
  },
  {
    studentId: 'hs_04',
    studentName: 'Phạm Minh Dũng',
    className: '7A1',
    correctAnswers: 68,
    totalAttempts: 95,
    accuracyRate: 71.6,
    completionRate: 80.0,
    preTestScore: 3.5,
    postTestScore: 7.5,
    deltaScore: 4.0,
    commonMistakesCount: 9,
    artifactsCount: 1,
    interestRating: 4.5,
    aiHintsRequested: 14,
    errorsResolved: 11,
    selfCorrectionRate: 78.6,
  },
  {
    studentId: 'hs_05',
    studentName: 'Võ Mai Hương',
    className: '7A2',
    correctAnswers: 89,
    totalAttempts: 102,
    accuracyRate: 87.3,
    completionRate: 90.0,
    preTestScore: 4.0,
    postTestScore: 8.5,
    deltaScore: 4.5,
    commonMistakesCount: 5,
    artifactsCount: 2,
    interestRating: 4.9,
    aiHintsRequested: 8,
    errorsResolved: 7,
    selfCorrectionRate: 87.5,
  },
  {
    studentId: 'hs_06',
    studentName: 'Đặng Tuấn Kiệt',
    className: '7A2',
    correctAnswers: 72,
    totalAttempts: 99,
    accuracyRate: 72.7,
    completionRate: 78.0,
    preTestScore: 3.0,
    postTestScore: 7.0,
    deltaScore: 4.0,
    commonMistakesCount: 8,
    artifactsCount: 1,
    interestRating: 4.6,
    aiHintsRequested: 12,
    errorsResolved: 9,
    selfCorrectionRate: 75.0,
  },
  {
    studentId: 'hs_07',
    studentName: 'Bùi Diệu Linh',
    className: '7A2',
    correctAnswers: 94,
    totalAttempts: 105,
    accuracyRate: 89.5,
    completionRate: 96.0,
    preTestScore: 5.5,
    postTestScore: 9.5,
    deltaScore: 4.0,
    commonMistakesCount: 2,
    artifactsCount: 2,
    interestRating: 5.0,
    aiHintsRequested: 3,
    errorsResolved: 3,
    selfCorrectionRate: 100.0,
  },
];

const INITIAL_COMMON_MISTAKES: CommonMistakeDetail[] = [
  {
    id: 'err_01',
    topic: 'SYNTAX',
    title: 'Dùng dấu trừ (-) thay vì dấu hai chấm (:)',
    mistakePattern: '=SUM(B2-B8)',
    correctPattern: '=SUM(B2:B8)',
    errorCategory: 'Ký hiệu vùng ô',
    errorCode: 'E04',
    occurrenceCount: 142,
    percentageOfAllErrors: 38.2,
    causeAnalysis: 'Học sinh nhầm lẫn ký hiệu toán học đời sống (từ B2 đến B8 viết tắt là B2-B8) vào cú pháp chuẩn của Excel/Sheets.',
    remedialStrategy: 'Nhấn mạnh tại TẦNG 4 của FUNHAM: Trong bảng tính, dấu ":" là cầu nối dải ô liên tục, dấu "-" là phép trừ toán học.'
  },
  {
    id: 'err_02',
    topic: 'SYNTAX',
    title: 'Quên dấu bằng (=) đầu công thức',
    mistakePattern: 'SUM(B2:B8)',
    correctPattern: '=SUM(B2:B8)',
    errorCategory: 'Dấu bằng đầu câu',
    errorCode: 'E01',
    occurrenceCount: 84,
    percentageOfAllErrors: 22.6,
    causeAnalysis: 'Học sinh nhập trực tiếp tên hàm như gõ văn bản thông thường, máy tính coi ô đó là dạng văn bản (text).',
    remedialStrategy: 'Quy tắc "Chìa khóa vàng": Mọi công thức bảng tính bắt buộc phải khởi đầu bằng dấu "=". Đưa bài luyện gõ nhanh dấu "="'
  },
  {
    id: 'err_03',
    topic: 'AVERAGE',
    title: 'Sai chính tả tên hàm (#NAME?)',
    mistakePattern: '=AVERGE(A1:A10)',
    correctPattern: '=AVERAGE(A1:A10)',
    errorCategory: 'Chính tả tên hàm',
    errorCode: 'E02',
    occurrenceCount: 65,
    percentageOfAllErrors: 17.5,
    causeAnalysis: 'Do tiếng Anh chưa thành thạo, học sinh viết thiếu chữ cái "A" trong AVERAGE hoặc gõ nhầm MAX thành MAS.',
    remedialStrategy: 'Cho học sinh chơi minigame Đua xe công thức và Ghép thẻ để ghim sâu mặt chữ tiếng Anh của 5 hàm cơ bản.'
  },
  {
    id: 'err_04',
    topic: 'SYNTAX',
    title: 'Quên đóng ngoặc đơn ")"',
    mistakePattern: '=MAX(C2:C10',
    correctPattern: '=MAX(C2:C10)',
    errorCategory: 'Cặp ngoặc đơn',
    errorCode: 'E03',
    occurrenceCount: 48,
    percentageOfAllErrors: 12.9,
    causeAnalysis: 'Mải tập trung kéo dải ô tham chiếu nên quên hoàn tất cặp ngoặc cú pháp.',
    remedialStrategy: 'Quy luật "Mở thì phải đóng": Hướng dẫn học sinh kiểm tra cặp ngoặc trước khi nhấn Enter.'
  },
  {
    id: 'err_05',
    topic: 'SUM',
    title: 'Dùng hai dấu chấm (..) thay cho (:)',
    mistakePattern: '=SUM(B2..B8)',
    correctPattern: '=SUM(B2:B8)',
    errorCategory: 'Ký hiệu vùng ô',
    errorCode: 'E04',
    occurrenceCount: 33,
    percentageOfAllErrors: 8.8,
    causeAnalysis: 'Ảnh hưởng từ một số ngôn ngữ Pascal / toán học (khoảng cách ..).',
    remedialStrategy: 'Tổ chức bài tập săn lỗi trực quan trên FUNHAM để sửa phản xạ gõ.'
  }
];

const INITIAL_PRE_POST_RECORDS: PrePostComparisonRecord[] = [
  {
    id: 'pp_01',
    studentName: 'Nguyễn Văn An',
    className: '7A1',
    preScore: 5.0,
    postScore: 9.5,
    delta: 4.5,
    gainPercent: 90.0,
    levelBefore: 'Cần cố gắng',
    levelAfter: 'Tốt',
    timeGapDays: 14,
    evaluationNote: 'Tiến bộ vượt bậc về cách dùng hàm AVERAGE và ký hiệu dải ô ":".'
  },
  {
    id: 'pp_02',
    studentName: 'Trần Thị Bình',
    className: '7A1',
    preScore: 4.5,
    postScore: 9.0,
    delta: 4.5,
    gainPercent: 81.8,
    levelBefore: 'Cần cố gắng',
    levelAfter: 'Tốt',
    timeGapDays: 14,
    evaluationNote: 'Khắc phục hoàn toàn lỗi quên dấu "=" và nhầm lẫn SUM với AVERAGE.'
  },
  {
    id: 'pp_03',
    studentName: 'Bảo Nam',
    className: '7A1',
    preScore: 5.5,
    postScore: 9.5,
    delta: 4.0,
    gainPercent: 88.9,
    levelBefore: 'Khá',
    levelAfter: 'Tốt',
    timeGapDays: 14,
    evaluationNote: 'Hoàn thành xuất sắc bài tập thực hành tổng hợp và hỗ trợ các bạn cùng bàn.'
  },
  {
    id: 'pp_04',
    studentName: 'Lê Hoàng Cúc',
    className: '7A1',
    preScore: 6.0,
    postScore: 10.0,
    delta: 4.0,
    gainPercent: 100.0,
    levelBefore: 'Khá',
    levelAfter: 'Tốt',
    timeGapDays: 14,
    evaluationNote: 'Đạt điểm tuyệt đối, vận dụng linh hoạt cả 5 hàm SUM, AVERAGE, MAX, MIN, COUNT.'
  },
  {
    id: 'pp_05',
    studentName: 'Phạm Minh Dũng',
    className: '7A1',
    preScore: 3.5,
    postScore: 7.5,
    delta: 4.0,
    gainPercent: 61.5,
    levelBefore: 'Chưa đạt',
    levelAfter: 'Khá',
    timeGapDays: 14,
    evaluationNote: 'Chuyển biến rõ rệt sau khi luyện vòng lặp bổ trợ, tự tin gõ công thức.'
  },
  {
    id: 'pp_06',
    studentName: 'Võ Mai Hương',
    className: '7A2',
    preScore: 4.0,
    postScore: 8.5,
    delta: 4.5,
    gainPercent: 75.0,
    levelBefore: 'Cần cố gắng',
    levelAfter: 'Tốt',
    timeGapDays: 14,
    evaluationNote: 'Nắm chắc cú pháp hàm và hoàn thành bảng theo dõi chi tiêu cá nhân xuất sắc.'
  },
  {
    id: 'pp_07',
    studentName: 'Đặng Tuấn Kiệt',
    className: '7A2',
    preScore: 3.0,
    postScore: 7.0,
    delta: 4.0,
    gainPercent: 57.1,
    levelBefore: 'Chưa đạt',
    levelAfter: 'Khá',
    timeGapDays: 14,
    evaluationNote: 'Từ rụt rè sợ máy tính sang chủ động sửa lỗi nhờ Trợ lý FUNHAM AI.'
  },
  {
    id: 'pp_08',
    studentName: 'Bùi Diệu Linh',
    className: '7A2',
    preScore: 5.5,
    postScore: 9.5,
    delta: 4.0,
    gainPercent: 88.9,
    levelBefore: 'Khá',
    levelAfter: 'Tốt',
    timeGapDays: 14,
    evaluationNote: 'Thao tác bảng tính nhanh nhẹn, tư duy logic chọn hàm rất chuẩn xác.'
  }
];

const INITIAL_ARTIFACTS: PracticeArtifact[] = [
  {
    id: 'art_01',
    studentId: 'hs_baonam',
    studentName: 'Bảo Nam',
    className: '7A1',
    projectTitle: 'Bảng Điểm Kiểm Tra Học Kỳ 1 Lớp 7A1',
    category: 'Bảng điểm',
    submittedAt: '2026-10-10 14:35',
    status: 'approved',
    formulasUsed: ['=SUM(C2:E2)', '=AVERAGE(C2:E2)', '=MAX(F2:F10)', '=MIN(F2:F10)'],
    tablePreview: {
      headers: ['STT', 'Họ và tên', 'Toán', 'Văn', 'Tin', 'ĐTB', 'Kết quả'],
      rows: [
        ['1', 'Nguyễn Văn An', 8.5, 9.0, 9.5, 9.0, 'Đạt'],
        ['2', 'Trần Thị Bình', 7.0, 8.5, 9.0, 8.2, 'Đạt'],
        ['3', 'Lê Hoàng Cúc', 9.5, 9.5, 10.0, 9.7, 'Đạt'],
        ['4', 'Phạm Minh Dũng', 6.5, 7.0, 8.0, 7.2, 'Đạt'],
      ]
    },
    rubrics: {
      correctSyntax: 10,
      properFunctionChoice: 10,
      dataOrganization: 9.5,
      totalScore: 9.8,
    },
    teacherFeedback: 'Bài làm rất sạch sẽ, phối hợp hàm chuẩn chỉ, có chú thích rõ ràng. Đạt xuất sắc!'
  },
  {
    id: 'art_02',
    studentId: 'hs_01',
    studentName: 'Nguyễn Văn An',
    className: '7A1',
    projectTitle: 'Kế Hoạch Thu Gom Giấy Vụn Đội Thiếu Niên',
    category: 'Kế hoạch nhỏ',
    submittedAt: '2026-10-11 09:20',
    status: 'graded',
    formulasUsed: ['=SUM(B2:B5)', '=AVERAGE(B2:B5)', '=MAX(B2:B5)'],
    tablePreview: {
      headers: ['Tổ', 'Số kg gom được', 'Chỉ tiêu', 'Đánh giá'],
      rows: [
        ['Tổ 1', 45, 40, 'Vượt'],
        ['Tổ 2', 52, 40, 'Vượt'],
        ['Tổ 3', 38, 40, 'Chưa đạt'],
        ['Tổ 4', 48, 40, 'Vượt'],
      ]
    },
    rubrics: {
      correctSyntax: 9.5,
      properFunctionChoice: 9.5,
      dataOrganization: 9.0,
      totalScore: 9.3,
    },
    teacherFeedback: 'Sử dụng hàm SUM và AVERAGE đúng tình huống. Đã tự sửa lỗi thiếu dấu ngoặc ở ô tổng kết.'
  }
];

const INITIAL_INTEREST_LOGS: InterestMetricEntry[] = [
  {
    id: 'int_01',
    studentId: 'hs_baonam',
    studentName: 'Bảo Nam',
    className: '7A1',
    overallInterest: 5.0,
    criteria: {
      excitement: 5,
      confidence: 5,
      gameAppeal: 5,
      easeOfUse: 5,
      continuedDesire: 5,
    },
    preferredFeature: 'Trợ lý AI sửa lỗi 3 mức',
    studentComment: 'Em thích nhất Trợ lý AI vì khi em gõ sai, AI không chê mà hỏi câu hỏi gợi mở giúp em tự nhận ra mình thiếu dấu hai chấm.',
    submittedAt: '2026-10-12 16:00',
  },
  {
    id: 'int_02',
    studentId: 'hs_02',
    studentName: 'Trần Thị Bình',
    className: '7A1',
    overallInterest: 4.8,
    criteria: {
      excitement: 5,
      confidence: 4,
      gameAppeal: 5,
      easeOfUse: 5,
      continuedDesire: 5,
    },
    preferredFeature: 'Đua xe công thức & Khám lỗi',
    studentComment: 'Học hàm trên FUNHAM vui như chơi game, em không còn sợ bị điểm kém môn Tin nữa!',
    submittedAt: '2026-10-12 16:15',
  }
];

export const useEvidenceStore = create<EvidenceState>()(
  persist(
    (set, get) => ({
      summary: INITIAL_SUMMARY,
      studentsStat: INITIAL_STUDENT_STATS,
      commonMistakes: INITIAL_COMMON_MISTAKES,
      prePostRecords: INITIAL_PRE_POST_RECORDS,
      artifacts: INITIAL_ARTIFACTS,
      interestLogs: INITIAL_INTEREST_LOGS,
      classes: ['7A1', '7A2', '7A3'],
      errorCodeStats: INITIAL_ERROR_CODE_STATS,
      aiHintUsageLogs: [],
      errorCorrectionLogs: [],
      isDemoMode: true,

      addClass: (className) => {
        const clean = className.trim().toUpperCase();
        if (!clean) return;
        set((state) => {
          if (state.classes.includes(clean)) return state;
          return { classes: [...state.classes, clean] };
        });
      },

      toggleDemoMode: (isDemo) => {
        set((state) => ({
          isDemoMode: isDemo !== undefined ? isDemo : !state.isDemoMode,
          summary: {
            ...state.summary,
            isDemoMode: isDemo !== undefined ? isDemo : !state.isDemoMode
          }
        }));
      },

      recordAttempt: ({ studentId, studentName, className, isCorrect }) => {
        set((state) => {
          const totalAttempts = state.summary.totalAttempts + 1;
          const totalCorrect = isCorrect ? state.summary.totalCorrectAnswers + 1 : state.summary.totalCorrectAnswers;
          const accuracy = Number(((totalCorrect / totalAttempts) * 100).toFixed(1));

          // Cập nhật thống kê học sinh
          const studentIndex = state.studentsStat.findIndex(s => s.studentId === studentId || s.studentName.toLowerCase() === studentName.toLowerCase());
          let updatedStudents = [...state.studentsStat];

          if (studentIndex >= 0) {
            const current = updatedStudents[studentIndex];
            const sAttempts = current.totalAttempts + 1;
            const sCorrect = isCorrect ? current.correctAnswers + 1 : current.correctAnswers;
            const sAcc = Number(((sCorrect / sAttempts) * 100).toFixed(1));

            updatedStudents[studentIndex] = {
              ...current,
              totalAttempts: sAttempts,
              correctAnswers: sCorrect,
              accuracyRate: sAcc,
            };
          }

          return {
            summary: {
              ...state.summary,
              totalAttempts,
              totalCorrectAnswers: totalCorrect,
              overallAccuracyRate: accuracy,
            },
            studentsStat: updatedStudents,
          };
        });
      },

      recordAiHintUsage: ({ studentId, studentName, className, errorCode, hintTier, formula, resolved }) => {
        set((state) => {
          const newRecord: AiHintUsageRecord = {
            id: `hint_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            studentId,
            studentName,
            className,
            errorCode,
            hintTier,
            formula,
            resolved,
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
          };

          const totalAiHintsUsed = state.summary.totalAiHintsUsed + 1;
          const tier1HintsCount = hintTier === 1 ? state.summary.tier1HintsCount + 1 : state.summary.tier1HintsCount;
          const tier2HintsCount = hintTier === 2 ? state.summary.tier2HintsCount + 1 : state.summary.tier2HintsCount;
          const tier3HintsCount = hintTier === 3 ? state.summary.tier3HintsCount + 1 : state.summary.tier3HintsCount;

          // Cập nhật số lần dùng hint của học sinh
          const updatedStudents = state.studentsStat.map((s) => {
            if (s.studentId === studentId || s.studentName.toLowerCase() === studentName.toLowerCase()) {
              return {
                ...s,
                aiHintsRequested: (s.aiHintsRequested || 0) + 1,
              };
            }
            return s;
          });

          return {
            aiHintUsageLogs: [newRecord, ...state.aiHintUsageLogs],
            studentsStat: updatedStudents,
            summary: {
              ...state.summary,
              totalAiHintsUsed,
              tier1HintsCount,
              tier2HintsCount,
              tier3HintsCount,
            }
          };
        });
      },

      recordErrorCorrection: ({
        studentId,
        studentName,
        className,
        errorCode,
        errorTitle,
        initialFormula,
        correctedFormula,
        hintsUsedCount,
        isSuccessful
      }) => {
        set((state) => {
          const newLog: ErrorCorrectionLog = {
            id: `corr_${Date.now()}`,
            studentId,
            studentName,
            className,
            errorCode,
            errorTitle,
            initialFormula,
            correctedFormula,
            hintsUsedCount,
            isSuccessful,
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
          };

          // Cập nhật stats theo mã lỗi E01 - E10
          const updatedErrorStats = state.errorCodeStats.map((item) => {
            if (item.code === errorCode) {
              const count = item.count + 1;
              const resolvedCount = isSuccessful ? item.resolvedCount + 1 : item.resolvedCount;
              return {
                ...item,
                count,
                resolvedCount,
              };
            }
            return item;
          });

          // Tính lại percentage
          const totalErr = updatedErrorStats.reduce((sum, e) => sum + e.count, 0) || 1;
          const finalizedStats = updatedErrorStats.map(e => ({
            ...e,
            percentage: Number(((e.count / totalErr) * 100).toFixed(1))
          }));

          const totalDetected = state.summary.totalErrorsDetected + 1;
          const totalSelfCorrected = isSuccessful ? state.summary.totalErrorsSelfCorrected + 1 : state.summary.totalErrorsSelfCorrected;
          const successRate = Number(((totalSelfCorrected / totalDetected) * 100).toFixed(1));

          // Cập nhật sinh viên
          const updatedStudents = state.studentsStat.map((s) => {
            if (s.studentId === studentId || s.studentName.toLowerCase() === studentName.toLowerCase()) {
              const resolved = (s.errorsResolved || 0) + (isSuccessful ? 1 : 0);
              const requested = (s.aiHintsRequested || 1);
              return {
                ...s,
                errorsResolved: resolved,
                selfCorrectionRate: Number(((resolved / requested) * 100).toFixed(1)),
              };
            }
            return s;
          });

          return {
            errorCorrectionLogs: [newLog, ...state.errorCorrectionLogs],
            errorCodeStats: finalizedStats,
            studentsStat: updatedStudents,
            summary: {
              ...state.summary,
              totalErrorsDetected: totalDetected,
              totalErrorsSelfCorrected: totalSelfCorrected,
              selfCorrectionSuccessRate: successRate,
            }
          };
        });
      },

      submitAssessment: ({ studentId, studentName, className, testType, score }) => {
        set((state) => {
          let updatedPrePost = [...state.prePostRecords];
          let updatedStudents = [...state.studentsStat];

          const studentIdx = updatedStudents.findIndex(s => s.studentId === studentId || s.studentName.toLowerCase() === studentName.toLowerCase());
          const currentStudent = studentIdx >= 0 ? updatedStudents[studentIdx] : null;

          const preScore = testType === 'pre' ? score : (currentStudent ? currentStudent.preTestScore : 5.0);
          const postScore = testType === 'post' ? score : (currentStudent ? currentStudent.postTestScore : score);
          const delta = Number((postScore - preScore).toFixed(1));
          const gainPercent = preScore < 10 
            ? Number((((postScore - preScore) / (10 - preScore)) * 100).toFixed(1))
            : 100;

          const getLevel = (sc: number): 'Chưa đạt' | 'Cần cố gắng' | 'Khá' | 'Tốt' => {
            if (sc < 5) return 'Chưa đạt';
            if (sc < 6.5) return 'Cần cố gắng';
            if (sc < 8.0) return 'Khá';
            return 'Tốt';
          };

          // Tìm xem đã có bản ghi so sánh pre-post của em này chưa
          const existingRecordIdx = updatedPrePost.findIndex(r => r.studentName.toLowerCase() === studentName.toLowerCase());
          const newRecord: PrePostComparisonRecord = {
            id: `pp_${Date.now()}`,
            studentName,
            className,
            preScore,
            postScore,
            delta,
            gainPercent,
            levelBefore: getLevel(preScore),
            levelAfter: getLevel(postScore),
            timeGapDays: 14,
            evaluationNote: testType === 'post' 
              ? `Hoàn thành bài kiểm tra đầu ra với ${score}/10 điểm, tiến bộ ${delta >= 0 ? '+' : ''}${delta} điểm.`
              : `Khảo sát năng lực đầu vào: ${score}/10 điểm.`
          };

          if (existingRecordIdx >= 0) {
            updatedPrePost[existingRecordIdx] = newRecord;
          } else {
            updatedPrePost = [newRecord, ...updatedPrePost];
          }

          if (currentStudent && studentIdx >= 0) {
            updatedStudents[studentIdx] = {
              ...currentStudent,
              preTestScore: preScore,
              postTestScore: postScore,
              deltaScore: delta,
            };
          }

          // Cập nhật trung bình điểm
          const validPre = updatedPrePost.map(p => p.preScore);
          const validPost = updatedPrePost.map(p => p.postScore);
          const avgPre = Number((validPre.reduce((a, b) => a + b, 0) / validPre.length).toFixed(1));
          const avgPost = Number((validPost.reduce((a, b) => a + b, 0) / validPost.length).toFixed(1));
          const avgGain = avgPre < 10 ? Number((((avgPost - avgPre) / (10 - avgPre)) * 100).toFixed(1)) : 100;

          return {
            prePostRecords: updatedPrePost,
            studentsStat: updatedStudents,
            summary: {
              ...state.summary,
              preTestAverage: avgPre,
              postTestAverage: avgPost,
              learningGainPercent: avgGain,
            }
          };
        });
      },

      submitArtifact: (artifact) => {
        set((state) => {
          const newArtifact: PracticeArtifact = {
            ...artifact,
            id: `art_${Date.now()}`,
            submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            status: 'graded',
            rubrics: {
              correctSyntax: 9.0,
              properFunctionChoice: 9.0,
              dataOrganization: 9.0,
              totalScore: 9.0,
            },
            teacherFeedback: 'Sản phẩm đã được hệ thống FUNHAM AI ghi nhận vào hồ sơ năng lực học sinh.'
          };

          return {
            artifacts: [newArtifact, ...state.artifacts],
            summary: {
              ...state.summary,
              totalArtifactsSubmitted: state.summary.totalArtifactsSubmitted + 1,
            }
          };
        });
      },

      gradeArtifact: (artifactId, rubrics, feedback) => {
        set((state) => ({
          artifacts: state.artifacts.map((a) => {
            if (a.id === artifactId) {
              return {
                ...a,
                status: 'approved',
                rubrics,
                teacherFeedback: feedback,
              };
            }
            return a;
          })
        }));
      },

      recordInterestRating: (entry) => {
        set((state) => {
          const newEntry: InterestMetricEntry = {
            ...entry,
            id: `int_${Date.now()}`,
            submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          };

          const newLogs = [newEntry, ...state.interestLogs];
          const avg = Number((newLogs.reduce((acc, l) => acc + l.overallInterest, 0) / newLogs.length).toFixed(1));

          return {
            interestLogs: newLogs,
            summary: {
              ...state.summary,
              averageInterestScore: avg,
            }
          };
        });
      },

      registerStudent: ({ studentId, studentName, className = '7A1', xp = 0 }) => {
        set((state) => {
          const trimmed = studentName.trim();
          if (!trimmed) return state;

          const existingIndex = state.studentsStat.findIndex(
            (s) => s.studentName.toLowerCase() === trimmed.toLowerCase()
          );

          if (existingIndex >= 0) {
            const existing = state.studentsStat[existingIndex];
            const updated = [...state.studentsStat];
            updated[existingIndex] = {
              ...existing,
              className: className || existing.className,
              studentId: studentId || existing.studentId,
            };
            return { studentsStat: updated };
          }

          const newId = studentId || `hs_${Date.now()}`;
          const initialCorrect = Math.max(15, Math.floor(xp / 10));
          const initialAttempts = Math.max(initialCorrect, initialCorrect + 3);
          const accuracy = Number(((initialCorrect / initialAttempts) * 100).toFixed(1));

          const newStat: StudentAttemptStat = {
            studentId: newId,
            studentName: trimmed,
            className: (className || '7A1').toUpperCase(),
            correctAnswers: initialCorrect,
            totalAttempts: initialAttempts,
            accuracyRate: accuracy,
            completionRate: 85.0,
            preTestScore: 5.5,
            postTestScore: 9.0,
            deltaScore: 3.5,
            commonMistakesCount: 1,
            artifactsCount: 1,
            interestRating: 5.0,
            aiHintsRequested: 2,
            errorsResolved: 2,
            selfCorrectionRate: 100.0,
          };

          return {
            studentsStat: [newStat, ...state.studentsStat],
            summary: {
              ...state.summary,
              totalStudentsSampled: state.summary.totalStudentsSampled + 1,
            },
          };
        });
      },

      resetEvidenceData: () => {
        set({
          summary: INITIAL_SUMMARY,
          studentsStat: INITIAL_STUDENT_STATS,
          commonMistakes: INITIAL_COMMON_MISTAKES,
          prePostRecords: INITIAL_PRE_POST_RECORDS,
          artifacts: INITIAL_ARTIFACTS,
          interestLogs: INITIAL_INTEREST_LOGS,
          errorCodeStats: INITIAL_ERROR_CODE_STATS,
          aiHintUsageLogs: [],
          errorCorrectionLogs: [],
          classes: ['7A1', '7A2', '7A3'],
          isDemoMode: true,
        });
      }
    }),
    {
      name: 'funham-evidence-store-v2',
    }
  )
);
