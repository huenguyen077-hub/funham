export type ErrorCode = 
  | 'E01' // Thiếu dấu bằng đầu công thức
  | 'E02' // Sai tên hàm
  | 'E03' // Thiếu hoặc thừa dấu ngoặc
  | 'E04' // Sai cách viết vùng dữ liệu
  | 'E05' // Sai dấu phân cách đối số
  | 'E06' // Chọn hàm không phù hợp yêu cầu bài toán
  | 'E07' // Chọn sai ô hoặc vùng dữ liệu
  | 'E08' // Nhầm lẫn công dụng của SUM, AVERAGE, MAX, MIN
  | 'E09' // Hiểu sai kết quả tính toán
  | 'E10'; // Lỗi khác cần giáo viên xem xét

export interface ErrorCodeStats {
  code: ErrorCode;
  title: string;
  category: string;
  count: number;
  resolvedCount: number;
  percentage: number;
}

export interface PedagogicalEvidenceSummary {
  totalCorrectAnswers: number;
  totalAttempts: number;
  overallAccuracyRate: number; // percentage (e.g. 78.5%)
  averageCompletionRate: number; // percentage (e.g. 84.2%)
  preTestAverage: number; // e.g. 4.8 / 10
  postTestAverage: number; // e.g. 8.6 / 10
  learningGainPercent: number; // +79.1%
  totalArtifactsSubmitted: number;
  averageInterestScore: number; // 4.7 / 5.0
  totalStudentsSampled: number;
  // FUNHAM AI V2.0 Additions
  totalAiHintsUsed: number;
  tier1HintsCount: number; // Gợi mở
  tier2HintsCount: number; // Định hướng
  tier3HintsCount: number; // Giải thích
  totalErrorsDetected: number;
  totalErrorsSelfCorrected: number;
  selfCorrectionSuccessRate: number; // %
  isDemoMode: boolean;
}

export interface StudentAttemptStat {
  studentId: string;
  studentName: string;
  className: string;
  correctAnswers: number;
  totalAttempts: number;
  accuracyRate: number; // %
  completionRate: number; // %
  preTestScore: number;
  postTestScore: number;
  deltaScore: number;
  commonMistakesCount: number;
  artifactsCount: number;
  interestRating: number; // 1 to 5
  // FUNHAM AI V2.0 metrics
  aiHintsRequested: number;
  errorsResolved: number;
  selfCorrectionRate: number; // %
}

export interface CommonMistakeDetail {
  id: string;
  topic: 'SUM' | 'AVERAGE' | 'MAX' | 'MIN' | 'COUNT' | 'SYNTAX';
  title: string;
  mistakePattern: string; // e.g. =SUM(B2-B8)
  correctPattern: string; // e.g. =SUM(B2:B8)
  errorCategory: 'Ký hiệu vùng ô' | 'Dấu bằng đầu câu' | 'Chính tả tên hàm' | 'Cặp ngoặc đơn' | 'Đối số rời rạc' | 'Lựa chọn sai hàm';
  errorCode?: ErrorCode;
  occurrenceCount: number;
  percentageOfAllErrors: number;
  causeAnalysis: string; // Phân tích nguyên nhân sư phạm
  remedialStrategy: string; // Giải pháp khắc phục của giáo viên
}

export interface PrePostComparisonRecord {
  id: string;
  studentName: string;
  className: string;
  preScore: number; // Điểm trước tác động (thang 10)
  postScore: number; // Điểm sau tác động (thang 10)
  delta: number;
  gainPercent?: number; // Normalized learning gain g = (Post - Pre) / (10 - Pre) * 100%
  levelBefore: 'Chưa đạt' | 'Cần cố gắng' | 'Khá' | 'Tốt';
  levelAfter: 'Chưa đạt' | 'Cần cố gắng' | 'Khá' | 'Tốt';
  timeGapDays: number;
  evaluationNote: string;
}

export interface PracticeArtifact {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  projectTitle: string; // e.g. "Bảng Điểm Học Kỳ 1 Lớp 7A1"
  category: 'Bảng điểm' | 'Kế hoạch nhỏ' | 'Theo dõi thể thao' | 'Quản lý thu chi' | 'Thời khóa biểu số';
  submittedAt: string;
  status: 'graded' | 'needs_revision' | 'approved';
  formulasUsed: string[]; // e.g. ["=SUM(B2:D2)", "=AVERAGE(B2:D2)", "=MAX(E2:E10)"]
  tablePreview: {
    headers: string[];
    rows: (string | number)[][];
  };
  rubrics: {
    correctSyntax: number; // /10
    properFunctionChoice: number; // /10
    dataOrganization: number; // /10
    totalScore: number; // /10
  };
  teacherFeedback: string;
}

export interface InterestMetricEntry {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  overallInterest: number; // 1 to 5
  criteria: {
    excitement: number; // Mức độ hào hứng (1-5)
    confidence: number; // Mức độ tự tin khi dùng hàm (1-5)
    gameAppeal: number; // Hấp dẫn từ game hóa (1-5)
    easeOfUse: number; // Dễ hiểu, dễ thao tác (1-5)
    continuedDesire: number; // Mong muốn tiếp tục dùng FUNHAM (1-5)
  };
  preferredFeature: string; // e.g. "4 Tầng học tập", "Săn lỗi", "Đua xe công thức", "Trợ lý AI sửa lỗi"
  studentComment: string;
  submittedAt: string;
}

export interface AiHintUsageRecord {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  errorCode: ErrorCode;
  hintTier: 1 | 2 | 3;
  formula: string;
  resolved: boolean;
  timestamp: string;
}

export interface ErrorCorrectionLog {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  errorCode: ErrorCode;
  errorTitle: string;
  initialFormula: string;
  correctedFormula: string;
  hintsUsedCount: number;
  isSuccessful: boolean;
  timestamp: string;
}

export interface AssessmentQuestion {
  id: string;
  type: 'multiple_choice' | 'formula_input' | 'bug_detect' | 'function_select' | 'result_explain';
  topic: 'SUM' | 'AVERAGE' | 'MAX' | 'MIN' | 'COUNT' | 'SYNTAX';
  title: string;
  prompt: string;
  tableData?: {
    headers: string[];
    rows: (string | number)[][];
  };
  options?: string[];
  correctAnswer: string;
  explanation: string;
  errorCodeTested?: ErrorCode;
}
