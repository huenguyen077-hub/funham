export type Role = 'student' | 'teacher' | 'admin';

export interface User {
  id: string;
  name: string;
  role: Role;
  avatar?: string;
}

export interface Student extends User {
  role: 'student';
  className: string;
  studentCode?: string;
  classId?: string;
  isDemo?: boolean;
  xp: number;
  level: number;
  score: number;
  streak: number;
  badges: string[]; // IDs of unlocked badges
  completedAssignments: string[];
  createdAt: string;
}

export interface Teacher extends User {
  role: 'teacher';
}

export type QuestionType = 'mcq' | 'fill_blank' | 'short_answer' | 'true_false' | 'matching' | 'ordering' | 'drag_drop';
export type QuestionDifficulty = 'nhan_biet' | 'thong_hieu' | 'van_dung' | 'van_dung_cao';
export type CognitiveLevel = 1 | 2 | 3 | 4 | 5 | 6;
export type QuestionTopic = 'SUM' | 'AVERAGE' | 'MIN' | 'MAX' | 'COUNT' | 'general';

export interface Question {
  id: string;
  type: QuestionType;
  content: string;
  options?: string[]; // For MCQ, True/False
  answer: string | string[]; // Correct answer(s)
  explanation: string;
  difficulty: QuestionDifficulty;
  cognitiveLevel?: CognitiveLevel;
  topic: QuestionTopic;
  points: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string; // Emoji or Lucide icon name
  condition: {
    type: 'xp' | 'lessons' | 'streak' | 'combo' | 'score';
    value: number;
  };
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  questionIds: string[];
  classIds: string[];
  studentIds?: string[];
  deadline?: string;
  status: 'active' | 'closed';
  createdAt: string;
}

export interface Exam {
  id: string;
  title: string;
  questions: string[];
  duration: number; // in minutes
  totalPoints: number;
  startTime?: string;
  endTime?: string;
}
