import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useDataStore } from '../store/dataStore';
import { useEvidenceStore } from '../store/evidenceStore';
import { Student } from '../types';
import { syncRegisterStudent } from '../services/databaseService';
import { isSupabaseConfigured } from '../services/supabaseClient';
import { SupabaseConfigModal } from '../components/SupabaseConfigModal';
import { CrossDeviceShareModal } from '../components/CrossDeviceShareModal';
import { Database, ShieldCheck, Sparkles, User, School, Key, Smartphone, QrCode } from 'lucide-react';

export function LoginPage() {
  const [role, setRole] = useState<'student' | 'teacher'>('student');
  const [isStudentOnlyMode, setIsStudentOnlyMode] = useState(false);
  const [name, setName] = useState('');
  const [classCode, setClassCode] = useState('7A1');
  const [customClass, setCustomClass] = useState('');
  const [studentCode, setStudentCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('student_only') === 'true') {
      setIsStudentOnlyMode(true);
      setRole('student');
    }
  }, []);

  // Force student role if in student-only mode
  useEffect(() => {
    if (isStudentOnlyMode && role !== 'student') {
      setRole('student');
    }
  }, [isStudentOnlyMode, role]);

  const { login, loginAs } = useAuthStore();
  const { students, addStudent } = useDataStore();
  const { registerStudent } = useEvidenceStore();
  const navigate = useNavigate();

  const activeClassCode = classCode === 'OTHER' ? customClass.trim().toUpperCase() : classCode;

  const handleStudentLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !activeClassCode) return;

    // Normalize student code or generate default if empty
    const normStudentCode = studentCode.trim() 
      ? studentCode.trim().toUpperCase() 
      : `HS_${name.trim().toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8) || '01'}`;

    setIsSubmitting(true);

    try {
      // 1. Sync & Register in Supabase / central storage
      const stdRecord = await syncRegisterStudent(activeClassCode, normStudentCode, name.trim());

      const loggedInStudent: Student = {
        id: stdRecord.id || `hs_${Date.now()}`,
        studentCode: normStudentCode,
        name: name.trim(),
        role: 'student',
        className: activeClassCode,
        xp: 250,
        level: 2,
        score: 80,
        streak: 1,
        badges: ['first_step'],
        completedAssignments: [],
        createdAt: stdRecord.created_at || new Date().toISOString(),
        isDemo: false,
      };

      // Add to local data store if not present
      const existing = students.find(s => s.id === loggedInStudent.id || (s.studentCode === normStudentCode && s.className === activeClassCode));
      if (!existing) {
        addStudent(loggedInStudent);
      }

      loginAs(loggedInStudent);

      // Register in local evidence store for immediate UI updates
      registerStudent({
        studentId: loggedInStudent.id,
        studentName: loggedInStudent.name,
        className: loggedInStudent.className,
        xp: loggedInStudent.xp,
      });

      navigate('/student');
    } catch (err) {
      console.error('Error during student login:', err);
      // Fallback local login if network fails
      const fallbackStudent: Student = {
        id: `hs_${Date.now()}`,
        studentCode: normStudentCode,
        name: name.trim(),
        role: 'student',
        className: activeClassCode,
        xp: 250,
        level: 2,
        score: 80,
        streak: 1,
        badges: ['first_step'],
        completedAssignments: [],
        createdAt: new Date().toISOString(),
        isDemo: false,
      };
      addStudent(fallbackStudent);
      loginAs(fallbackStudent);
      navigate('/student');
    } finally {
      setIsSubmitting(false);
    }
  };

  const [teacherPassword, setTeacherPassword] = useState('');
  const [passwordError, setPasswordError] = useState(false);

  const handleTeacherLogin = () => {
    // Hardcoded teacher password for now
    if (teacherPassword === 'GV_FUNHAM_2026') {
      login('gv1', 'teacher');
      navigate('/teacher');
    } else {
      setPasswordError(true);
      setTeacherPassword('');
    }
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 flex flex-col items-center justify-center p-4 md:p-6 text-slate-900">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl"
      >
        <div className="text-center mb-8">
          <h1 
            className="text-5xl md:text-7xl font-black tracking-wider mb-3 uppercase text-blue-700 flex items-center justify-center gap-3 drop-shadow-2xl"
            style={{
              textShadow: '2px 2px 0px #1e1b4b, 4px 4px 0px #312e81, 6px 6px 0px #4f46e5, 0 15px 30px rgba(0,0,0,0.3)'
            }}
          >
            <span>📊</span> <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 font-extrabold">FUNHÀM</span> <span>🧮</span>
          </h1>
          <p className="text-base md:text-xl font-black text-slate-950 uppercase tracking-wide bg-blue-200 py-2.5 px-6 rounded-2xl border-3 border-b-6 border-indigo-700 shadow-xl inline-block">
            ✨ HỌC HÀM – CHƠI VUI – LÀM CHỦ BẢNG TÍNH 🚀
          </p>

          {!isStudentOnlyMode && (
            <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black ${
                isSupabaseConfigured() 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                <Database className="w-3.5 h-3.5" />
                <span>{isSupabaseConfigured() ? 'Đã kết nối Supabase Cloud' : 'Chế độ lưu trữ thiết bị'}</span>
              </span>

              <button
                type="button"
                onClick={() => setShowShareModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-blue-100 hover:bg-blue-200 text-blue-900 border border-blue-300 transition-all cursor-pointer shadow-sm active:scale-95"
              >
                <QrCode className="w-3.5 h-3.5 text-blue-700" />
                <span>📱 Quét QR Học Trên Điện Thoại</span>
              </button>
            </div>
          )}
        </div>

        <div className="bg-white border-4 border-b-8 border-indigo-900 rounded-3xl shadow-[0_25px_60px_rgba(79,70,229,0.2)] p-6 md:p-12 text-slate-900">
          {!isStudentOnlyMode && (
            <div className="flex gap-4 mb-8">
              <button
                onClick={() => { setRole('student'); setPasswordError(false); }}
                className={`flex-1 py-4 font-black text-lg md:text-xl rounded-2xl transition-all border-3 border-b-6 uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer ${
                  role === 'student' 
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white border-blue-950 shadow-xl scale-105' 
                    : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                }`}
              >
                <span>🎓</span> HỌC SINH
              </button>
              <button
                onClick={() => { setRole('teacher'); setPasswordError(false); }}
                className={`flex-1 py-4 font-black text-lg md:text-xl rounded-2xl transition-all border-3 border-b-6 uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer ${
                  role === 'teacher' 
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white border-purple-950 shadow-xl scale-105' 
                    : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                }`}
              >
                <span>👩‍🏫</span> GIÁO VIÊN
              </button>
            </div>
          )}

          <div className="space-y-6">
            {role === 'student' ? (
              <form onSubmit={handleStudentLogin} className="space-y-5">
                {/* Lớp học */}
                <div>
                  <label className="block text-sm font-black text-indigo-950 uppercase tracking-wider mb-1.5 flex items-center gap-2">
                    <School className="w-4 h-4 text-blue-600" />
                    <span>Lớp học</span>
                  </label>
                  <div className="grid grid-cols-4 gap-2 mb-2">
                    {['7A1', '7A2', '7A3'].map((c) => (
                      <button
                        type="button"
                        key={c}
                        onClick={() => setClassCode(c)}
                        className={`py-2.5 rounded-xl font-black text-sm uppercase transition-all border-2 ${
                          classCode === c
                            ? 'bg-blue-600 text-white border-blue-900 shadow-md'
                            : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                        }`}
                      >
                        {c}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setClassCode('OTHER')}
                      className={`py-2.5 rounded-xl font-black text-sm uppercase transition-all border-2 ${
                        classCode === 'OTHER'
                          ? 'bg-purple-600 text-white border-purple-900 shadow-md'
                          : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      Khác
                    </button>
                  </div>

                  {classCode === 'OTHER' && (
                    <input
                      type="text"
                      value={customClass}
                      onChange={(e) => setCustomClass(e.target.value)}
                      placeholder="Nhập mã lớp (VD: 7A4, 7B1...)"
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-indigo-900 font-black text-base text-slate-900 placeholder:text-slate-400"
                      required
                    />
                  )}
                </div>

                {/* Mã học sinh */}
                <div>
                  <label className="block text-sm font-black text-indigo-950 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Key className="w-4 h-4 text-amber-600" />
                      <span>Mã định danh học sinh (STT / Mã số)</span>
                    </span>
                    <span className="text-[11px] text-slate-500 font-normal lowercase">(duy nhất trong lớp)</span>
                  </label>
                  <input
                    type="text"
                    value={studentCode}
                    onChange={(e) => setStudentCode(e.target.value)}
                    placeholder="VD: HS01, HS02, hoặc 01, 02..."
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-indigo-900 focus:border-blue-600 focus:bg-white outline-none font-mono font-bold text-base text-slate-900 placeholder:text-slate-400 shadow-inner"
                    required
                  />
                  <p className="text-[11px] text-slate-500 font-bold mt-1">
                    💡 Dùng mã này để hệ thống ghép đúng bài kiểm tra đầu vào và đầu ra của em.
                  </p>
                </div>

                {/* Họ và tên */}
                <div>
                  <label className="block text-sm font-black text-indigo-950 uppercase tracking-wider mb-1.5 flex items-center gap-2">
                    <User className="w-4 h-4 text-emerald-600" />
                    <span>Họ và tên học sinh</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="VD: Nguyễn Văn An"
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-indigo-900 focus:border-blue-600 focus:bg-white outline-none font-black text-base text-slate-900 placeholder:text-slate-400 shadow-inner"
                    required
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full py-4.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-8 border-emerald-950 shadow-2xl hover:scale-102 active:scale-98 transition-all text-lg mt-3 flex items-center justify-center gap-3 cursor-pointer"
                  style={{ textShadow: '0 2px 4px rgba(0,0,0,0.4)' }}
                >
                  <span>🚀</span> {isSubmitting ? 'ĐANG KẾT NỐI HỆ THỐNG...' : 'VÀO HỌC VÀ LÀM BÀI'} <span>🎯</span>
                </button>
              </form>
            ) : (
              <div className="space-y-4">
                <h3 className="font-black text-indigo-950 text-base md:text-lg mb-2 uppercase tracking-wide flex items-center gap-2">
                  <span>✨</span> Cổng quản trị dành cho Giáo viên:
                </h3>

                <div className="space-y-2">
                   <input
                     type="password"
                     value={teacherPassword}
                     onChange={(e) => { setTeacherPassword(e.target.value); setPasswordError(false); }}
                     placeholder="Nhập mật khẩu giáo viên"
                     className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 font-bold text-base text-slate-900 placeholder:text-slate-400 ${passwordError ? 'border-red-500' : 'border-indigo-900'}`}
                     required
                   />
                   {passwordError && <p className="text-red-500 text-xs font-bold">Mật khẩu không đúng!</p>}
                </div>

                <div className="space-y-2">
                   <input
                     type="password"
                     value={teacherPassword}
                     onChange={(e) => { setTeacherPassword(e.target.value); setPasswordError(false); }}
                     placeholder="Nhập mật khẩu giáo viên"
                     className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 font-bold text-base text-slate-900 placeholder:text-slate-400 ${passwordError ? 'border-red-500' : 'border-indigo-900'}`}
                     required
                   />
                   {passwordError && <p className="text-red-500 text-xs font-bold">Mật khẩu không đúng!</p>}
                </div>

                <button
                  onClick={handleTeacherLogin}
                  className="w-full text-left p-5 rounded-2xl bg-purple-50 border-3 border-b-6 border-purple-900 hover:border-purple-700 transition-all shadow-md group cursor-pointer"
                >
                  <div className="font-black text-lg text-purple-950 group-hover:text-purple-800 flex items-center gap-2">
                    <span>👩‍🏫</span> GV001 - Giáo viên Tin học 7
                  </div>
                  <div className="text-xs text-purple-900 font-bold mt-1 flex items-center gap-2">
                    <span>🔑</span> Vào thẳng Dashboard theo dõi kết quả thực tế của học sinh
                  </div>
                </button>

                <div className="p-4 rounded-2xl bg-slate-50 border-2 border-slate-200 flex items-center justify-between">
                  <div className="text-xs">
                    <div className="font-black text-slate-800">Cấu hình kết nối Supabase Cloud</div>
                    <div className="text-slate-500 font-bold">
                      {isSupabaseConfigured() ? 'Đã kết nối cơ sở dữ liệu trực tuyến' : 'Chưa cấu hình Supabase'}
                    </div>
                  </div>
                  <button
                    onClick={() => setShowConfigModal(true)}
                    className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <Database className="w-3.5 h-3.5" />
                    <span>Cấu hình DB</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Supabase Config Modal */}
      <SupabaseConfigModal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
      />

      {/* Cross-Device Share / QR Modal */}
      <CrossDeviceShareModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title="KẾT NỐI HỌC TRÊN ĐIỆN THOẠI & MÁY TÍNH"
        defaultRole="student"
      />
    </div>
  );
}

