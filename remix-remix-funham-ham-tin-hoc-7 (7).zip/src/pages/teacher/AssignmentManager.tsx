import React, { useState } from 'react';
import { Target, Plus } from 'lucide-react';
import { useDataStore } from '../../store/dataStore';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Assignment } from '../../types';

export function AssignmentManager() {
  const { assignments, questions, addAssignment, updateAssignment, deleteAssignment } = useDataStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [detailAssignment, setDetailAssignment] = useState<Assignment | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedClass, setSelectedClass] = useState('7A1');
  const [selectedQuestions, setSelectedQuestions] = useState<string[]>([]);

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || selectedQuestions.length === 0) {
      alert('Vui lòng nhập tên bài tập và chọn ít nhất 1 câu hỏi!');
      return;
    }

    const newAssignment: Assignment = {
      id: 'asm_' + Date.now(),
      title,
      description,
      classIds: [selectedClass],
      questionIds: selectedQuestions,
      status: 'active',
      createdAt: new Date().toISOString()
    };

    addAssignment(newAssignment);
    setIsModalOpen(false);
    setTitle('');
    setDescription('');
    setSelectedQuestions([]);
  };

  const toggleQuestionSelection = (qId: string) => {
    setSelectedQuestions(prev => 
      prev.includes(qId) ? prev.filter(id => id !== qId) : [...prev, qId]
    );
  };

  const toggleAssignmentStatus = (asm: Assignment) => {
    const newStatus = asm.status === 'active' ? 'closed' : 'active';
    updateAssignment(asm.id, { status: newStatus });
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 p-8 rounded-3xl border-4 border-b-8 border-teal-950 shadow-2xl text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 
            className="text-4xl md:text-5xl font-black uppercase tracking-wider mb-2 text-yellow-300"
            style={{ textShadow: '3px 3px 0px #042f2e, 6px 6px 15px rgba(0,0,0,0.5)' }}
          >
            🎯 GIAO BÀI TẬP 📝
          </h1>
          <p className="text-emerald-100 font-bold text-lg uppercase tracking-wide">
            ✨ QUẢN LÝ VÀ GIAO BÀI TẬP TRỰC TUYẾN CHO HỌC SINH. 🚀
          </p>
        </div>
        <Button 
          onClick={() => setIsModalOpen(true)}
          className="gap-2 bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-black uppercase px-6 py-4 rounded-2xl border-3 border-b-6 border-amber-700 shadow-xl active:translate-y-1"
        >
          <Plus className="w-6 h-6 stroke-[3]" /> Tạo bài tập mới
        </Button>
      </div>

      {/* Modal Create Assignment */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border-4 border-b-8 border-teal-950 p-8 max-w-2xl w-full shadow-2xl my-8">
            <div className="flex justify-between items-center mb-6 border-b-2 border-slate-100 pb-4">
              <h2 className="text-2xl font-black uppercase text-teal-900 flex items-center gap-2">
                <span>🎯</span> TẠO BÀI TẬP MỚI CHO HỌC SINH
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-red-100 text-slate-700 hover:text-red-600 font-black text-xl flex items-center justify-center border-2 border-slate-300 transition-colors"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAssignment} className="space-y-6">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Tiêu đề bài tập</label>
                <input 
                  required
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Nhập tên bài tập (VD: Kiểm tra 15 phút hàm SUM & AVERAGE)..."
                  className="w-full p-4 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-teal-600 shadow-inner"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Mô tả chi tiết</label>
                <textarea 
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Nhập mô tả hoặc hướng dẫn làm bài cho học sinh..."
                  className="w-full p-4 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-teal-600 shadow-inner resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Giao cho lớp</label>
                <select 
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="w-full p-3.5 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-teal-600 shadow-sm"
                >
                  <option value="7A1">LỚP 7A1</option>
                  <option value="7A2">LỚP 7A2</option>
                  <option value="7A3">LỚP 7A3</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">
                  Chọn câu hỏi từ kho ({selectedQuestions.length} đã chọn)
                </label>
                <div className="max-h-60 overflow-y-auto space-y-2 p-3 bg-slate-50 border-3 border-slate-300 rounded-2xl">
                  {questions.map(q => {
                    const isSelected = selectedQuestions.includes(q.id);
                    return (
                      <div 
                        key={q.id}
                        onClick={() => toggleQuestionSelection(q.id)}
                        className={`p-3 rounded-xl border-2 cursor-pointer flex items-center justify-between transition-all ${
                          isSelected ? 'bg-teal-50 border-teal-500 font-bold text-teal-900 shadow-sm' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black ${isSelected ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
                            {isSelected ? '✓' : '+'}
                          </span>
                          <span className="text-sm font-bold truncate max-w-md">{q.content}</span>
                        </div>
                        <Badge variant="purple" className="text-xs">{q.topic}</Badge>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-4 pt-4 border-t-2 border-slate-100">
                <Button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-black uppercase px-6 py-3 rounded-2xl border-3 border-b-6 border-slate-400"
                >
                  Hủy bỏ
                </Button>
                <Button 
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black uppercase px-8 py-3 rounded-2xl border-3 border-b-6 border-emerald-900 shadow-xl"
                >
                  Giao bài tập
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Detail Assignment */}
      {detailAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border-4 border-b-8 border-teal-950 p-8 max-w-3xl w-full shadow-2xl my-8">
            <div className="flex justify-between items-center mb-6 border-b-2 border-slate-100 pb-4">
              <div>
                <div className="flex gap-2 mb-2">
                  <Badge variant={detailAssignment.status === 'active' ? 'success' : 'default'} className="font-black uppercase">
                    {detailAssignment.status === 'active' ? '🟢 ĐANG MỞ' : '🔴 ĐÃ ĐÓNG'}
                  </Badge>
                  {detailAssignment.classIds.map(c => (
                    <Badge key={c} variant="blue" className="font-black uppercase">LỚP {c}</Badge>
                  ))}
                </div>
                <h2 className="text-2xl font-black uppercase text-teal-900">{detailAssignment.title}</h2>
              </div>
              <button 
                onClick={() => setDetailAssignment(null)}
                className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-red-100 text-slate-700 hover:text-red-600 font-black text-xl flex items-center justify-center border-2 border-slate-300 transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="space-y-6">
              <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 block mb-1">Mô tả bài tập:</span>
                <p className="text-slate-800 font-medium">{detailAssignment.description || 'Không có mô tả chi tiết.'}</p>
              </div>

              <div>
                <h3 className="text-lg font-black uppercase text-slate-800 mb-3 flex items-center gap-2">
                  <span>📚</span> Danh sách câu hỏi trong bài ({detailAssignment.questionIds.length} câu)
                </h3>
                <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                  {detailAssignment.questionIds.map((qId, idx) => {
                    const q = questions.find(item => item.id === qId);
                    if (!q) return null;
                    return (
                      <div key={q.id} className="p-4 bg-white border-2 border-slate-200 rounded-2xl shadow-sm">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-black text-purple-700 uppercase bg-purple-50 px-3 py-1 rounded-lg">Câu {idx + 1} - {q.topic}</span>
                          <span className="text-xs font-black text-amber-700 bg-amber-50 px-3 py-1 rounded-lg">⭐ {q.points} điểm</span>
                        </div>
                        <p className="font-black text-slate-900">{q.content}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t-2 border-slate-100">
                <Button 
                  onClick={() => {
                    if (confirm('Bạn có chắc chắn muốn xóa bài tập này?')) {
                      deleteAssignment(detailAssignment.id);
                      setDetailAssignment(null);
                    }
                  }}
                  className="bg-red-50 hover:bg-red-100 text-red-700 font-black uppercase px-6 py-3 rounded-2xl border-2 border-red-300"
                >
                  Xóa bài tập
                </Button>
                <Button 
                  onClick={() => setDetailAssignment(null)}
                  className="bg-teal-600 hover:bg-teal-700 text-white font-black uppercase px-8 py-3 rounded-2xl border-3 border-b-6 border-teal-900 shadow-xl"
                >
                  Đóng cửa sổ
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-6">
        {assignments.map(asm => (
          <div key={asm.id} className="bg-white rounded-3xl p-6 border-4 border-b-8 border-slate-300 shadow-xl hover:border-emerald-500 transition-all">
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div>
                <div className="flex gap-3 mb-3">
                  <Badge variant={asm.status === 'active' ? 'success' : 'default'} className="font-black uppercase">
                    {asm.status === 'active' ? '🟢 ĐANG MỞ' : '🔴 ĐÃ ĐÓNG'}
                  </Badge>
                  {asm.classIds.map(c => (
                    <Badge key={c} variant="blue" className="font-black uppercase">LỚP {c}</Badge>
                  ))}
                </div>
                <h3 className="text-2xl font-black uppercase tracking-wide text-slate-900 mb-2">{asm.title}</h3>
                <p className="text-slate-600 font-medium">{asm.description}</p>
              </div>
              <div className="flex flex-col gap-2.5 shrink-0">
                <Button 
                  onClick={() => setDetailAssignment(asm)}
                  variant="outline" 
                  size="sm" 
                  className="font-black uppercase border-2 border-slate-300 rounded-xl hover:bg-slate-100"
                >
                  Xem chi tiết
                </Button>
                <Button 
                  onClick={() => toggleAssignmentStatus(asm)}
                  size="sm" 
                  className={asm.status === 'active' 
                    ? "bg-red-50 text-red-700 font-black uppercase hover:bg-red-100 border-2 border-red-200 rounded-xl shadow-none"
                    : "bg-emerald-50 text-emerald-700 font-black uppercase hover:bg-emerald-100 border-2 border-emerald-200 rounded-xl shadow-none"
                  }
                >
                  {asm.status === 'active' ? 'Đóng bài' : 'Mở lại'}
                </Button>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t-2 border-slate-100 flex gap-12">
              <div>
                <div className="text-xs font-black text-slate-400 uppercase tracking-widest">SỐ CÂU HỎI</div>
                <div className="text-xl font-black text-emerald-600">{asm.questionIds.length} CÂU</div>
              </div>
              <div>
                <div className="text-xs font-black text-slate-400 uppercase tracking-widest">NGÀY TẠO</div>
                <div className="text-xl font-black text-slate-800">
                  {new Date(asm.createdAt).toLocaleDateString('vi-VN')}
                </div>
              </div>
            </div>
          </div>
        ))}

        {assignments.length === 0 && (
          <div className="text-center py-16 text-slate-500 font-black uppercase tracking-wider bg-white rounded-3xl border-4 border-dashed border-slate-300">
            Chưa có bài tập nào được tạo.
          </div>
        )}
      </div>
    </div>
  );
}
