import { useState, useEffect } from 'react';
import { useDataStore } from '../../store/dataStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { calculateLevel, cn } from '../../utils';
import { StudentResultModal } from '../../components/StudentResultModal';
import { 
  syncFetchTeacherDashboardData, 
  syncFetchClasses, 
  TeacherStudentAggregated, 
  ClassRecord 
} from '../../services/databaseService';
import { isSupabaseConfigured } from '../../services/supabaseClient';
import { 
  Users, 
  Search, 
  Filter, 
  Eye, 
  TrendingUp, 
  Sparkles, 
  FileText, 
  CheckCircle2, 
  Printer, 
  Download,
  RefreshCw,
  Database,
  Wifi,
  WifiOff
} from 'lucide-react';

export function StudentManagement() {
  const { students } = useDataStore();
  const { studentsStat, prePostRecords, classes } = useEvidenceStore();

  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);
  const [filterClass, setFilterClass] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedStudentForModal, setSelectedStudentForModal] = useState<string | null>(null);
  const [realStudents, setRealStudents] = useState<TeacherStudentAggregated[]>([]);
  const [classList, setClassList] = useState<ClassRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const cls = await syncFetchClasses();
      setClassList(cls);

      if (isSupabaseConfigured()) {
        const stats = await syncFetchTeacherDashboardData(filterClass === 'all' ? 'ALL' : filterClass, isDemoMode);
        setRealStudents(stats.students);
      }
    } catch (e) {
      console.error('Error fetching students in StudentManagement:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [filterClass, isDemoMode]);

  const availableClasses = ['all', ...Array.from(new Set([...classList.map(c => c.class_code), ...classes, ...students.map(s => s.className)]))];

  // Combined data depending on mode and supabase
  let displayedList: any[] = [];

  if (isSupabaseConfigured()) {
    displayedList = realStudents.map(s => ({
      id: s.student_id,
      studentCode: s.student_code,
      name: s.display_name,
      className: s.class_code,
      preScore: s.pre_score !== null ? s.pre_score : '-',
      postScore: s.post_score !== null ? s.post_score : '-',
      delta: s.delta !== null ? (s.delta >= 0 ? `+${s.delta}` : `${s.delta}`) : '-',
      accuracy: s.accuracy_rate,
      aiHints: s.ai_hints_used,
      selfCorrection: s.self_correction_rate,
      isDemo: s.is_demo,
      xp: 250 + (s.completed_tasks * 50)
    }));
  } else if (isDemoMode) {
    displayedList = students.map((s) => {
      const stat = studentsStat.find(st => st.studentName.toLowerCase() === s.name.toLowerCase());
      const pp = prePostRecords.find(p => p.studentName.toLowerCase() === s.name.toLowerCase());
      const preScore = pp ? pp.preScore : (stat ? stat.preTestScore : 5.0);
      const postScore = pp ? pp.postScore : (stat ? stat.postTestScore : 9.0);
      const delta = Number((postScore - preScore).toFixed(1));
      return {
        ...s,
        studentCode: `HS_${s.id.slice(-4)}`,
        preScore,
        postScore,
        delta: delta >= 0 ? `+${delta}` : `${delta}`,
        accuracy: stat ? stat.accuracyRate : 88.0,
        aiHints: stat ? (stat.aiHintsRequested || 3) : 3,
        selfCorrection: stat ? (stat.selfCorrectionRate || 85.0) : 85.0,
        isDemo: true
      };
    });
  } else {
    // Real mode without Supabase - only show students created locally
    const INITIAL_DEMO_IDS = new Set([
      'hs_baonam', 'hs_01', 'hs_02', 'hs_03', 'hs_04', 'hs_05',
      'hs_06', 'hs_07', 'hs_08', 'hs_09', 'hs_10', 'hs_11',
      'hs_12', 'hs_13', 'hs_14', 'hs_15', 'hs_16', 'hs_17',
      'hs_18', 'hs_19', 'hs_20'
    ]);
    displayedList = students.filter(s => !(s as any).isDemo && !INITIAL_DEMO_IDS.has(s.id)).map(s => {
      const stat = studentsStat.find(st => st.studentName.toLowerCase() === s.name.toLowerCase());
      const pp = prePostRecords.find(p => p.studentName.toLowerCase() === s.name.toLowerCase());
      return {
        ...s,
        studentCode: (s as any).studentCode || `HS_${s.id.slice(-4)}`,
        preScore: pp ? pp.preScore : (stat ? stat.preTestScore : '-'),
        postScore: pp ? pp.postScore : (stat ? stat.postTestScore : '-'),
        delta: pp ? `${pp.delta >= 0 ? '+' : ''}${pp.delta}` : '-',
        accuracy: stat ? stat.accuracyRate : 0,
        aiHints: stat ? stat.aiHintsRequested : 0,
        selfCorrection: stat ? stat.selfCorrectionRate : 100,
        isDemo: false
      };
    });
  }

  const filtered = displayedList.filter((s) => {
    const matchClass = filterClass === 'all' || s.className.toUpperCase() === filterClass.toUpperCase();
    const matchSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        (s.studentCode && s.studentCode.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchClass && matchSearch;
  });

  const handleExportCSV = () => {
    const headers = [
      'STT',
      'Ma HS',
      'Ho va ten',
      'Lop',
      'Cap do',
      'XP',
      'Diem Dau vao (Pre-Test)',
      'Diem Dau ra (Post-Test)',
      'Do tang truong diem (Delta)',
      'Do chinh xac (%)',
      'Luot hoi AI',
      'Ty le tu sua loi (%)',
      'Che do du lieu'
    ];

    const rows = filtered.map((s, idx) => [
      idx + 1,
      `"${s.studentCode || ''}"`,
      `"${s.name}"`,
      s.className,
      `"Level ${calculateLevel(s.xp || 250)}"`,
      s.xp || 250,
      s.preScore,
      s.postScore,
      s.delta,
      `${s.accuracy}%`,
      s.aiHints,
      `${s.selfCorrection}%`,
      `"${s.isDemo ? 'DEMO' : 'CHINH THUC'}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Ket_Qua_Hoc_Sinh_TinHoc7_${filterClass}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 p-8 rounded-3xl border-4 border-b-8 border-indigo-950 shadow-2xl text-white relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase">
              <Users className="w-4 h-4 text-yellow-300" />
              <span>CỔNG QUẢN LÝ HỒ SƠ NĂNG LỰC HỌC SINH</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black uppercase tracking-wider text-yellow-300 drop-shadow-md">
              👥 QUẢN LÝ HỌC SINH TIN HỌC 7
            </h1>
            <p className="text-blue-100 text-xs md:text-sm font-bold max-w-2xl leading-relaxed">
              Theo dõi chi tiết điểm số, tỉ lệ tự sửa lỗi và hồ sơ năng lực của từng học sinh đồng bộ từ tất cả thiết bị làm bài.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <Button
              onClick={handleExportCSV}
              disabled={filtered.length === 0}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase px-5 py-3 rounded-2xl shadow-lg border-2 border-b-4 border-emerald-800 flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Xuất CSV</span>
            </Button>

            <Button
              onClick={loadData}
              disabled={isLoading}
              className="bg-white/20 hover:bg-white/30 text-white font-black text-xs uppercase px-4 py-3 rounded-2xl border border-white/30 flex items-center gap-2 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Làm mới</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Mode switch & stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white rounded-2xl border-2 border-slate-200 shadow-sm">
        <div className="flex items-center gap-2">
          <span className="text-xs font-black uppercase text-slate-500">Chế độ hiển thị:</span>
          <button
            onClick={() => setIsDemoMode(false)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase cursor-pointer ${
              !isDemoMode ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Dữ liệu thật (Chính thức)
          </button>
          <button
            onClick={() => setIsDemoMode(true)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase cursor-pointer ${
              isDemoMode ? 'bg-amber-500 text-slate-950 shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Dữ liệu Demo
          </button>
        </div>

        <div className="text-xs font-bold text-slate-500 flex items-center gap-3">
          <span>{isSupabaseConfigured() ? '🟢 Supabase Cloud' : '🟡 Cục bộ'}</span>
          <span>•</span>
          <span>Hiển thị <strong>{filtered.length}</strong> học sinh</span>
        </div>
      </div>

      {/* Filter and Table container */}
      <div className="bg-white rounded-3xl border-4 border-b-8 border-slate-300 shadow-xl p-6 md:p-8 space-y-6">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative flex-1 w-full">
            <Search className="w-5 h-5 absolute left-3.5 top-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo tên hoặc mã học sinh..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-50 border-2 border-slate-200 font-bold text-sm focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
              className="w-full md:w-auto px-4 py-3 rounded-2xl bg-slate-50 border-2 border-slate-200 font-black text-xs uppercase focus:border-blue-500 focus:outline-none"
            >
              {availableClasses.map((c) => (
                <option key={c} value={c}>
                  {c === 'all' ? 'Tất cả các lớp' : `Lớp ${c}`}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Detailed Table */}
        <div className="overflow-x-auto border-2 border-slate-200 rounded-2xl shadow-inner">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-black uppercase text-[11px] border-b border-slate-200">
                <th className="p-3.5">Mã số</th>
                <th className="p-3.5">Học sinh</th>
                <th className="p-3.5">Lớp</th>
                <th className="p-3.5 text-center">Đầu vào (Pre)</th>
                <th className="p-3.5 text-center">Đầu ra (Post)</th>
                <th className="p-3.5 text-center">Tăng trưởng (Δ)</th>
                <th className="p-3.5 text-center">Độ chính xác</th>
                <th className="p-3.5 text-center">Lượt hỏi AI</th>
                <th className="p-3.5 text-center">Tự sửa lỗi</th>
                <th className="p-3.5 text-center">Chi tiết kết quả</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((student) => (
                <tr 
                  key={student.id} 
                  className="hover:bg-blue-50/50 transition-colors cursor-pointer font-bold"
                  onClick={() => setSelectedStudentForModal(student.name)}
                >
                  <td className="p-3.5 font-mono text-slate-400 text-[11px]">
                    {student.studentCode || '-'}
                  </td>

                  <td className="p-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-600 text-white font-black text-sm flex items-center justify-center shrink-0 shadow-sm">
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-black text-slate-900 text-sm">{student.name}</div>
                        {student.isDemo && (
                          <span className="text-[10px] text-amber-600 font-black uppercase">Demo</span>
                        )}
                      </div>
                    </div>
                  </td>

                  <td className="p-3.5">
                    <span className="px-2.5 py-1 rounded-lg bg-blue-100 text-blue-800 text-[11px] font-black">
                      {student.className}
                    </span>
                  </td>

                  <td className="p-3.5 text-center font-mono font-black text-amber-700 text-sm">
                    {student.preScore}
                  </td>

                  <td className="p-3.5 text-center font-mono font-black text-emerald-700 text-sm">
                    {student.postScore}
                  </td>

                  <td className="p-3.5 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-cyan-100 text-cyan-800 font-mono font-black text-xs">
                      {student.delta}
                    </span>
                  </td>

                  <td className="p-3.5 text-center font-mono text-slate-700">
                    {student.accuracy}%
                  </td>

                  <td className="p-3.5 text-center font-mono text-purple-700">
                    {student.aiHints} lượt
                  </td>

                  <td className="p-3.5 text-center">
                    <span className={cn(
                      "px-2.5 py-0.5 rounded-full text-xs font-mono font-black",
                      student.selfCorrection >= 80 ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                    )}>
                      {student.selfCorrection}%
                    </span>
                  </td>

                  <td className="p-3.5 text-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedStudentForModal(student.name);
                      }}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-[11px] uppercase shadow-sm flex items-center gap-1 mx-auto cursor-pointer transition-transform active:scale-95"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Xem Phiếu</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filtered.length === 0 && !isLoading && (
            <div className="text-center py-12 text-slate-500 font-medium space-y-2">
              <div className="text-3xl">📭</div>
              <div className="font-black text-slate-700 uppercase">
                {isDemoMode ? 'Không tìm thấy học sinh phù hợp' : 'CHƯA CÓ DỮ LIỆU HỌC SINH THỰC TẾ'}
              </div>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {isDemoMode 
                  ? 'Hãy thử đổi bộ lọc lớp hoặc tìm kiếm tên khác.'
                  : 'Chưa có học sinh nào đăng nhập và nộp bài. Bật chế độ "Dữ liệu Demo" để xem trước số liệu mẫu.'}
              </p>
            </div>
          )}

          {isLoading && (
            <div className="text-center py-12">
              <RefreshCw className="w-6 h-6 animate-spin text-blue-600 mx-auto" />
              <p className="text-xs text-slate-400 font-bold mt-2">Đang tải dữ liệu học sinh...</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal View for Individual Student Result */}
      {selectedStudentForModal && (
        <StudentResultModal
          studentName={selectedStudentForModal}
          onClose={() => setSelectedStudentForModal(null)}
        />
      )}
    </div>
  );
}
