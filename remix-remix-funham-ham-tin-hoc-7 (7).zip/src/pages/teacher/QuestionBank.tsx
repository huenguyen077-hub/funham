import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { useDataStore } from '../../store/dataStore';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Question } from '../../types';

export function QuestionBank() {
  const { questions, addQuestion, updateQuestion, deleteQuestion } = useDataStore();
  const [filterTopic, setFilterTopic] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);

  // Form state
  const [content, setContent] = useState('');
  const [topic, setTopic] = useState('SUM');
  const [difficulty, setDifficulty] = useState<'nhan_biet' | 'thong_hieu' | 'van_dung' | 'van_dung_cao'>('nhan_biet');
  const [type, setType] = useState<'mcq' | 'fill_blank' | 'matching' | 'ordering' | 'drag_drop' | 'true_false'>('mcq');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [opt4, setOpt4] = useState('');
  const [answer, setAnswer] = useState('');
  const [points, setPoints] = useState(10);

  const handleOpenCreate = () => {
    setEditingQuestionId(null);
    setContent('');
    setTopic('SUM');
    setDifficulty('nhan_biet');
    setType('mcq');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setOpt4('');
    setAnswer('');
    setPoints(10);
    setIsModalOpen(true);
  };

  const handleEditQuestion = (q: Question) => {
    setEditingQuestionId(q.id);
    setContent(q.content);
    setTopic(q.topic);
    setDifficulty(q.difficulty);
    setType(q.type);
    setAnswer(String(q.answer));
    setPoints(q.points || 10);
    if (q.options && q.options.length > 0) {
      setOpt1(q.options[0] || '');
      setOpt2(q.options[1] || '');
      setOpt3(q.options[2] || '');
      setOpt4(q.options[3] || '');
    } else {
      setOpt1('');
      setOpt2('');
      setOpt3('');
      setOpt4('');
    }
    setIsModalOpen(true);
  };

  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !answer.trim()) {
      alert('Vui lòng nhập đầy đủ nội dung và đáp án!');
      return;
    }

    const optionsList = type === 'mcq' || type === 'true_false' || type === 'matching' || type === 'ordering' || type === 'drag_drop' 
      ? [opt1, opt2, opt3, opt4].filter(o => o.trim() !== '') 
      : undefined;

    if (editingQuestionId) {
      updateQuestion(editingQuestionId, {
        topic,
        difficulty,
        type,
        content,
        options: optionsList && optionsList.length > 0 ? optionsList : undefined,
        answer,
        points: Number(points) || 10
      });
    } else {
      const newQuestion: Question = {
        id: 'q_' + Date.now(),
        topic: topic as any,
        difficulty,
        type,
        content,
        options: optionsList && optionsList.length > 0 ? optionsList : undefined,
        answer,
        explanation: 'Được biên soạn bởi giáo viên.',
        points: Number(points) || 10
      };
      addQuestion(newQuestion);
    }

    setIsModalOpen(false);
    setEditingQuestionId(null);
    setContent('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setOpt4('');
    setAnswer('');
  };

  const filteredQuestions = filterTopic === 'all' 
    ? questions 
    : questions.filter(q => q.topic === filterTopic);

  const getDifficultyBadge = (difficulty: string) => {
    switch(difficulty) {
      case 'nhan_biet': return <Badge variant="success" className="font-black uppercase">🌱 Nhận biết</Badge>;
      case 'thong_hieu': return <Badge variant="blue" className="font-black uppercase">💡 Thông hiểu</Badge>;
      case 'van_dung': return <Badge variant="warning" className="font-black uppercase">⚡ Vận dụng</Badge>;
      case 'van_dung_cao': return <Badge variant="danger" className="font-black uppercase">🔥 Vận dụng cao</Badge>;
      default: return <Badge className="font-black uppercase">Khác</Badge>;
    }
  };

  const getQuestionTypeBadge = (type: string) => {
    switch(type) {
      case 'mcq': return <Badge variant="default" className="font-black uppercase bg-purple-100 text-purple-800 border-purple-300">📝 Trắc nghiệm</Badge>;
      case 'fill_blank': return <Badge variant="default" className="font-black uppercase bg-blue-100 text-blue-800 border-blue-300">✍️ Điền khuyết</Badge>;
      case 'matching': return <Badge variant="default" className="font-black uppercase bg-emerald-100 text-emerald-800 border-emerald-300">🔗 Ghép nối cặp</Badge>;
      case 'ordering': return <Badge variant="default" className="font-black uppercase bg-amber-100 text-amber-800 border-amber-300">🔢 Sắp xếp thứ tự</Badge>;
      case 'drag_drop': return <Badge variant="default" className="font-black uppercase bg-indigo-100 text-indigo-800 border-indigo-300">🎯 Kéo thả ô</Badge>;
      case 'true_false': return <Badge variant="default" className="font-black uppercase bg-rose-100 text-rose-800 border-rose-300">⚖️ Đúng / Sai</Badge>;
      default: return <Badge className="font-black uppercase">Khác</Badge>;
    }
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-700 p-8 rounded-3xl border-4 border-b-8 border-indigo-950 shadow-2xl text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 
            className="text-4xl md:text-5xl font-black uppercase tracking-wider mb-2 text-yellow-300"
            style={{ textShadow: '3px 3px 0px #3b0764, 6px 6px 15px rgba(0,0,0,0.5)' }}
          >
            📚 NGÂN HÀNG CÂU HỎI ❓
          </h1>
          <p className="text-purple-100 font-bold text-lg uppercase tracking-wide">
            ✨ QUẢN LÝ VÀ BIÊN SOẠN CÂU HỎI TRẮC NGHIỆM VÀ TỰ LUẬN. 🚀
          </p>
        </div>
        <Button 
          onClick={handleOpenCreate}
          className="gap-2 bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-black uppercase px-6 py-4 rounded-2xl border-3 border-b-6 border-amber-700 shadow-xl active:translate-y-1"
        >
          <Plus className="w-6 h-6 stroke-[3]" /> Thêm câu hỏi mới
        </Button>
      </div>

      {/* Modal Add / Edit Question */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border-4 border-b-8 border-purple-950 p-8 max-w-2xl w-full shadow-2xl my-8">
            <div className="flex justify-between items-center mb-6 border-b-2 border-slate-100 pb-4">
              <h2 className="text-2xl font-black uppercase text-purple-900 flex items-center gap-2">
                <span>{editingQuestionId ? '✏️' : '➕'}</span> {editingQuestionId ? 'CẬP NHẬT CÂU HỎI' : 'THÊM CÂU HỎI MỚI VÀO KHO'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-red-100 text-slate-700 hover:text-red-600 font-black text-xl flex items-center justify-center border-2 border-slate-300 transition-colors"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveQuestion} className="space-y-6">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Nội dung câu hỏi</label>
                <textarea 
                  required
                  rows={3}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Nhập nội dung câu hỏi (Ví dụ: Hàm nào dùng để tính tổng?)..."
                  className="w-full p-4 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-purple-600 shadow-inner resize-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Chủ đề / Hàm</label>
                  <select 
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="w-full p-3.5 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-purple-600 shadow-sm"
                  >
                    <option value="SUM">HÀM SUM</option>
                    <option value="AVERAGE">HÀM AVERAGE</option>
                    <option value="MIN">HÀM MIN</option>
                    <option value="MAX">HÀM MAX</option>
                    <option value="COUNT">HÀM COUNT</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Độ khó</label>
                  <select 
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as any)}
                    className="w-full p-3.5 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-purple-600 shadow-sm"
                  >
                    <option value="nhan_biet">NHẬN BIẾT</option>
                    <option value="thong_hieu">THÔNG HIỂU</option>
                    <option value="van_dung">VẬN DỤNG</option>
                    <option value="van_dung_cao">VẬN DỤNG CAO</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Điểm số</label>
                  <input 
                    type="number"
                    min="5"
                    max="100"
                    value={points}
                    onChange={(e) => setPoints(Number(e.target.value))}
                    className="w-full p-3.5 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-purple-600 shadow-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Loại câu hỏi</label>
                  <select 
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full p-3.5 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-purple-600 shadow-sm"
                  >
                    <option value="mcq">TRẮC NGHIỆM 4 ĐÁP ÁN</option>
                    <option value="fill_blank">ĐIỀN TỪ KHUYẾT THIẾU</option>
                    <option value="matching">GHÉP NỐI CẶP</option>
                    <option value="ordering">SẮP XẾP THỨ TỰ</option>
                    <option value="drag_drop">KÉO THẢ Ô DỮ LIỆU</option>
                    <option value="true_false">ĐÚNG / SAI</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Đáp án đúng chính xác</label>
                  <input 
                    required
                    type="text"
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    placeholder="Nhập đáp án đúng (VD: =SUM(B2:B10))..."
                    className="w-full p-3.5 bg-slate-50 border-3 border-slate-300 rounded-2xl font-bold text-slate-800 outline-none focus:border-purple-600 shadow-sm"
                  />
                </div>
              </div>

              {type === 'mcq' && (
                <div className="space-y-3 pt-2">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-600">Các lựa chọn đáp án (A, B, C, D)</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input 
                      type="text"
                      value={opt1}
                      onChange={(e) => setOpt1(e.target.value)}
                      placeholder="Đáp án 1 (VD: =SUM(B2:B10))"
                      className="p-3 bg-slate-50 border-2 border-slate-300 rounded-xl font-bold text-slate-800 outline-none focus:border-purple-600"
                    />
                    <input 
                      type="text"
                      value={opt2}
                      onChange={(e) => setOpt2(e.target.value)}
                      placeholder="Đáp án 2 (VD: =AVERAGE(A1:A5))"
                      className="p-3 bg-slate-50 border-2 border-slate-300 rounded-xl font-bold text-slate-800 outline-none focus:border-purple-600"
                    />
                    <input 
                      type="text"
                      value={opt3}
                      onChange={(e) => setOpt3(e.target.value)}
                      placeholder="Đáp án 3"
                      className="p-3 bg-slate-50 border-2 border-slate-300 rounded-xl font-bold text-slate-800 outline-none focus:border-purple-600"
                    />
                    <input 
                      type="text"
                      value={opt4}
                      onChange={(e) => setOpt4(e.target.value)}
                      placeholder="Đáp án 4"
                      className="p-3 bg-slate-50 border-2 border-slate-300 rounded-xl font-bold text-slate-800 outline-none focus:border-purple-600"
                    />
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-4 pt-4 border-t-2 border-slate-100">
                <Button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-black uppercase px-6 py-3 rounded-2xl border-3 border-b-6 border-slate-400"
                >
                  Hủy bỏ
                </Button>
                <Button 
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-700 text-white font-black uppercase px-8 py-3 rounded-2xl border-3 border-b-6 border-purple-900 shadow-xl"
                >
                  Lưu câu hỏi
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="flex gap-3 overflow-x-auto pb-2">
        {[
          { id: 'all', label: 'TẤT CẢ', emoji: '🌟' },
          { id: 'SUM', label: 'HÀM SUM', emoji: '➕' },
          { id: 'AVERAGE', label: 'HÀM AVERAGE', emoji: '📊' },
          { id: 'MIN', label: 'HÀM MIN', emoji: '📉' },
          { id: 'MAX', label: 'HÀM MAX', emoji: '📈' },
          { id: 'COUNT', label: 'HÀM COUNT', emoji: '🔢' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setFilterTopic(t.id)}
            className={`px-5 py-3 rounded-2xl font-black uppercase text-sm tracking-wider whitespace-nowrap transition-all border-3 border-b-6 shadow-md flex items-center gap-2 ${
              filterTopic === t.id 
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-900 scale-105 ring-4 ring-purple-300' 
                : 'bg-white text-slate-700 border-slate-300 hover:bg-purple-50 hover:border-purple-300'
            }`}
          >
            <span>{t.emoji}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      <div className="grid gap-6">
        {filteredQuestions.map((q: Question) => (
          <div key={q.id} className="bg-white rounded-3xl p-6 border-4 border-b-8 border-slate-300 shadow-xl hover:border-purple-500 transition-all">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
              <div>
                <div className="flex flex-wrap gap-2 mb-3">
                  <Badge variant="purple" className="font-black uppercase">📌 {q.topic}</Badge>
                  {getQuestionTypeBadge(q.type)}
                  {getDifficultyBadge(q.difficulty)}
                  <Badge variant="default" className="font-black uppercase bg-amber-100 text-amber-800 border-amber-300">⭐ {q.points} ĐIỂM</Badge>
                </div>
                <h3 className="text-xl font-black uppercase tracking-wide text-slate-900">{q.content}</h3>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button 
                  onClick={() => handleEditQuestion(q)}
                  variant="outline" 
                  size="sm" 
                  className="font-black uppercase border-2 border-slate-300 rounded-xl hover:bg-purple-50 hover:border-purple-300"
                >
                  Sửa
                </Button>
                <Button 
                  onClick={() => {
                    if (confirm('Bạn có chắc chắn muốn xóa câu hỏi này khỏi kho?')) {
                      deleteQuestion(q.id);
                    }
                  }}
                  variant="danger" 
                  size="sm" 
                  className="bg-red-50 text-red-700 font-black uppercase hover:bg-red-100 border-2 border-red-200 rounded-xl shadow-none"
                >
                  Xóa
                </Button>
              </div>
            </div>

            {(q.type === 'mcq' || q.type === 'true_false') && q.options && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                {q.options.map((opt, i) => (
                  <div 
                    key={i} 
                    className={`p-4 rounded-2xl border-3 font-bold uppercase text-sm tracking-wide ${
                      opt === q.answer 
                        ? 'border-green-500 bg-green-50 text-green-800 shadow-md ring-2 ring-green-300' 
                        : 'border-slate-300 bg-slate-50 text-slate-700'
                    }`}
                  >
                    {opt === q.answer ? '✅ ' : '🔸 '} {opt}
                  </div>
                ))}
              </div>
            )}
            
            {(q.type === 'fill_blank' || q.type === 'matching' || q.type === 'ordering' || q.type === 'drag_drop') && (
              <div className="mt-4 space-y-3">
                {q.options && (
                  <div className="p-4 bg-slate-50 border-3 border-slate-200 rounded-2xl">
                    <span className="text-xs font-black uppercase tracking-wider text-slate-500 block mb-2">Các mục / Gợi ý:</span>
                    <div className="flex flex-wrap gap-2">
                      {q.options.map((opt, i) => (
                        <span key={i} className="px-3 py-1.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-bold text-slate-700">
                          {opt}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                <div className="p-4 bg-emerald-50 border-3 border-emerald-200 rounded-2xl flex items-center gap-3">
                  <span className="font-black uppercase text-emerald-900">ĐÁP ÁN ĐÚNG:</span>
                  <span className="font-black text-emerald-700 uppercase bg-white px-4 py-1.5 rounded-xl border-2 border-emerald-300 shadow-sm">{String(q.answer)}</span>
                </div>
              </div>
            )}
          </div>
        ))}

        {filteredQuestions.length === 0 && (
          <div className="text-center py-16 text-slate-500 font-black uppercase tracking-wider bg-white rounded-3xl border-4 border-dashed border-slate-300">
            Không có câu hỏi nào thuộc chủ đề này.
          </div>
        )}
      </div>
    </div>
  );
}
