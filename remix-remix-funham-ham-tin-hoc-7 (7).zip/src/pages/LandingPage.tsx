import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Gamepad2, Trophy, BookOpen, TrendingUp } from 'lucide-react';

export function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white py-12">
      <main className="container mx-auto px-6 pt-4">
        <div className="max-w-4xl mx-auto bg-slate-800 border-4 border-b-8 border-indigo-600 rounded-3xl shadow-[0_20px_50px_rgba(79,70,229,0.4)] p-8 md:p-14 text-center relative overflow-hidden">
          {/* Decorative background glow */}
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-black tracking-wider mb-4 leading-tight uppercase"
            style={{
              color: '#38bdf8',
              textShadow: '0 4px 0 #0284c7, 0 8px 0 #0369a1, 0 12px 0 #075985, 0 20px 30px rgba(56,189,248,0.5)'
            }}
          >
            FUNHAM AI V2.0 🎯
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="text-xl md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-400 to-cyan-300 mb-4 tracking-wide uppercase"
            style={{
              filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.5))'
            }}
          >
            🌟 Học qua trải nghiệm – Hiểu từ lỗi sai – Tiến bộ mỗi ngày 🚀
          </motion.div>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-sm md:text-lg text-slate-200 mb-8 max-w-3xl mx-auto leading-relaxed font-bold bg-slate-900/60 p-5 rounded-2xl border-2 border-slate-700 shadow-inner"
          >
            ✨ Giải pháp ứng dụng trí tuệ nhân tạo hỗ trợ học sinh lớp 7 phát hiện và khắc phục lỗi khi học hàm tính toán (Chương trình GDPT 2018 - SGK Tin học 7 Kết nối tri thức). Tích hợp Trợ lý AI chẩn đoán 10 mã lỗi, gợi ý thông minh 3 mức độ và đánh giá năng lực thực tế. 📊
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <button 
              onClick={() => navigate('/login')} 
              className="px-10 py-5 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-3xl border-4 border-b-8 border-purple-900 shadow-2xl hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 transition-all flex items-center justify-center gap-3 text-2xl mx-auto"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              <span>🚀</span> VÀO HỌC NGAY 🎓
            </button>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mt-16">
          <FeatureCard 
            icon="🎮"
            title="Học qua trò chơi"
            desc="Hệ thống câu hỏi tương tác thú vị giúp ghi nhớ lâu hơn."
            delay={0.3}
            color="from-blue-600 to-indigo-600 border-blue-900"
          />
          <FeatureCard 
            icon="🏆"
            title="Thi đua tích cực"
            desc="Bảng xếp hạng, cấp độ và huy hiệu tạo động lực."
            delay={0.4}
            color="from-amber-500 to-orange-600 border-orange-900"
          />
          <FeatureCard 
            icon="🔮"
            title="Kiến thức trực quan"
            desc="Thẻ bài 3D và mô phỏng giúp hiểu sâu bản chất."
            delay={0.5}
            color="from-emerald-500 to-teal-600 border-teal-900"
          />
          <FeatureCard 
            icon="📊"
            title="Theo dõi tiến bộ"
            desc="Biểu đồ phân tích chi tiết kỹ năng và điểm số."
            delay={0.6}
            color="from-purple-600 to-pink-600 border-pink-900"
          />
        </div>

        {/* Pedagogical Loop Showcase Section */}
        <div className="mt-16 bg-slate-800/90 border-4 border-b-8 border-rose-600 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="px-4 py-1.5 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded-full text-xs font-black uppercase tracking-widest">
              🔄 QUY TRÌNH HỌC TẬP KHÉP KÍN FUNHAM
            </span>
            <h2 className="text-3xl md:text-4xl font-black text-white uppercase mt-3 mb-4">
              Từ Khó Khăn Đến Thành Thạo
            </h2>
            <p className="text-slate-300 font-bold text-sm md:text-base">
              Chuỗi giải pháp học tập chuẩn hóa giúp học sinh lớp 7 làm chủ hoàn toàn các hàm tính toán bảng điện tử.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 text-center">
            <div className="bg-slate-900/80 p-5 rounded-2xl border-2 border-amber-500/40 flex flex-col justify-between">
              <div className="text-3xl mb-2">⚠️</div>
              <div className="text-amber-400 font-black text-xs uppercase mb-1">Bước 1</div>
              <div className="text-white font-black text-sm uppercase">Học sinh gặp khó khăn</div>
            </div>
            <div className="bg-slate-900/80 p-5 rounded-2xl border-2 border-blue-500/40 flex flex-col justify-between">
              <div className="text-3xl mb-2">🔍</div>
              <div className="text-blue-400 font-black text-xs uppercase mb-1">Bước 2</div>
              <div className="text-white font-black text-sm uppercase">FUNHAM phát hiện</div>
            </div>
            <div className="bg-slate-900/80 p-5 rounded-2xl border-2 border-purple-500/40 flex flex-col justify-between">
              <div className="text-3xl mb-2">🎯</div>
              <div className="text-purple-400 font-black text-xs uppercase mb-1">Bước 3</div>
              <div className="text-white font-black text-sm uppercase">FUNHAM cá nhân hóa</div>
            </div>
            <div className="bg-slate-900/80 p-5 rounded-2xl border-2 border-emerald-500/40 flex flex-col justify-between">
              <div className="text-3xl mb-2">🎮</div>
              <div className="text-emerald-400 font-black text-xs uppercase mb-1">Bước 4</div>
              <div className="text-white font-black text-sm uppercase">Học sinh luyện tập</div>
            </div>
            <div className="bg-slate-900/80 p-5 rounded-2xl border-2 border-cyan-500/40 flex flex-col justify-between">
              <div className="text-3xl mb-2">📈</div>
              <div className="text-cyan-400 font-black text-xs uppercase mb-1">Bước 5</div>
              <div className="text-white font-black text-sm uppercase">Đo lường tiến bộ</div>
            </div>
            <div className="bg-slate-900/80 p-5 rounded-2xl border-2 border-rose-500/40 flex flex-col justify-between">
              <div className="text-3xl mb-2">🏆</div>
              <div className="text-rose-400 font-black text-xs uppercase mb-1">Bước 6</div>
              <div className="text-white font-black text-sm uppercase">Nghiên cứu hiệu quả</div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <button
              onClick={() => navigate('/login')}
              className="px-8 py-4 bg-rose-600 hover:bg-rose-500 text-white font-black uppercase tracking-wider rounded-2xl border-2 border-b-6 border-rose-900 shadow-xl transition-all inline-flex items-center gap-3"
            >
              <span>🚀 Trải Nghiệm Ngay Chuỗi Khép Kín</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, desc, delay, color }: { icon: string, title: string, desc: string, delay: number, color: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`bg-slate-800 p-6 rounded-3xl border-4 border-b-8 shadow-2xl ${color} flex flex-col justify-between hover:-translate-y-1 transition-all`}
    >
      <div>
        <div className="w-16 h-16 rounded-2xl bg-white/10 border-2 border-white/20 flex items-center justify-center text-3xl mb-4 shadow-inner">
          {icon}
        </div>
        <h3 className="text-xl font-black text-white mb-2 uppercase tracking-wide" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>{title}</h3>
        <p className="text-slate-300 text-sm md:text-base leading-relaxed font-bold">{desc}</p>
      </div>
    </motion.div>
  );
}
