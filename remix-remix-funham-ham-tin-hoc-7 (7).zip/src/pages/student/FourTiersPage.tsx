import React from 'react';
import { motion } from 'framer-motion';
import { Layers, Sparkles, Trophy, BookOpen, CheckCircle, ArrowLeft } from 'lucide-react';
import { FourTiersLearning } from '../../components/FourTiersLearning';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';

export function FourTiersPage() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 pb-12">
      {/* Top Breadcrumb & Action */}
      <div className="flex items-center justify-between">
        <Button
          onClick={() => navigate('/student')}
          className="bg-white hover:bg-slate-100 text-slate-700 border-2 border-slate-300 font-black text-xs uppercase px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" /> Bảng điều khiển
        </Button>
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 rounded-full text-xs font-black uppercase">
          <Layers className="w-3.5 h-3.5" /> Khung 4 Cấp Độ Năng Lực Hàm
        </div>
      </div>

      {/* Main 4 Tiers Interactive Component */}
      <FourTiersLearning />

      {/* Pedagogical Framework Summary Card */}
      <div className="bg-white rounded-3xl p-6 md:p-8 border-3 border-slate-200 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black text-xl">
            📚
          </div>
          <div>
            <h3 className="font-black text-lg md:text-xl text-slate-900 uppercase">
              KHUNG 4 CẤP ĐỘ NĂNG LỰC HÀM TIN HỌC 7
            </h3>
            <p className="text-xs text-slate-500 font-bold">
              Thiết kế theo thang đo năng lực phát triển tư duy tính toán và giải quyết vấn đề với bảng tính
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
          <div className="p-4 rounded-2xl bg-blue-50 border-2 border-blue-200">
            <span className="text-xs font-black text-blue-700 uppercase block mb-1">Cấp 1: Nhận Biết</span>
            <p className="text-xs text-slate-700 font-medium">
              Nhận diện tên hàm và công dụng cơ bản (SUM tính tổng, AVERAGE tính trung bình, MIN/MAX, COUNT).
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-indigo-50 border-2 border-indigo-200">
            <span className="text-xs font-black text-indigo-700 uppercase block mb-1">Cấp 2: Hiểu Cú Pháp</span>
            <p className="text-xs text-slate-700 font-medium">
              Nắm vững cú pháp chuẩn: dấu bằng, dấu hai chấm chỉ khối ô liền nhau (=SUM(B2:B8)) và dấu phẩy phân cách đối số rời rạc.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-200">
            <span className="text-xs font-black text-emerald-700 uppercase block mb-1">Cấp 3: Vận Dụng</span>
            <p className="text-xs text-slate-700 font-medium">
              Áp dụng vào bảng điểm thực tế (Toán, Văn, Tin của học sinh An, Bình...) để lập công thức giải quyết bài toán.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-rose-50 border-2 border-rose-200">
            <span className="text-xs font-black text-rose-700 uppercase block mb-1">Cấp 4: Sửa Lỗi</span>
            <p className="text-xs text-slate-700 font-medium">
              Phát hiện công thức sai (ví dụ: =SUM(B2-B8)) và sửa lại cho đúng (=SUM(B2:B8)), phát triển tư duy phản biện.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
