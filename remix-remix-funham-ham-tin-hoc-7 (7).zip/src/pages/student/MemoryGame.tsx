import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Brain, Trophy, RotateCcw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { soundManager } from '../../utils/sound';

// 6 Pairs = 12 Cards
const CARD_PAIRS = [
  { id: 'sum', content: '=SUM()', matchId: 'sum', type: 'formula' },
  { id: 'sum-desc', content: 'Tổng', matchId: 'sum', type: 'desc' },
  { id: 'avg', content: '=AVERAGE()', matchId: 'avg', type: 'formula' },
  { id: 'avg-desc', content: 'Trung bình', matchId: 'avg', type: 'desc' },
  { id: 'min', content: '=MIN()', matchId: 'min', type: 'formula' },
  { id: 'min-desc', content: 'Nhỏ nhất', matchId: 'min', type: 'desc' },
  { id: 'max', content: '=MAX()', matchId: 'max', type: 'formula' },
  { id: 'max-desc', content: 'Lớn nhất', matchId: 'max', type: 'desc' },
  { id: 'count', content: '=COUNT()', matchId: 'count', type: 'formula' },
  { id: 'count-desc', content: 'Đếm số', matchId: 'count', type: 'desc' },
  { id: 'syntax', content: '=(A1:A5)', matchId: 'syntax', type: 'formula' },
  { id: 'syntax-desc', content: 'Vùng dữ liệu', matchId: 'syntax', type: 'desc' },
];

export function MemoryGame() {
  const navigate = useNavigate();
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<string[]>([]);
  const [moves, setMoves] = useState(0);
  const [score, setScore] = useState(0);
  const [isLocked, setIsLocked] = useState(false);

  const initGame = () => {
    const shuffled = [...CARD_PAIRS].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setFlipped([]);
    setMatched([]);
    setMoves(0);
    setScore(0);
    setIsLocked(false);
  };

  useEffect(() => {
    initGame();
  }, []);

  const handleCardClick = (index: number) => {
    if (isLocked) return;
    if (flipped.includes(index)) return;
    if (matched.includes(cards[index].matchId)) return;

    const newFlipped = [...flipped, index];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setIsLocked(true);
      setMoves(m => m + 1);

      const firstCard = cards[newFlipped[0]];
      const secondCard = cards[newFlipped[1]];

      if (firstCard.matchId === secondCard.matchId) {
        // Match!
        soundManager.playCorrect();
        setMatched(prev => {
          const next = [...prev, firstCard.matchId];
          if (next.length === CARD_PAIRS.length / 2) {
            setTimeout(() => soundManager.playVictory(), 300);
          }
          return next;
        });
        setScore(s => s + 30);
        setFlipped([]);
        setIsLocked(false);
      } else {
        // No match
        soundManager.playWrong();
        setTimeout(() => {
          setFlipped([]);
          setIsLocked(false);
        }, 1000);
      }
    }
  };

  const isWin = matched.length === CARD_PAIRS.length / 2;

  if (isWin) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <motion.div 
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', bounce: 0.5, duration: 1 }}
        >
          <Trophy className="w-48 h-48 text-purple-400 drop-shadow-[0_0_50px_rgba(192,132,252,0.6)] mb-8" />
        </motion.div>
        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-4 text-center">
          TRÍ NHỚ SIÊU PHÀM!
        </h1>
        <p className="text-xl text-slate-300 mb-8 text-center max-w-md">
          Bạn đã hoàn thành trò chơi trong <strong className="text-white">{moves}</strong> lượt lật. 
          Điểm của bạn: <strong className="text-yellow-400">{score}</strong> XP
        </p>
        <div className="flex gap-4">
          <Button size="lg" onClick={() => navigate('/student/game')} variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
            Về khu vui chơi
          </Button>
          <Button size="lg" onClick={initGame} className="bg-purple-600 hover:bg-purple-500">
            Chơi lại
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4 font-sans pb-24">
      {/* Header */}
      <div className="flex justify-between items-center max-w-4xl mx-auto mb-8 pt-4">
        <button
          onClick={() => navigate('/student/game')}
          className="px-6 py-3.5 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-2xl hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 transition-all flex items-center gap-2 text-lg"
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
        >
          <span className="text-2xl">⬅️</span> TRỞ VỀ 🎮
        </button>
        
        <div className="flex items-center gap-3 bg-slate-800 px-6 py-3 rounded-2xl border-2 border-b-6 border-slate-700 shadow-lg">
          <span className="text-3xl">🧠</span>
          <h1 
            className="text-2xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 uppercase tracking-wider"
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
          >
            LẬT THẺ TRÍ NHỚ ✨
          </h1>
        </div>

        <div className="text-yellow-300 font-black bg-yellow-500/20 border border-yellow-500/40 px-5 py-2.5 rounded-2xl text-lg shadow-sm">
          ⭐ {score} XP
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8 bg-slate-800 p-5 rounded-2xl border-2 border-slate-700 shadow-inner">
          <div className="text-amber-400 font-black uppercase tracking-wider text-lg">
            🎯 SỐ LƯỢT LẬT: <span className="text-white text-2xl font-mono ml-2">{moves}</span>
          </div>
          <button 
            onClick={initGame}
            className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black uppercase tracking-wider rounded-xl border-2 border-b-4 border-purple-900 shadow-lg transition-all flex items-center gap-2 text-base"
          >
            <RotateCcw className="w-5 h-5" /> CHƠI LẠI 🔄
          </button>
        </div>
        
        <div className="grid grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
          {cards.map((card, index) => {
            const isFlipped = flipped.includes(index);
            const isMatched = matched.includes(card.matchId);
            const showFace = isFlipped || isMatched;

            return (
              <div 
                key={index}
                className="aspect-square relative cursor-pointer group"
                onClick={() => handleCardClick(index)}
              >
                <motion.div
                  className="w-full h-full relative preserve-3d"
                  animate={{ rotateY: showFace ? 180 : 0 }}
                  transition={{ type: "spring", stiffness: 260, damping: 20 }}
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  {/* Card Back (Hidden when flipped) */}
                  <div 
                    className="absolute inset-0 w-full h-full bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl border-4 border-b-8 border-slate-700 flex items-center justify-center backface-hidden shadow-2xl group-hover:border-purple-500 transition-all"
                    style={{ backfaceVisibility: 'hidden' }}
                  >
                    <span className="text-4xl animate-pulse">🧠</span>
                  </div>

                  {/* Card Front (Visible when flipped) */}
                  <div 
                    className={`absolute inset-0 w-full h-full rounded-3xl border-4 border-b-8 flex items-center justify-center p-3 text-center backface-hidden shadow-2xl
                      ${isMatched ? 'bg-gradient-to-br from-purple-900 to-indigo-950 border-purple-600' : 'bg-gradient-to-br from-white to-slate-100 border-slate-300'}
                    `}
                    style={{ 
                      backfaceVisibility: 'hidden', 
                      transform: 'rotateY(180deg)' 
                    }}
                  >
                    <span className={`font-black tracking-wide ${card.type === 'formula' ? 'font-mono text-2xl md:text-3xl text-blue-700' : 'text-lg md:text-2xl text-slate-900'}
                      ${isMatched ? 'text-purple-200' : ''}
                    `} style={{ textShadow: isMatched ? '0 2px 4px rgba(0,0,0,0.5)' : 'none' }}>
                      {card.content}
                    </span>
                  </div>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
