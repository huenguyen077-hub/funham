import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Play, Trophy, Star, Target, Flame, BookOpen, Gamepad2, MonitorPlay, Layers, Sparkles, ArrowRight, FileCheck2, Printer, Award } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { Student } from '../../types';
import { mockStudents } from '../../data/mockData';
import { calculateLevel, getLevelName, getXpForNextLevel, cn } from '../../utils';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { StudentResultModal } from '../../components/StudentResultModal';
import { Achievements } from '../../components/Achievements';

export function StudentDashboard() {
  const { user } = useAuthStore();
  const { studentsStat, prePostRecords } = useEvidenceStore();
  const navigate = useNavigate();
  const [showResultModal, setShowResultModal] = useState(false);

  const student = (user as Student) || mockStudents[0];
  const currentXp = student?.xp ?? 950;
  const currentLevel = calculateLevel(currentXp);
  const nextLevelXp = getXpForNextLevel(currentLevel);
  const currentLevelBaseXp = getXpForNextLevel(currentLevel - 1);
  
  const progressPercent = Math.min(100, Math.max(0, ((currentXp - currentLevelBaseXp) / (nextLevelXp - currentLevelBaseXp)) * 100));

  const myStat = studentsStat.find(s => s.studentName.toLowerCase() === student.name.toLowerCase()) || {
    preTestScore: 5.0,
    postTestScore: 9.0,
    deltaScore: 4.0,
    accuracyRate: 88.0,
    selfCorrectionRate: 85.0,
    aiHintsRequested: 4
  };
  const myPrePost = prePostRecords.find(p => p.studentName.toLowerCase() === student.name.toLowerCase());
  const myPre = myPrePost ? myPrePost.preScore : myStat.preTestScore;
  const myPost = myPrePost ? myPrePost.postScore : myStat.postTestScore;
  const myDelta = Number((myPost - myPre).toFixed(1));

  return (
    <div className="space-y-8 pb-12">
      {/* Hero */}
      <section className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 p-8 rounded-3xl border-4 border-b-8 border-indigo-800 shadow-xl text-white relative overflow-hidden">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 rounded-full text-xs font-black uppercase tracking-widest mb-3 border border-white/30">
              <span>🌟 PHÒNG ĐIỀU KHIỂN CHÍNH</span>
            </div>
            <h1 
              className="text-3xl md:text-5xl font-black tracking-wider uppercase mb-3 drop-shadow-md"
              style={{ textShadow: '0 3px 6px rgba(0,0,0,0.3)' }}
            >
              🚀 CHÀO MỪNG, {student.name}! ✨
            </h1>
            <p className="text-blue-100 font-extrabold text-lg">
              Bạn đã sẵn sàng chinh phục các hàm tính toán đỉnh cao chưa?
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 bg-gradient-to-r from-blue-600 to-indigo-600 border-4 border-b-8 border-blue-800 text-white overflow-hidden relative shadow-lg rounded-3xl">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Trophy className="w-48 h-48" />
          </div>
          <div className="relative z-10 p-2">
            <div className="flex justify-between items-end mb-6">
              <div>
                <div className="text-blue-200 font-black mb-1 uppercase tracking-wider text-xs">🏆 Cấp độ hiện tại</div>
                <div className="text-3xl md:text-4xl font-black" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.2)' }}>{getLevelName(currentLevel)}</div>
                <div className="text-blue-100 font-extrabold mt-1 text-sm uppercase">LEVEL {currentLevel}</div>
              </div>
              <div className="text-right">
                <div className="text-2xl md:text-3xl font-black" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.2)' }}>{student.xp} XP</div>
                <div className="text-blue-200 text-xs font-bold uppercase tracking-wider">MỤC TIÊU: {nextLevelXp} XP</div>
              </div>
            </div>
            
            <div className="h-5 bg-black/20 rounded-full overflow-hidden p-1 border border-white/20 shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full bg-gradient-to-r from-yellow-300 to-amber-400 rounded-full shadow-md"
              />
            </div>
          </div>
        </Card>

        <Card className="flex flex-col justify-center items-center text-center bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100 border-4 border-b-8 border-orange-400 rounded-3xl shadow-lg p-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-400 to-amber-500 flex items-center justify-center mb-4 shadow-md border-2 border-white transform rotate-6">
            <Flame className="w-9 h-9 text-white drop-shadow" />
          </div>
          <div className="text-4xl font-black text-orange-600 mb-1" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>{student.streak} NGÀY</div>
          <div className="text-slate-600 font-black uppercase tracking-wider text-xs">🔥 HỌC LIÊN TIẾP</div>
        </Card>
      </div>

      {/* PHIẾU BÁO KẾT QUẢ HỌC TẬP CÁ NHÂN CỦA EM */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 rounded-3xl border-4 border-b-8 border-indigo-700 shadow-xl text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase border border-yellow-400/30">
            <Award className="w-3.5 h-3.5 text-yellow-300" />
            <span>KẾT QUẢ HỌC TẬP CÁ NHÂN CỦA BẠN</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black uppercase text-white">
            BÁO CÁO NĂNG LỰC & TIẾN BỘ: <span className="text-yellow-300">{student.name}</span>
          </h2>
          <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-slate-300 pt-1">
            <span className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/20">
              Đầu vào (Pre): <strong className="text-amber-300 font-mono text-sm">{myPre}/10</strong>
            </span>
            <span className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/20">
              Đầu ra (Post): <strong className="text-emerald-300 font-mono text-sm">{myPost}/10</strong>
            </span>
            <span className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/20">
              Tăng trưởng: <strong className="text-cyan-300 font-mono text-sm">+{myDelta} đ</strong>
            </span>
            <span className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/20">
              Tự sửa lỗi (AI): <strong className="text-purple-300 font-mono text-sm">{myStat.selfCorrectionRate}%</strong>
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button
            onClick={() => setShowResultModal(true)}
            className="bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-300 hover:to-amber-400 text-slate-950 font-black text-xs md:text-sm uppercase px-5 py-3.5 rounded-2xl shadow-lg border-2 border-b-4 border-amber-700 flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
          >
            <Printer className="w-4 h-4" />
            <span>Xem & In Phiếu Kết Quả Của Em</span>
          </Button>
          <Button
            onClick={() => navigate('/student/evidence')}
            className="bg-white/20 hover:bg-white/30 text-white font-black text-xs md:text-sm uppercase px-5 py-3.5 rounded-2xl border border-white/30 flex items-center gap-2 cursor-pointer"
          >
            <span>Hồ Sơ Minh Chứng</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* NÂNG CẤP FUNHAM AI V2.0 - TRỌNG TÂM CUỘC THI 2026 */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-black uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>NÂNG CẤP TRÍ TUỆ NHÂN TẠO 2026</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black uppercase text-slate-800">
              🤖 BỘ CÔNG CỤ TRỢ LÝ FUNHAM AI V2.0
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div 
            onClick={() => navigate('/student/doctor')}
            className="bg-gradient-to-br from-teal-500 to-emerald-600 rounded-3xl p-6 text-white border-4 border-b-8 border-teal-800 shadow-xl cursor-pointer hover:scale-102 transition-all space-y-3"
          >
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-3xl border border-white/30">
              🩺
            </div>
            <h3 className="text-xl font-black uppercase">Trợ Lý AI Khám Lỗi</h3>
            <p className="text-xs text-teal-100 font-bold leading-relaxed">
              Phát hiện 10 mã lỗi cú pháp & ngữ nghĩa, hỗ trợ gợi ý 3 mức độ (Gợi mở, Định hướng, Giải thích) giúp em tự khắc phục.
            </p>
            <div className="pt-2 flex items-center gap-1.5 text-xs font-black text-yellow-300 uppercase">
              <span>Vào khám lỗi ngay</span> ➔
            </div>
          </div>

          <div 
            onClick={() => navigate('/student/assessment')}
            className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-3xl p-6 text-white border-4 border-b-8 border-indigo-900 shadow-xl cursor-pointer hover:scale-102 transition-all space-y-3"
          >
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-3xl border border-white/30">
              📝
            </div>
            <h3 className="text-xl font-black uppercase">Khảo Sát & Đánh Giá</h3>
            <p className="text-xs text-indigo-100 font-bold leading-relaxed">
              Bài kiểm tra Đầu vào (Pre-Test) và Đầu ra (Post-Test) chuẩn 10 câu SGK Tin 7 đo lường độ tăng trưởng năng lực.
            </p>
            <div className="pt-2 flex items-center gap-1.5 text-xs font-black text-yellow-300 uppercase">
              <span>Làm bài khảo sát</span> ➔
            </div>
          </div>

          <div 
            onClick={() => navigate('/student/adaptive')}
            className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-3xl p-6 text-white border-4 border-b-8 border-purple-900 shadow-xl cursor-pointer hover:scale-102 transition-all space-y-3"
          >
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-3xl border border-white/30">
              🎯
            </div>
            <h3 className="text-xl font-black uppercase">Luyện Bổ Trợ Cá Nhân</h3>
            <p className="text-xs text-purple-100 font-bold leading-relaxed">
              Lộ trình bài tập khắc phục chuyên sâu các lỗi thường gặp (Quên dấu =, sai tên hàm, ký hiệu vùng, nhầm SUM/AVERAGE).
            </p>
            <div className="pt-2 flex items-center gap-1.5 text-xs font-black text-yellow-300 uppercase">
              <span>Bắt đầu luyện tập</span> ➔
            </div>
          </div>
        </div>
      </section>

      {/* 4 Tầng Học Tập - Trọng tâm Sư phạm */}
      <section className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Layers className="w-64 h-64 text-cyan-400" />
        </div>
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase tracking-wider border border-yellow-400/30">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>ĐỔI MỚI PHƯƠNG PHÁP TIN HỌC 7</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black uppercase text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-300 to-cyan-300">
              🎯 4 CẤP ĐỘ NĂNG LỰC HÀM BẢNG TÍNH
            </h2>
            <p className="text-slate-300 text-xs md:text-sm font-bold max-w-2xl leading-relaxed">
              Lộ trình rèn luyện 4 cấp bậc: <span className="text-cyan-300 font-black">Cấp 1: Nhận biết</span> ➔ <span className="text-indigo-300 font-black">Cấp 2: Hiểu cú pháp</span> ➔ <span className="text-emerald-300 font-black">Cấp 3: Vận dụng thực tế</span> ➔ <span className="text-rose-300 font-black">Cấp 4: Phát hiện & Sửa lỗi</span>.
            </p>
            
            <div className="flex flex-wrap gap-2 pt-2">
              <span className="px-2.5 py-1 bg-blue-500/20 text-blue-300 rounded-lg text-xs font-bold border border-blue-500/30">
                Cấp 1: Nhận biết (=SUM tính tổng)
              </span>
              <span className="px-2.5 py-1 bg-indigo-500/20 text-indigo-300 rounded-lg text-xs font-bold border border-indigo-500/30">
                Cấp 2: Hiểu cú pháp (=SUM(B2:B8))
              </span>
              <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 rounded-lg text-xs font-bold border border-emerald-500/30">
                Cấp 3: Vận dụng (Bảng điểm thực tế)
              </span>
              <span className="px-2.5 py-1 bg-rose-500/20 text-rose-300 rounded-lg text-xs font-bold border border-rose-500/30">
                Cấp 4: Sửa lỗi (=SUM(B2-B8) ➔ ❌)
              </span>
            </div>
          </div>

          <Button
            size="lg"
            onClick={() => navigate('/student/tiers')}
            className="w-full lg:w-auto px-8 py-5 h-auto rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-base uppercase tracking-wider shadow-xl shadow-cyan-500/25 border-2 border-b-6 border-blue-900 flex items-center justify-center gap-3 shrink-0"
          >
            <span>BẮT ĐẦU CHINH PHỤC</span>
            <ArrowRight className="w-5 h-5" />
          </Button>
        </div>
      </section>

      <Achievements />

      {/* Modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ModuleCard
          title="HỌC BÀI"
          subtitle="📖 LÝ THUYẾT"
          description="Khám phá chi tiết các hàm tính toán cơ bản: SUM, AVERAGE, MIN, MAX, COUNT."
          icon={<BookOpen className="w-10 h-10 text-blue-600" />}
          borderColor="border-blue-400"
          shadowColor="shadow-[0_10px_0_0_#93c5fd]"
          textColor="text-blue-600"
          onClick={() => navigate('/student/lesson')}
        />
        <ModuleCard
          title="LUYỆN TẬP"
          subtitle="🎮 TRÒ CHƠI"
          description="Thực hành mô phỏng bảng tính và tham gia minigame để tích lũy XP."
          icon={<Gamepad2 className="w-10 h-10 text-purple-600" />}
          borderColor="border-purple-400"
          shadowColor="shadow-[0_10px_0_0_#d8b4fe]"
          textColor="text-purple-600"
          onClick={() => navigate('/student/game')}
        />
        <ModuleCard
          title="THÁP 4 TẦNG"
          subtitle="🏰 CHINH PHỤC NĂNG LỰC"
          description="Leo tháp săn XP: Nhận biết, Cú pháp, Bảng tính thực chiến và Diệt trùm sửa lỗi."
          icon={<Layers className="w-10 h-10 text-rose-600" />}
          borderColor="border-rose-400"
          shadowColor="shadow-[0_10px_0_0_#fecdd3]"
          textColor="text-rose-600"
          onClick={() => navigate('/student/tiers')}
        />
        <ModuleCard
          title="XẾP HẠNG"
          subtitle="🏆 VINH QUANG"
          description="Xem vị trí của bạn trên bảng vinh danh và các thành tích đã đạt được."
          icon={<Trophy className="w-10 h-10 text-amber-500" />}
          borderColor="border-amber-400"
          shadowColor="shadow-[0_10px_0_0_#fde68a]"
          textColor="text-amber-600"
          onClick={() => navigate('/student/leaderboard')}
        />
      </div>

      {/* Recent Assignments */}
      <section className="pt-4">
        <h2 
          className="text-2xl md:text-3xl font-black text-slate-800 tracking-wider mb-6 uppercase flex items-center gap-3"
          style={{ textShadow: '0 1px 2px rgba(0,0,0,0.1)' }}
        >
          <span className="w-4 h-4 rounded-full bg-blue-600 animate-pulse border-2 border-white shadow"></span>
          🎯 BÀI TẬP ĐƯỢC GIAO
        </h2>
        <div className="bg-gradient-to-r from-slate-50 via-blue-50/50 to-slate-50 border-4 border-b-8 border-slate-300 rounded-3xl shadow-xl p-8">
          <div className="text-center py-6">
            <div className="w-20 h-20 bg-white rounded-3xl border-2 border-b-6 border-slate-200 flex items-center justify-center mx-auto mb-4 shadow-md">
              <Target className="w-10 h-10 text-blue-500" />
            </div>
            <div className="text-slate-800 font-black text-xl uppercase tracking-wide">Hiện tại bạn không có bài tập nào mới!</div>
            <p className="text-slate-600 font-bold text-sm mt-2">Hãy vào phòng luyện tập để tự do khám phá các hàm tính toán ngay nào!</p>
            <Button size="lg" className="mt-6 px-10 h-16 rounded-2xl shadow-xl shadow-blue-500/30 text-lg font-black uppercase tracking-wider bg-gradient-to-r from-blue-600 to-indigo-600 border-2 border-b-6 border-blue-900 active:border-b-2 active:translate-y-1" onClick={() => navigate('/student/game')}>
              🚀 VÀO PHÒNG LUYỆN TẬP NGAY
            </Button>
          </div>
        </div>
      </section>

      {/* Modal View for Individual Student Result */}
      {showResultModal && (
        <StudentResultModal
          studentName={student.name}
          onClose={() => setShowResultModal(false)}
        />
      )}
    </div>
  );
}

function ModuleCard({ title, subtitle, description, icon, borderColor, shadowColor, textColor, onClick }: { title: string, subtitle: string, description: string, icon: React.ReactNode, borderColor: string, shadowColor: string, textColor: string, onClick: () => void }) {
  return (
    <motion.div 
      onClick={onClick}
      whileHover={{ y: -6, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        "cursor-pointer bg-white border-4 rounded-3xl p-8 flex flex-col justify-between transition-all duration-200 relative overflow-hidden group",
        borderColor,
        shadowColor
      )}
    >
      <div>
        <div className="flex justify-between items-start mb-6">
          <div className="w-20 h-20 rounded-2xl bg-slate-50 border-2 border-slate-100 flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
            {icon}
          </div>
          <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-600 font-extrabold text-xs tracking-wider uppercase">
            {subtitle}
          </span>
        </div>
        <h3 
          className="text-3xl font-black tracking-tight mb-3 uppercase"
          style={{
            color: textColor === 'text-blue-600' ? '#2563eb' : textColor === 'text-purple-600' ? '#9333ea' : '#d97706',
            textShadow: '0 2px 0 rgba(0,0,0,0.1)'
          }}
        >
          {title}
        </h3>
        <p className="text-slate-600 font-medium leading-relaxed text-sm">{description}</p>
      </div>
      
      <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
        <span className={cn("font-black text-sm uppercase tracking-wider", textColor)}>Khám phá ngay →</span>
      </div>
    </motion.div>
  );
}

