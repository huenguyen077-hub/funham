import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle2, Search, Cpu, Sparkles, Gamepad2, Award, 
  ArrowRight, RefreshCw, BarChart3, AlertCircle, ShieldCheck, Zap
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { cn } from '../../utils';
import confetti from 'canvas-confetti';

export function LearningLoopPage() {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [userFormula, setUserFormula] = useState<string>('=SUM(B2:B10');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [practiceDone, setPracticeDone] = useState<boolean>(false);
  const [practiceAnswer, setPracticeAnswer] = useState<string>('');

  const triggerConfetti = () => {
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 }
    });
  };

  const steps = [
    {
      id: 1,
      title: '1. Kiểm Tra',
      subtitle: 'Khảo sát năng lực & Phát hiện lỗi sai',
      icon: Search,
      color: 'from-amber-500 to-orange-600',
      borderColor: 'border-amber-400',
      badgeBg: 'bg-amber-100 text-amber-800'
    },
    {
      id: 2,
      title: '2. Phân Tích',
      subtitle: 'AI chẩn đoán nguyên nhân hổng kiến thức',
      icon: Cpu,
      color: 'from-blue-600 to-indigo-600',
      borderColor: 'border-blue-400',
      badgeBg: 'bg-blue-100 text-blue-800'
    },
    {
      id: 3,
      title: '3. Cá Nhân Hóa',
      subtitle: 'Thiết kế lộ trình học riêng biệt cho học sinh',
      icon: Sparkles,
      color: 'from-purple-600 to-pink-600',
      borderColor: 'border-purple-400',
      badgeBg: 'bg-purple-100 text-purple-800'
    },
    {
      id: 4,
      title: '4. Luyện',
      subtitle: 'Thực hành qua minigame & bảng tính tương tác',
      icon: Gamepad2,
      color: 'from-emerald-500 to-teal-600',
      borderColor: 'border-emerald-400',
      badgeBg: 'bg-emerald-100 text-emerald-800'
    },
    {
      id: 5,
      title: '5. Đánh Giá',
      subtitle: 'Đo lường tiến bộ real-time & chứng nhận thành thạo',
      icon: Award,
      color: 'from-cyan-500 to-blue-600',
      borderColor: 'border-cyan-400',
      badgeBg: 'bg-cyan-100 text-cyan-800'
    }
  ];

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (userFormula.includes('(') && !userFormula.includes(')')) {
      setAnalysisResult('⚠️ Lỗi cú pháp: Thiếu dấu ngoặc đơn đóng ")" ở cuối hàm SUM.');
    } else if (userFormula.includes(';')) {
      setAnalysisResult('⚠️ Lỗi tham số: Dùng dấu chấm phẩy ";" thay vì dấu hai chấm ":" cho vùng dữ liệu.');
    } else {
      setAnalysisResult('✅ Cú pháp hợp lệ! Không phát hiện lỗi.');
    }
  };

  const handlePracticeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (practiceAnswer.trim() === '=SUM(B2:B10)') {
      setPracticeDone(true);
      triggerConfetti();
    }
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 p-8 md:p-12 rounded-3xl border-4 border-b-8 border-indigo-900 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 -mt-12 -mr-12 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white/20 rounded-full text-xs font-black uppercase tracking-widest mb-4 border border-white/30">
            <span>🔄 HỆ THỐNG 5 BƯỚC CHUẨN FUNHAM</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black tracking-wider uppercase mb-4" style={{ textShadow: '0 3px 6px rgba(0,0,0,0.3)' }}>
            Kiểm tra → Phân tích → Cá nhân hóa → Luyện → Đánh giá
          </h1>
          <p className="text-blue-100 font-extrabold text-lg md:text-xl leading-relaxed">
            Quy trình học tập khép kín giúp học sinh lớp 7 làm chủ hoàn toàn các hàm tính toán bảng điện tử một cách hiệu quả nhất!
          </p>
        </div>
      </section>

      {/* Step Navigator Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
        {steps.map((step) => {
          const Icon = step.icon;
          const isActive = activeStep === step.id;
          return (
            <button
              key={step.id}
              onClick={() => setActiveStep(step.id)}
              className={cn(
                "p-4 rounded-2xl border-3 border-b-6 text-left transition-all flex flex-col justify-between shadow-md",
                isActive 
                  ? "bg-gradient-to-br from-blue-600 to-indigo-700 text-white border-blue-900 scale-105 ring-4 ring-blue-400/40"
                  : "bg-white text-slate-800 border-slate-200 hover:bg-slate-50 hover:border-slate-300"
              )}
            >
              <div className="flex justify-between items-start mb-3">
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-inner font-black text-sm",
                  isActive ? "bg-white/25 border border-white/40" : "bg-gradient-to-r " + step.color
                )}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className={cn("text-xs font-black px-2 py-0.5 rounded-full", isActive ? "bg-white/25 text-white" : step.badgeBg)}>
                  Bước {step.id}
                </span>
              </div>
              <div className="font-black text-sm uppercase tracking-wide leading-tight">
                {step.title.replace(/^\d+\.\s*/, '')}
              </div>
              <div className={cn("text-xs mt-1 line-clamp-1 font-bold", isActive ? "text-blue-100" : "text-slate-500")}>
                {step.subtitle}
              </div>
            </button>
          );
        })}
      </div>

      {/* Step Detailed Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeStep}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.25 }}
        >
          {activeStep === 1 && (
            <Card className="p-8 md:p-10 border-4 border-b-8 border-amber-400 rounded-3xl bg-gradient-to-br from-amber-50/70 via-white to-orange-50/50 shadow-xl">
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-3xl shadow-lg border-2 border-white">
                    🔍
                  </div>
                  <div>
                    <span className="text-xs font-black px-3 py-1 bg-amber-200 text-amber-900 rounded-full uppercase tracking-widest">Bước 1 trong hệ thống</span>
                    <h2 className="text-3xl font-black text-slate-900 uppercase mt-1">1. Kiểm Tra & Phát Hiện Lỗi</h2>
                  </div>
                </div>

                <p className="text-slate-700 font-bold text-lg leading-relaxed">
                  Hệ thống thực hiện bài kiểm tra nhanh hoặc ghi nhận thao tác nhập công thức thực tế của học sinh trên bảng tính Tin học 7 để phát hiện ngay các điểm mù kiến thức.
                </p>

                <div className="bg-white p-6 rounded-2xl border-3 border-amber-300 shadow-sm space-y-4">
                  <div className="font-black text-slate-800 uppercase text-sm">🧪 Thử nghiệm nhập công thức bảng tính:</div>
                  <form onSubmit={handleAnalyze} className="space-y-3">
                    <div>
                      <label className="block text-xs font-black uppercase text-slate-600 mb-1">Nhập công thức hàm SUM:</label>
                      <div className="flex gap-3">
                        <input 
                          type="text" 
                          value={userFormula} 
                          onChange={(e) => setUserFormula(e.target.value)}
                          className="flex-1 px-4 py-3 rounded-xl border-3 border-slate-300 font-mono font-bold text-lg text-slate-900 focus:border-amber-500 outline-none"
                          placeholder="Ví dụ: =SUM(B2:B10)"
                        />
                        <Button type="submit" className="px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-black uppercase rounded-xl border-2 border-b-4 border-amber-900">
                          Kiểm Tra
                        </Button>
                      </div>
                    </div>
                  </form>

                  {analysisResult && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 bg-amber-100 border-2 border-amber-300 rounded-xl text-amber-900 font-bold text-sm">
                      {analysisResult}
                    </motion.div>
                  )}
                </div>

                <div className="pt-4 flex justify-end">
                  <Button onClick={() => setActiveStep(2)} className="px-8 py-4 bg-amber-600 hover:bg-amber-700 text-white font-black uppercase tracking-wider rounded-2xl shadow-lg border-2 border-b-6 border-amber-900 flex items-center gap-2">
                    <span>Bước Tiếp: Phân Tích (AI)</span>
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {activeStep === 2 && (
            <Card className="p-8 md:p-10 border-4 border-b-8 border-blue-500 rounded-3xl bg-gradient-to-br from-blue-50/70 via-white to-indigo-50/50 shadow-xl">
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center text-3xl shadow-lg border-2 border-white">
                    🤖
                  </div>
                  <div>
                    <span className="text-xs font-black px-3 py-1 bg-blue-200 text-blue-900 rounded-full uppercase tracking-widest">Bước 2 trong hệ thống</span>
                    <h2 className="text-3xl font-black text-slate-900 uppercase mt-1">2. Phân Tích Chuyên Sâu</h2>
                  </div>
                </div>

                <p className="text-slate-700 font-bold text-lg leading-relaxed">
                  Công nghệ AI chẩn đoán của FUNHAM mổ xẻ cấu trúc công thức, phân loại chính xác dạng lỗi (cú pháp, tham số, tên hàm) và xác định mức độ hiểu bài của học sinh.
                </p>

                <div className="bg-slate-900 text-white p-6 rounded-2xl border-3 border-blue-400 font-mono shadow-inner space-y-3">
                  <div className="flex items-center justify-between text-xs text-blue-300 border-b border-slate-700 pb-2">
                    <span>⚡ FUNHAM AI DIAGNOSTIC ENGINE</span>
                    <span>STATUS: ANALYZED 🎯</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-red-400">&gt; Target Formula:</span> <span className="text-yellow-300">=SUM(B2:B10</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-cyan-400">&gt; Error Severity:</span> <span className="text-orange-300">Level 2 (Critical Syntax Gap)</span>
                  </div>
                  <div className="text-sm bg-blue-950/80 p-3 rounded-xl border border-blue-800 text-blue-200">
                    💡 <span className="font-bold text-white">Kết luận phân tích:</span> Học sinh thường xuyên quên đóng ngoặc đơn trong các hàm tính toán nhóm. Cần kích hoạt lộ trình rèn luyện kỹ năng cú pháp cơ bản.
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <Button variant="outline" onClick={() => setActiveStep(1)} className="font-black uppercase">← Quay lại</Button>
                  <Button onClick={() => setActiveStep(3)} className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-wider rounded-2xl shadow-lg border-2 border-b-6 border-blue-900 flex items-center gap-2">
                    <span>Bước Tiếp: Cá Nhân Hóa</span>
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {activeStep === 3 && (
            <Card className="p-8 md:p-10 border-4 border-b-8 border-purple-500 rounded-3xl bg-gradient-to-br from-purple-50/70 via-white to-pink-50/50 shadow-xl">
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-purple-600 text-white flex items-center justify-center text-3xl shadow-lg border-2 border-white">
                    🎯
                  </div>
                  <div>
                    <span className="text-xs font-black px-3 py-1 bg-purple-200 text-purple-900 rounded-full uppercase tracking-widest">Bước 3 trong hệ thống</span>
                    <h2 className="text-3xl font-black text-slate-900 uppercase mt-1">3. Cá Nhân Hóa Lộ Trình</h2>
                  </div>
                </div>

                <p className="text-slate-700 font-bold text-lg leading-relaxed">
                  Dựa trên kết quả phân tích, hệ thống tự động thiết kế lộ trình học tập riêng biệt cho từng em, loại bỏ các kiến thức đã biết và tập trung chính xác vào điểm yếu.
                </p>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-white p-5 rounded-2xl border-3 border-purple-200 text-center shadow-sm">
                    <div className="text-3xl mb-2">⏱️</div>
                    <div className="font-black text-slate-900 text-base uppercase">Micro-Lesson 3 Phút</div>
                    <p className="text-xs text-slate-600 mt-1 font-bold">Video ngắn hướng dẫn chuẩn hóa dấu ngoặc trong Excel.</p>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border-3 border-purple-200 text-center shadow-sm">
                    <div className="text-3xl mb-2">🎮</div>
                    <div className="font-black text-slate-900 text-base uppercase">Bug Hunter Game</div>
                    <p className="text-xs text-slate-600 mt-1 font-bold">Trò chơi săn lỗi cú pháp bảng tính đối kháng.</p>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border-3 border-purple-200 text-center shadow-sm">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="font-black text-slate-900 text-base uppercase">Spreadsheet Lab</div>
                    <p className="text-xs text-slate-600 mt-1 font-bold">Thực hành trực tiếp trên bảng tính giả lập thông minh.</p>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <Button variant="outline" onClick={() => setActiveStep(2)} className="font-black uppercase">← Quay lại</Button>
                  <Button onClick={() => setActiveStep(4)} className="px-8 py-4 bg-purple-600 hover:bg-purple-700 text-white font-black uppercase tracking-wider rounded-2xl shadow-lg border-2 border-b-6 border-purple-900 flex items-center gap-2">
                    <span>Bước Tiếp: Luyện Tập</span>
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {activeStep === 4 && (
            <Card className="p-8 md:p-10 border-4 border-b-8 border-emerald-500 rounded-3xl bg-gradient-to-br from-emerald-50/70 via-white to-teal-50/50 shadow-xl">
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center text-3xl shadow-lg border-2 border-white">
                    🎮
                  </div>
                  <div>
                    <span className="text-xs font-black px-3 py-1 bg-emerald-200 text-emerald-900 rounded-full uppercase tracking-widest">Bước 4 trong hệ thống</span>
                    <h2 className="text-3xl font-black text-slate-900 uppercase mt-1">4. Luyện Tập Tương Tác</h2>
                  </div>
                </div>

                <p className="text-slate-700 font-bold text-lg leading-relaxed">
                  Học sinh thực hành trực tiếp qua các minigame và bài tập mô phỏng bảng tính được cá nhân hóa để khắc phục triệt để lỗi đã được phát hiện.
                </p>

                <div className="bg-white p-6 rounded-3xl border-4 border-emerald-300 shadow-md space-y-4">
                  <div className="font-black text-slate-800 uppercase text-base">🛠️ Thử thách sửa lỗi hàm SUM:</div>
                  <p className="text-sm font-bold text-slate-600">
                    Hãy nhập công thức tính tổng từ ô B2 đến B10 đúng chuẩn (có đủ dấu ngoặc):
                  </p>

                  <form onSubmit={handlePracticeSubmit} className="space-y-3">
                    <div className="flex gap-3">
                      <input 
                        type="text" 
                        value={practiceAnswer} 
                        onChange={(e) => setPracticeAnswer(e.target.value)}
                        className="flex-1 px-4 py-3 rounded-xl border-3 border-slate-300 font-mono text-lg font-bold text-slate-900 focus:border-emerald-500 outline-none"
                        placeholder="Nhập công thức..."
                      />
                      <Button type="submit" className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black uppercase rounded-xl border-2 border-b-4 border-emerald-900">
                        Nộp Bài
                      </Button>
                    </div>
                  </form>

                  {practiceDone && (
                    <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="p-4 bg-emerald-100 border-2 border-emerald-300 rounded-xl text-emerald-900 font-bold text-base flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-emerald-600 flex-shrink-0" />
                      <span>🎉 Xuất sắc! Bạn đã vượt qua thử thách luyện tập và thành thạo cú pháp hàm SUM.</span>
                    </motion.div>
                  )}
                </div>

                <div className="pt-4 flex justify-between">
                  <Button variant="outline" onClick={() => setActiveStep(3)} className="font-black uppercase">← Quay lại</Button>
                  <Button onClick={() => setActiveStep(5)} className="px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black uppercase tracking-wider rounded-2xl shadow-lg border-2 border-b-6 border-emerald-900 flex items-center gap-2">
                    <span>Bước Tiếp: Đánh Giá</span>
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {activeStep === 5 && (
            <Card className="p-8 md:p-10 border-4 border-b-8 border-cyan-500 rounded-3xl bg-gradient-to-br from-cyan-50/70 via-white to-blue-50/50 shadow-xl">
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-cyan-600 text-white flex items-center justify-center text-3xl shadow-lg border-2 border-white">
                    🏆
                  </div>
                  <div>
                    <span className="text-xs font-black px-3 py-1 bg-cyan-200 text-cyan-900 rounded-full uppercase tracking-widest">Bước 5 trong hệ thống</span>
                    <h2 className="text-3xl font-black text-slate-900 uppercase mt-1">5. Đánh Giá & Đo Lường Tiến Bộ</h2>
                  </div>
                </div>

                <p className="text-slate-700 font-bold text-lg leading-relaxed">
                  Hệ thống tổng kết kết quả phiên học, cập nhật biểu đồ năng lực kỹ năng và cấp chứng nhận hoàn thành mục tiêu cho học sinh.
                </p>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-white p-6 rounded-2xl border-3 border-cyan-200 shadow-sm space-y-4">
                    <div className="font-black text-slate-800 uppercase text-base flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-cyan-600" />
                      <span>Biểu đồ đo lường kỹ năng</span>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-xs font-black text-slate-700 mb-1">
                          <span>HÀM SUM (Tổng)</span>
                          <span>98% (Đã thành thạo)</span>
                        </div>
                        <div className="h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                          <div className="h-full bg-emerald-500 rounded-full w-[98%]" />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs font-black text-slate-700 mb-1">
                          <span>HÀM AVERAGE (Trung bình)</span>
                          <span>92% (Rất tốt)</span>
                        </div>
                        <div className="h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                          <div className="h-full bg-cyan-500 rounded-full w-[92%]" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-cyan-600 to-blue-700 text-white p-6 rounded-2xl border-3 border-cyan-800 shadow-md flex flex-col justify-between">
                    <div>
                      <div className="text-cyan-200 font-black uppercase text-xs">⭐ Đánh giá tổng kết</div>
                      <div className="text-3xl font-black mt-2">+200 XP Thưởng</div>
                      <p className="text-cyan-100 text-xs font-bold mt-2">Hoàn thành xuất sắc vòng lặp 5 bước. Nâng hạng thành công!</p>
                    </div>
                    <div className="pt-4 border-t border-cyan-500/40 flex items-center gap-2 text-xs font-black text-cyan-200 uppercase">
                      <span>🛡️ Huy hiệu: Master of Spreadsheet Evaluated!</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <Button variant="outline" onClick={() => setActiveStep(4)} className="font-black uppercase">← Quay lại</Button>
                  <Button onClick={() => setActiveStep(1)} className="px-8 py-4 bg-slate-800 hover:bg-slate-900 text-white font-black uppercase tracking-wider rounded-2xl shadow-lg border-2 border-b-6 border-slate-950 flex items-center gap-2">
                    <span>🔄 Xem Lại Từ Đầu</span>
                    <RefreshCw className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
