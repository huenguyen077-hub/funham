import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ClipboardCheck, 
  ArrowRight, 
  CheckCircle2, 
  XCircle, 
  Trophy, 
  RotateCcw, 
  TrendingUp, 
  Sparkles, 
  BookOpen, 
  HelpCircle,
  ShieldCheck,
  Award,
  AlertCircle,
  RefreshCw,
  Wifi,
  WifiOff,
  CloudCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { useAuthStore } from '../../store/authStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { useDataStore } from '../../store/dataStore';
import { PRE_TEST_QUESTIONS, POST_TEST_QUESTIONS } from '../../data/assessmentQuestions';
import { cn } from '../../utils';
import { syncSaveAttempt, syncRegisterStudent, ErrorEventRecord } from '../../services/databaseService';
import { isSupabaseConfigured } from '../../services/supabaseClient';

export function AssessmentPage() {
  const { user } = useAuthStore();
  const { updateStudent } = useDataStore();
  const { submitAssessment, prePostRecords } = useEvidenceStore();

  const [activeTestType, setActiveTestType] = useState<'pre' | 'post'>('pre');
  const questions = activeTestType === 'pre' ? PRE_TEST_QUESTIONS : POST_TEST_QUESTIONS;

  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState<number | null>(null);

  // Sync state with cloud database
  const [syncState, setSyncState] = useState<{
    status: 'idle' | 'saving' | 'synced' | 'offline_queued' | 'error';
    attemptId?: string;
    message?: string;
  }>({ status: 'idle' });

  // Tìm kết quả trước đó của học sinh trong prePostRecords
  const studentName = user?.name || 'Học sinh';
  const existingRecord = prePostRecords.find(
    r => r.studentName.toLowerCase() === studentName.toLowerCase()
  );

  const currentQ = questions[currentIdx];
  const totalQuestions = questions.length;
  const answeredCount = Object.keys(answers).length;

  const handleSelectOption = (opt: string) => {
    setAnswers(prev => ({ ...prev, [currentQ.id]: opt }));
  };

  const handleNext = () => {
    if (currentIdx < totalQuestions - 1) {
      setCurrentIdx(currentIdx + 1);
    }
  };

  const handlePrev = () => {
    if (currentIdx > 0) {
      setCurrentIdx(currentIdx - 1);
    }
  };

  const sendResultToDatabase = async (calculatedScore: number, errorEvents: ErrorEventRecord[]) => {
    setSyncState({
      status: 'saving',
      message: 'Đang gửi kết quả lên hệ thống máy chủ...',
    });

    const studentId = user?.id || `std_${Date.now()}`;
    const studentCode = (user as any)?.studentCode || `HS_${studentName.replace(/[^a-zA-Z0-9]/g, '').slice(0, 6) || '01'}`;
    const className = (user as any)?.className || '7A1';
    const isDemo = Boolean((user as any)?.isDemo);

    try {
      // 1. Ensure student is registered with proper student ID in database
      let resolvedStudentId = studentId;
      try {
        const reg = await syncRegisterStudent(className, studentCode, studentName);
        if (reg?.id) {
          resolvedStudentId = reg.id;
        }
      } catch (e) {
        console.warn('Student register sync warning:', e);
      }

      // 2. Save attempt to Supabase / central storage
      const res = await syncSaveAttempt(
        {
          student_id: resolvedStudentId,
          activity_id: activeTestType === 'pre' ? 'pre_test' : 'post_test',
          activity_type: activeTestType === 'pre' ? 'pre_assessment' : 'post_assessment',
          score: calculatedScore,
          max_score: 10,
          started_at: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
          completed_at: new Date().toISOString(),
          is_demo: isDemo,
        },
        errorEvents,
        { studentCode, classCode: className, displayName: studentName }
      );

      if (res.success && !res.offline) {
        setSyncState({
          status: 'synced',
          attemptId: res.attemptId,
          message: `Đã lưu kết quả thành công lên cơ sở dữ liệu máy chủ! (Mã bài nộp: ${res.attemptId?.slice(0, 8)})`,
        });
      } else if (res.offline) {
        setSyncState({
          status: 'offline_queued',
          message: res.error || 'Chưa đồng bộ máy chủ: Đã lưu an toàn trong bộ nhớ thiết bị. Hệ thống sẽ tự động gửi lại khi có mạng.',
        });
      } else {
        setSyncState({
          status: 'error',
          message: res.error || 'Lỗi khi lưu kết quả lên máy chủ. Bấm "Thử gửi lại" để thử lại.',
        });
      }
    } catch (err: any) {
      console.error('Error submitting assessment to server:', err);
      setSyncState({
        status: 'offline_queued',
        message: 'Chưa đồng bộ: Đã lưu tạm bộ nhớ thiết bị do mất kết nối mạng. Sẽ tự động gửi lại khi có mạng.',
      });
    }
  };

  const handleSubmit = async () => {
    let correctCount = 0;
    const errorEvents: ErrorEventRecord[] = [];

    questions.forEach((q) => {
      const userAns = (answers[q.id] || '').trim().toUpperCase();
      const correctAns = q.correctAnswer.trim().toUpperCase();
      if (userAns === correctAns) {
        correctCount++;
      } else {
        // Map question topic to error code
        const code = q.topic === 'SUM' ? 'E04' : q.topic === 'AVERAGE' ? 'E02' : q.topic === 'MAX' ? 'E03' : q.topic === 'COUNT' ? 'E06' : 'E01';
        errorEvents.push({
          error_code: code,
          corrected: false,
          hint_count: 0,
        });
      }
    });

    const calculatedScore = Number(((correctCount / totalQuestions) * 10).toFixed(1));
    setScore(calculatedScore);
    setIsSubmitted(true);

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });

    // Local Evidence Store for immediate reactive updates in UI
    const studentId = user?.id || 'hs_current';
    const className = (user as any)?.className || '7A1';

    submitAssessment({
      studentId,
      studentName,
      className,
      testType: activeTestType,
      score: calculatedScore
    });

    // Thưởng XP
    if (user && user.role === 'student') {
      const studentXp = (user as any).xp ?? 950;
      updateStudent(studentId, { xp: studentXp + calculatedScore * 15 });
    }

    // Gửi lên hệ thống máy chủ / Supabase
    await sendResultToDatabase(calculatedScore, errorEvents);
  };

  const handleRetake = (type: 'pre' | 'post') => {
    setActiveTestType(type);
    setCurrentIdx(0);
    setAnswers({});
    setIsSubmitted(false);
    setScore(null);
    setSyncState({ status: 'idle' });
  };

  // Tính Normalized Gain nếu đã có cả Pre và Post
  const preScoreVal = activeTestType === 'post' && existingRecord ? existingRecord.preScore : (existingRecord?.preScore ?? 5.0);
  const postScoreVal = score !== null && activeTestType === 'post' ? score : (existingRecord?.postScore ?? 9.0);
  const calculatedGain = preScoreVal < 10 
    ? Number((((postScoreVal - preScoreVal) / (10 - preScoreVal)) * 100).toFixed(1))
    : 100;

  return (
    <div className="space-y-8 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-blue-700 to-purple-800 p-6 md:p-8 rounded-3xl border-4 border-b-8 border-indigo-950 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-80 h-80 bg-cyan-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase tracking-wider border border-yellow-400/30">
              <ClipboardCheck className="w-4 h-4 text-yellow-300" />
              <span>ĐÁNH GIÁ NĂNG LỰC TOÀN DIỆN TIN HỌC 7</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black uppercase tracking-wider text-yellow-300 drop-shadow-md">
              📝 KHẢO SÁT ĐẦU VÀO & ĐÁNH GIÁ ĐẦU RA
            </h1>
            <p className="text-blue-100 text-xs md:text-sm font-bold leading-relaxed">
              Bài đánh giá chuẩn đầu ra môn Tin học 7 - Chủ đề 4: Ứng dụng tin học (Bảng tính điện tử). Kết quả sẽ được lưu và chuyển tiếp trực tiếp đến Giáo viên để theo dõi độ tiến bộ của em.
            </p>
          </div>

          <div className="flex flex-col gap-2 shrink-0">
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-right">
              <div className="text-xs text-blue-200 font-bold uppercase">Học sinh làm bài:</div>
              <div className="text-lg font-black text-white">{studentName}</div>
              <div className="text-xs font-mono text-yellow-300 font-black">Lớp: {(user as any)?.className || '7A1'} • {(user as any)?.studentCode ? `Mã: ${(user as any)?.studentCode}` : ''}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Selector: Pre-Test vs Post-Test */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-2 bg-slate-200 rounded-2xl border-2 border-slate-300">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleRetake('pre')}
            className={cn(
              "px-6 py-3 rounded-xl font-black text-xs md:text-sm uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2",
              activeTestType === 'pre'
                ? "bg-blue-600 text-white shadow-md border-2 border-blue-900"
                : "text-slate-700 hover:bg-slate-300"
            )}
          >
            <span>📋</span>
            <span>1. Khảo sát Đầu Vào (Pre-Test)</span>
          </button>

          <button
            onClick={() => handleRetake('post')}
            className={cn(
              "px-6 py-3 rounded-xl font-black text-xs md:text-sm uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2",
              activeTestType === 'post'
                ? "bg-emerald-600 text-white shadow-md border-2 border-emerald-900"
                : "text-slate-700 hover:bg-slate-300"
            )}
          >
            <span>🎯</span>
            <span>2. Đánh giá Đầu Ra (Post-Test)</span>
          </button>
        </div>

        <div className="text-xs font-bold text-slate-600 px-3">
          Tiến độ: <strong className="text-blue-700">{answeredCount}</strong> / {totalQuestions} câu
        </div>
      </div>

      {/* Progress Dots Bar */}
      <div className="bg-white p-4 rounded-2xl border-2 border-slate-300 shadow-sm">
        <div className="flex items-center justify-between gap-2 overflow-x-auto py-1">
          {questions.map((q, idx) => {
            const isAnswered = answers[q.id] !== undefined;
            const isCurrent = currentIdx === idx;

            return (
              <button
                key={q.id}
                onClick={() => !isSubmitted && setCurrentIdx(idx)}
                disabled={isSubmitted}
                className={cn(
                  "w-9 h-9 rounded-xl font-black text-xs flex items-center justify-center transition-all shrink-0 border-2",
                  isCurrent
                    ? "bg-blue-600 text-white border-blue-900 scale-110 shadow-md ring-2 ring-blue-300"
                    : isAnswered
                      ? "bg-emerald-500 text-white border-emerald-700"
                      : "bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200"
                )}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Question View or Results View */}
      {!isSubmitted ? (
        <Card className="bg-white p-6 md:p-8 rounded-3xl border-4 border-b-8 border-slate-300 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b-2 border-slate-100 pb-4">
          <div>
            <span className="text-xs font-black uppercase text-blue-600 tracking-wider">
              Câu hỏi {currentIdx + 1} / {totalQuestions}
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-900 mt-1">
              {currentQ.title}
            </h2>
          </div>
          <Badge className="bg-slate-100 text-slate-700 font-bold border-slate-300">
            Dạng: {currentQ.type === 'multiple_choice' ? 'Trắc nghiệm' : currentQ.type === 'bug_detect' ? 'Soát lỗi' : currentQ.type === 'formula_input' ? 'Điền công thức' : currentQ.type === 'function_select' ? 'Chọn hàm' : 'Giải thích kết quả'}
          </Badge>
        </div>

        {/* Prompt */}
        <div className="p-5 bg-blue-50/70 rounded-2xl border-2 border-blue-200 text-blue-950 font-bold text-base leading-relaxed">
          {currentQ.prompt}
        </div>

        {/* Options or Text Input */}
        {currentQ.options ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {currentQ.options.map((opt, oIdx) => {
              const isSelected = answers[currentQ.id] === opt;
              return (
                <button
                  key={oIdx}
                  onClick={() => handleSelectOption(opt)}
                  className={cn(
                    "p-4 rounded-2xl text-left font-bold text-sm border-3 transition-all cursor-pointer flex items-center justify-between gap-3",
                    isSelected
                      ? "bg-blue-600 text-white border-blue-900 shadow-lg scale-102"
                      : "bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100 hover:border-slate-300"
                  )}
                >
                  <span className="flex-1">{opt}</span>
                  <div className={cn(
                    "w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0",
                    isSelected ? "border-white bg-white/20 text-white" : "border-slate-300"
                  )}>
                    {isSelected && <span className="w-2.5 h-2.5 rounded-full bg-white" />}
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="space-y-3 pt-2">
            <label className="block text-xs font-black uppercase text-slate-600">
              Nhập công thức bảng tính của em (Bắt đầu bằng dấu =):
            </label>
            <input
              type="text"
              value={answers[currentQ.id] || ''}
              onChange={(e) => setAnswers(prev => ({ ...prev, [currentQ.id]: e.target.value }))}
              placeholder="Ví dụ: =MIN(C2:C35)"
              className="w-full px-5 py-4 bg-slate-50 text-blue-900 font-mono text-base font-bold rounded-2xl border-2 border-slate-300 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-500/20"
            />
          </div>
        )}

        {/* Navigation Controls */}
        <div className="flex items-center justify-between pt-6 border-t-2 border-slate-100">
          <Button
            variant="outline"
            onClick={handlePrev}
            disabled={currentIdx === 0}
            className="text-xs uppercase font-black px-5 py-3 rounded-xl border-slate-300 cursor-pointer"
          >
            Câu trước
          </Button>

          {currentIdx < totalQuestions - 1 ? (
            <Button
              onClick={handleNext}
              className="bg-blue-600 hover:bg-blue-500 text-white text-xs uppercase font-black px-6 py-3 rounded-xl cursor-pointer"
            >
              Câu tiếp theo ➔
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={answeredCount < totalQuestions}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs uppercase font-black px-8 py-3.5 rounded-xl shadow-lg border-2 border-b-4 border-emerald-900 cursor-pointer"
            >
              Nộp bài & Chấm điểm 🏁
            </Button>
          )}
        </div>
      </Card>
      ) : (
        <div className="space-y-8">
          <Card className="bg-gradient-to-br from-indigo-900 via-slate-900 to-purple-950 p-6 md:p-8 rounded-3xl border-4 border-b-8 border-indigo-950 text-white shadow-2xl text-center space-y-6">

            <div className="space-y-2">
              <span className="inline-block px-4 py-1 bg-white/20 text-yellow-300 rounded-full text-xs font-black uppercase tracking-widest border border-white/20">
                KẾT QUẢ ĐÁNH GIÁ CHUẨN ĐẦU RA TIN HỌC 7
              </span>
              <h2 className="text-4xl md:text-5xl font-black uppercase text-yellow-300">
                ĐIỂM SỐ: {score} / 10
              </h2>
              <p className="text-slate-300 text-sm max-w-md mx-auto font-bold">
                {score && score >= 8
                  ? 'Tuyệt vời! Em đã nắm vững hoàn toàn các hàm tính toán cơ bản môn Tin học 7.'
                  : score && score >= 5
                    ? 'Khá tốt! Em đã hiểu bản chất các hàm nhưng cần chú ý thêm về cú pháp vùng dữ liệu.'
                    : 'Cần cố gắng thêm! Hãy quay lại Phòng Khám Công Thức để Trợ lý AI hướng dẫn em sửa các lỗi thường gặp nhé!'}
              </p>
            </div>

            {/* MANDATORY SYNC STATUS BANNER (SECTION IV) */}
            <div className="max-w-xl mx-auto p-4 rounded-2xl border-2 text-xs font-bold transition-all">
              {syncState.status === 'saving' && (
                <div className="bg-blue-900/60 border-blue-400 text-blue-200 flex items-center justify-center gap-2 p-3 rounded-xl">
                  <RefreshCw className="w-4 h-4 animate-spin text-blue-300" />
                  <span>Đang đồng bộ kết quả lên hệ thống máy chủ giáo viên...</span>
                </div>
              )}

              {syncState.status === 'synced' && (
                <div className="bg-emerald-900/60 border-emerald-400 text-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div className="text-left">
                      <div className="font-black text-white">ĐÃ LƯU KẾT QUẢ VÀO HỆ THỐNG MÁY CHỦ THÀNH CÔNG</div>
                      <div className="text-[11px] text-emerald-300 font-normal">
                        Giáo viên có thể xem trực tiếp kết quả của em trên Dashboard ở bất kỳ thiết bị nào.
                      </div>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-800 text-emerald-100 rounded-lg text-[10px] font-mono">
                    Đã đồng bộ
                  </span>
                </div>
              )}

              {syncState.status === 'offline_queued' && (
                <div className={cn(
                  "border-2 flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl",
                  isSupabaseConfigured()
                    ? "bg-amber-900/70 border-amber-400 text-amber-200"
                    : "bg-emerald-900/80 border-emerald-400 text-emerald-100"
                )}>
                  <div className="flex items-center gap-2">
                    {isSupabaseConfigured() ? (
                      <WifiOff className="w-5 h-5 text-amber-400 shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
                    )}
                    <div className="text-left">
                      <div className="font-black">
                        {isSupabaseConfigured() ? 'TRẠNG THÁI: CHƯA ĐỒNG BỘ MÁY CHỦ' : '✅ ĐÃ LƯU KẾT QUẢ AN TOÀN TRÊN THIẾT BỊ'}
                      </div>
                      <div className="text-[11px] opacity-90 font-normal">
                        {isSupabaseConfigured()
                          ? 'Đã lưu an toàn trong bộ nhớ thiết bị. Hệ thống sẽ tự động gửi khi kết nối Internet.'
                          : 'Hệ thống đang hoạt động ở chế độ nội bộ. Điểm số của em đã được ghi nhận đầy đủ trên thiết bị này.'}
                      </div>
                    </div>
                  </div>
                  {isSupabaseConfigured() && (
                    <button
                      onClick={() => sendResultToDatabase(score || 0, [])}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase cursor-pointer shrink-0"
                    >
                      Thử gửi lại ngay
                    </button>
                  )}
                </div>
              )}

              {syncState.status === 'error' && (
                <div className="bg-rose-900/70 border-rose-400 text-rose-200 flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    <div className="text-left">
                      <div className="font-black text-rose-100">LỖI ĐỒNG BỘ: {syncState.message}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => sendResultToDatabase(score || 0, [])}
                    className="px-3 py-1.5 bg-rose-500 hover:bg-rose-400 text-white font-black rounded-xl text-xs uppercase cursor-pointer"
                  >
                    Thử gửi lại
                  </button>
                </div>
              )}
            </div>

            {/* Comparison Metrics if Post-Test */}
            {activeTestType === 'post' && (
              <div className="max-w-xl mx-auto p-5 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-xs text-blue-200 font-bold uppercase">Điểm Đầu Vào (Pre)</div>
                  <div className="text-2xl font-black text-amber-300">{preScoreVal} / 10</div>
                </div>
                <div>
                  <div className="text-xs text-blue-200 font-bold uppercase">Điểm Đầu Ra (Post)</div>
                  <div className="text-2xl font-black text-emerald-300">{postScoreVal} / 10</div>
                </div>
                <div>
                  <div className="text-xs text-blue-200 font-bold uppercase">Độ Tăng Trưởng (Gain)</div>
                  <div className="text-2xl font-black text-cyan-300">+{calculatedGain}%</div>
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Button
                onClick={() => handleRetake(activeTestType)}
                className="bg-white/20 hover:bg-white/30 text-white font-black text-xs uppercase px-6 py-3 rounded-xl border border-white/30 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 mr-2" /> Làm lại bài kiểm tra
              </Button>
              {activeTestType === 'pre' && (
                <Button
                  onClick={() => handleRetake('post')}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase px-6 py-3 rounded-xl shadow-lg cursor-pointer"
                >
                  Tiếp tục: Làm Bài Đánh Giá Đầu Ra (Post-Test) ➔
                </Button>
              )}
            </div>
          </Card>

          {/* Detailed Question Review */}
          <div className="space-y-4">
            <h3 className="text-xl font-black uppercase text-slate-800 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span>CHI TIẾT ĐÁP ÁN & GIẢI THÍCH SƯ PHẠM</span>
            </h3>

            {questions.map((q, idx) => {
              const userAns = (answers[q.id] || '').trim().toUpperCase();
              const correctAns = q.correctAnswer.trim().toUpperCase();
              const isCorrect = userAns === correctAns;

              return (
                <Card key={q.id} className="p-6 rounded-3xl border-3 border-slate-200 shadow-md space-y-3 bg-white">
                  <div className="flex items-start justify-between gap-4">
                    <span className="font-black text-xs text-slate-500 uppercase">
                      Câu {idx + 1} • {q.topic}
                    </span>
                    <Badge className={isCorrect ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}>
                      {isCorrect ? '✅ ĐÚNG' : '❌ CHƯA ĐÚNG'}
                    </Badge>
                  </div>

                  <p className="font-bold text-slate-900 text-sm">{q.prompt}</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-bold pt-2">
                    <div className={cn(
                      "p-3 rounded-xl border",
                      isCorrect ? "bg-emerald-50 border-emerald-300 text-emerald-900" : "bg-rose-50 border-rose-300 text-rose-900"
                    )}>
                      <span className="block text-[10px] uppercase font-black text-slate-500 mb-0.5">Câu trả lời của em:</span>
                      <span>{answers[q.id] || '(Chưa trả lời)'}</span>
                    </div>

                    <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-300 text-emerald-950">
                      <span className="block text-[10px] uppercase font-black text-emerald-700 mb-0.5">Đáp án đúng chuẩn SGK:</span>
                      <span>{q.correctAnswer}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-blue-900 text-xs font-medium leading-relaxed">
                    <strong className="text-blue-950 font-bold block mb-0.5">💡 Giải thích chi tiết:</strong>
                    {q.explanation}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
