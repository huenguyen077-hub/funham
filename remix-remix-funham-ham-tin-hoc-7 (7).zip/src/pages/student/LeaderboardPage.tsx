import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Trophy, 
  Medal, 
  Zap, 
  TrendingUp, 
  Layers, 
  Flame, 
  Target, 
  Filter
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { useDataStore } from '../../store/dataStore';
import { Student } from '../../types';
import { calculateLevel, cn } from '../../utils';

type LeaderboardTab = 'xp' | 'correctAnswers' | 'totalAttempts' | 'completionRate' | 'deltaScore';

export function LeaderboardPage() {
  const { user } = useAuthStore();
  const { studentsStat, registerStudent } = useEvidenceStore();
  const { students } = useDataStore();
  
  const [tab, setTab] = useState<LeaderboardTab>('xp');
  const [selectedClass, setSelectedClass] = useState<string>('all');

  // Tự động đồng bộ học sinh hiện tại và danh sách học sinh vào bảng vinh danh
  useEffect(() => {
    if (user && user.role === 'student') {
      const studentObj = user as Student;
      registerStudent({
        studentId: studentObj.id || 'hs_baonam',
        studentName: studentObj.name,
        className: studentObj.className || '7A1',
        xp: studentObj.xp,
      });
    }

    students.forEach((st) => {
      registerStudent({
        studentId: st.id,
        studentName: st.name,
        className: st.className,
        xp: st.xp,
      });
    });
  }, [user, students, registerStudent]);

  // Find personal student stat
  const currentStudentName = user?.name || 'Bảo Nam';
  const myStat = studentsStat.find((s) => 
    s.studentName.toLowerCase().trim() === currentStudentName.toLowerCase().trim() ||
    s.studentName.toLowerCase().includes(currentStudentName.toLowerCase()) ||
    currentStudentName.toLowerCase().includes(s.studentName.toLowerCase())
  ) || studentsStat[0];

  // Enrich students with computed XP based on performance and user state
  const enrichedStudents = studentsStat.map((s) => {
    const isThisUser = user && s.studentName.toLowerCase() === user.name.toLowerCase();
    const dataStoreMatch = students.find(ds => ds.name.toLowerCase() === s.studentName.toLowerCase());
    const baseComputed = Math.round(s.correctAnswers * 10 + s.deltaScore * 40 + s.completionRate * 2);
    
    let finalXp = baseComputed;
    if (isThisUser && (user as Student).xp) {
      finalXp = Math.max((user as Student).xp, baseComputed);
    } else if (dataStoreMatch && dataStoreMatch.xp) {
      finalXp = Math.max(dataStoreMatch.xp, baseComputed);
    }

    return {
      ...s,
      xp: finalXp,
      level: calculateLevel(finalXp),
    };
  });

  // Dynamic list of classes
  const availableClasses = Array.from(new Set(enrichedStudents.map(s => s.className).filter(Boolean))).sort();

  // Filter by class
  const filteredStudents = enrichedStudents.filter((s) => {
    return selectedClass === 'all' || s.className === selectedClass;
  });

  // Sort based on current tab
  const sortedStudents = [...filteredStudents].sort((a, b) => {
    if (tab === 'xp') return b.xp - a.xp;
    if (tab === 'correctAnswers') return b.correctAnswers - a.correctAnswers;
    if (tab === 'totalAttempts') return b.totalAttempts - a.totalAttempts;
    if (tab === 'completionRate') return b.completionRate - a.completionRate;
    if (tab === 'deltaScore') return b.deltaScore - a.deltaScore;
    return 0;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-16">
      {/* 3D Colorful Header Box */}
      <div className="text-center bg-gradient-to-r from-amber-400 via-orange-500 to-pink-500 py-6 px-8 rounded-3xl border-4 border-b-8 border-orange-700 shadow-xl relative overflow-hidden text-white">
        <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/20 rounded-full blur-xl pointer-events-none" />
        <h1 
          className="text-2xl md:text-4xl font-black tracking-wider uppercase drop-shadow-md flex items-center justify-center gap-3"
          style={{ textShadow: '0 3px 6px rgba(0,0,0,0.3)' }}
        >
          <span>🏆</span>
          <span>BẢNG VINH DANH VÀ XẾP HẠNG</span>
          <span>🌟</span>
        </h1>
      </div>

      {/* ========================================================================= */}
      {/* 🏆 BẢNG THI ĐUA TỔNG HỢP VỚI CÁC TAB XẾP HẠNG MINH CHỨNG */}
      {/* ========================================================================= */}
      <div className="space-y-4 pt-2">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          {/* 5 Tab Buttons Corresponding to the Evidence Metrics */}
          <div className="flex flex-wrap gap-2 p-1.5 bg-slate-200/80 rounded-2xl border-2 border-slate-300 shadow-inner w-full md:w-auto">
          <button
            onClick={() => setTab('xp')}
            className={cn(
              "px-4 py-2.5 rounded-xl font-black uppercase tracking-wider text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer",
              tab === 'xp'
                ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-2 border-blue-800 scale-102 shadow-md"
                : "bg-white text-slate-600 hover:bg-slate-50"
            )}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>Theo XP</span>
          </button>

          <button
            onClick={() => setTab('correctAnswers')}
            className={cn(
              "px-4 py-2.5 rounded-xl font-black uppercase tracking-wider text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer",
              tab === 'correctAnswers'
                ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-2 border-emerald-800 scale-102 shadow-md"
                : "bg-white text-slate-600 hover:bg-slate-50"
            )}
          >
            <Target className="w-3.5 h-3.5 text-emerald-300" />
            <span>Số câu đúng</span>
          </button>

          <button
            onClick={() => setTab('totalAttempts')}
            className={cn(
              "px-4 py-2.5 rounded-xl font-black uppercase tracking-wider text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer",
              tab === 'totalAttempts'
                ? "bg-gradient-to-r from-blue-500 to-cyan-600 text-white border-2 border-blue-800 scale-102 shadow-md"
                : "bg-white text-slate-600 hover:bg-slate-50"
            )}
          >
            <Flame className="w-3.5 h-3.5 text-orange-300 fill-orange-300" />
            <span>Số lần làm (Kiên trì)</span>
          </button>

          <button
            onClick={() => setTab('completionRate')}
            className={cn(
              "px-4 py-2.5 rounded-xl font-black uppercase tracking-wider text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer",
              tab === 'completionRate'
                ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white border-2 border-purple-800 scale-102 shadow-md"
                : "bg-white text-slate-600 hover:bg-slate-50"
            )}
          >
            <Layers className="w-3.5 h-3.5 text-purple-300" />
            <span>Mức hoàn thành</span>
          </button>

          <button
            onClick={() => setTab('deltaScore')}
            className={cn(
              "px-4 py-2.5 rounded-xl font-black uppercase tracking-wider text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer",
              tab === 'deltaScore'
                ? "bg-gradient-to-r from-cyan-600 to-blue-700 text-white border-2 border-cyan-800 scale-102 shadow-md"
                : "bg-white text-slate-600 hover:bg-slate-50"
            )}
          >
            <TrendingUp className="w-3.5 h-3.5 text-cyan-300" />
            <span>Tiến bộ Trước/Sau</span>
          </button>
        </div>

        {/* Filter by class */}
        <div className="flex items-center gap-2 bg-white px-3.5 py-2 rounded-2xl border-2 border-slate-200 shadow-xs shrink-0 self-end md:self-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-black text-slate-600 uppercase">Lớp:</span>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="bg-transparent text-xs font-black text-purple-700 focus:outline-none cursor-pointer"
          >
            <option value="all">Tất cả các lớp (Khối 7)</option>
            {availableClasses.map((cls) => (
              <option key={cls} value={cls}>Lớp {cls}</option>
            ))}
          </select>
        </div>
      </div>

        {/* Student List */}
        <div className="space-y-3 pt-2">
          {sortedStudents.map((student, index) => {
            const isCurrentUser = student.studentId === myStat.studentId || 
              student.studentName.toLowerCase() === currentStudentName.toLowerCase();
            
            const isFemale = /(thị|hoa|lan|linh|hương|mai|thảo|ngọc|diệu|nhi|quỳnh|vy|yến|hằng|thủy|trang|phương|nhung|hà|châu|giang|hiền|cúc)/i.test(student.studentName || '');
            const genderEmoji = isFemale ? '👧🌸' : '👦⚽';
            
            let rankStyle = "bg-slate-100 text-slate-600 border-slate-300";
            let icon = null;
            
            if (index === 0) {
              rankStyle = "bg-gradient-to-br from-yellow-300 to-amber-500 text-white border-amber-600 shadow-yellow-500/50";
              icon = <Trophy className="w-6 h-6 text-white drop-shadow" />;
            } else if (index === 1) {
              rankStyle = "bg-gradient-to-br from-slate-300 to-slate-400 text-white border-slate-500 shadow-slate-400/50";
              icon = <Medal className="w-6 h-6 text-white drop-shadow" />;
            } else if (index === 2) {
              rankStyle = "bg-gradient-to-br from-amber-600 to-amber-800 text-white border-amber-900 shadow-amber-700/50";
              icon = <Medal className="w-6 h-6 text-white drop-shadow" />;
            }

            return (
              <motion.div
                key={student.studentId}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.04 }}
              >
                <div className={cn(
                  "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-3xl border-3 border-b-6 shadow-md transition-all bg-white",
                  isCurrentUser ? 'border-blue-500 bg-blue-50/70 ring-4 ring-blue-500/20' : 'border-slate-200 hover:border-slate-300'
                )}>
                  {/* Left: Rank & Avatar & Info */}
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className={cn("w-12 h-12 flex items-center justify-center rounded-2xl font-black text-lg shrink-0 border-2 border-b-4 shadow-xs", rankStyle)}>
                      {icon || (index + 1)}
                    </div>
                    
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-400 to-pink-500 flex items-center justify-center text-2xl font-black shrink-0 border-2 border-b-4 border-orange-600 shadow-xs">
                      {genderEmoji}
                    </div>
                    
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-black text-slate-800 text-base md:text-lg uppercase tracking-wide truncate">
                          {student.studentName}
                        </h3>
                        {isCurrentUser && (
                          <span className="px-2 py-0.5 bg-blue-600 text-white text-[10px] font-black uppercase rounded-lg shadow-xs">
                            Em
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 font-bold mt-0.5 flex flex-wrap items-center gap-2">
                        <span>Lớp {student.className}</span>
                        <span>•</span>
                        <span className="text-purple-600 font-black">Level {student.level}</span>
                        <span>•</span>
                        <span className="text-amber-600 font-black">{student.xp} XP</span>
                      </div>
                    </div>
                  </div>

                  {/* Middle: 4 Evidence Badges */}
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                    {/* Badge 1: Câu đúng */}
                    <div className={cn(
                      "px-2.5 py-1 rounded-xl text-xs font-black border flex items-center gap-1",
                      tab === 'correctAnswers' 
                        ? "bg-emerald-500 text-white border-emerald-600 shadow-xs" 
                        : "bg-emerald-50 text-emerald-700 border-emerald-200"
                    )}>
                      <span>🎯</span>
                      <span>{student.correctAnswers} câu đúng</span>
                      <span className="opacity-70 text-[10px]">({student.accuracyRate}%)</span>
                    </div>

                    {/* Badge 2: Lần làm */}
                    <div className={cn(
                      "px-2.5 py-1 rounded-xl text-xs font-black border flex items-center gap-1",
                      tab === 'totalAttempts' 
                        ? "bg-blue-500 text-white border-blue-600 shadow-xs" 
                        : "bg-blue-50 text-blue-700 border-blue-200"
                    )}>
                      <span>🔥</span>
                      <span>{student.totalAttempts} lượt làm</span>
                    </div>

                    {/* Badge 3: Mức hoàn thành */}
                    <div className={cn(
                      "px-2.5 py-1 rounded-xl text-xs font-black border flex items-center gap-1",
                      tab === 'completionRate' 
                        ? "bg-purple-500 text-white border-purple-600 shadow-xs" 
                        : "bg-purple-50 text-purple-700 border-purple-200"
                    )}>
                      <span>🏆</span>
                      <span>{student.completionRate}%</span>
                    </div>

                    {/* Badge 4: Tiến bộ Trước/Sau */}
                    <div className={cn(
                      "px-2.5 py-1 rounded-xl text-xs font-black border flex items-center gap-1",
                      tab === 'deltaScore' 
                        ? "bg-cyan-500 text-slate-950 border-cyan-600 shadow-xs" 
                        : "bg-cyan-50 text-cyan-800 border-cyan-200"
                    )}>
                      <span>📈</span>
                      <span>+{student.deltaScore}đ</span>
                      <span className="opacity-70 text-[10px]">({student.preTestScore} ➔ {student.postTestScore})</span>
                    </div>
                  </div>

                  {/* Right: Primary Highlighted Metric based on Tab */}
                  <div className="text-right shrink-0 hidden md:block">
                    <div className={cn(
                      "font-black text-2xl font-mono",
                      tab === 'xp' && "text-blue-600",
                      tab === 'correctAnswers' && "text-emerald-600",
                      tab === 'totalAttempts' && "text-blue-600",
                      tab === 'completionRate' && "text-purple-600",
                      tab === 'deltaScore' && "text-cyan-700"
                    )}>
                      {tab === 'xp' && `${student.xp}`}
                      {tab === 'correctAnswers' && `${student.correctAnswers}`}
                      {tab === 'totalAttempts' && `${student.totalAttempts}`}
                      {tab === 'completionRate' && `${student.completionRate}%`}
                      {tab === 'deltaScore' && `+${student.deltaScore}đ`}
                    </div>
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                      {tab === 'xp' && '⚡ TỔNG XP'}
                      {tab === 'correctAnswers' && '🎯 SỐ CÂU ĐÚNG'}
                      {tab === 'totalAttempts' && '🔥 LƯỢT LUYỆN'}
                      {tab === 'completionRate' && '🏆 HOÀN THÀNH'}
                      {tab === 'deltaScore' && '📈 BỨT PHÁ'}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
