import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useSearchParams } from 'react-router-dom';
import confetti from 'canvas-confetti';
import { X, Check, ArrowRight, Zap, Trophy, Flame } from 'lucide-react';
import { useDataStore } from '../../store/dataStore';
import { useAuthStore } from '../../store/authStore';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { soundManager } from '../../utils/sound';
import { MatchingQuestionView } from '../../components/quiz/MatchingQuestionView';
import { OrderingQuestionView } from '../../components/quiz/OrderingQuestionView';
import { syncSaveAttempt } from '../../services/databaseService';
import { useEvidenceStore } from '../../store/evidenceStore';

export function QuizPage() {
  const [searchParams] = useSearchParams();
  const mode = searchParams.get('mode') || 'practice';
  const { questions, updateStudent } = useDataStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  
  // Stats
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [xpGained, setXpGained] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Time limit for speed mode
  const [timeLeft, setTimeLeft] = useState(15);
  
  const level = searchParams.get('level') || 'trung_binh';

  // Select questions based on difficulty level or cognitive mode
  const [sessionQuestions] = useState(() => {
    const cogParam = searchParams.get('cognitiveLevel');
    if (cogParam) {
      const targetLvl = Number(cogParam);
      const filtered = questions.filter(q => q.cognitiveLevel === targetLvl);
      if (filtered.length > 0) return [...filtered].sort(() => 0.5 - Math.random()).slice(0, 6);
    }

    if (mode === 'cognitive') {
      const picked: typeof questions = [];
      for (let lvl = 1; lvl <= 6; lvl++) {
        const lvlQuestions = questions.filter(q => q.cognitiveLevel === lvl);
        if (lvlQuestions.length > 0) {
          const randomQ = lvlQuestions[Math.floor(Math.random() * lvlQuestions.length)];
          picked.push(randomQ);
        }
      }
      if (picked.length >= 4) return picked;
    }

    let filtered = questions;
    if (level === 'yeu') {
      filtered = questions.filter(q => q.difficulty === 'nhan_biet');
      if (filtered.length === 0) filtered = questions;
    } else if (level === 'trung_binh') {
      filtered = questions.filter(q => q.difficulty === 'nhan_biet' || q.difficulty === 'thong_hieu');
      if (filtered.length === 0) filtered = questions;
    }
    const shuffled = [...filtered].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, 5);
  });

  const currentQuestion = sessionQuestions[currentIndex];

  useEffect(() => {
    if (mode === 'speed' && !isAnswered && !isFinished) {
      if (timeLeft > 0) {
        const timer = setTimeout(() => setTimeLeft(prev => prev - 1), 1000);
        return () => clearTimeout(timer);
      } else {
        handleTimeout();
      }
    }
  }, [timeLeft, isAnswered, isFinished, mode]);

  const handleTimeout = () => {
    soundManager.playWrong();
    setIsAnswered(true);
    setIsCorrect(false);
    setCombo(0);
  };

  const handleSubmit = (answer: string, forceCorrect?: boolean) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    const correct = forceCorrect !== undefined ? forceCorrect : answer === currentQuestion.answer;
    setIsCorrect(correct);
    
    if (correct) {
      soundManager.playCorrect();
      const points = currentQuestion.points;
      const speedBonus = mode === 'speed' && timeLeft > 10 ? 5 : 0;
      const comboBonus = combo >= 2 ? 5 : 0;
      
      setScore(prev => prev + points + speedBonus + comboBonus);
      setXpGained(prev => prev + 20 + speedBonus);
      
      const newCombo = combo + 1;
      setCombo(newCombo);
      if (newCombo > maxCombo) setMaxCombo(newCombo);
      
      // Mini confetti on correct
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#22c55e', '#3b82f6', '#f59e0b']
      });
    } else {
      soundManager.playWrong();
      setCombo(0);
    }
  };

  const handleNext = () => {
    if (currentIndex < sessionQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer('');
      setIsAnswered(false);
      setIsCorrect(false);
      setTimeLeft(15);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    setIsFinished(true);
    soundManager.playVictory();
    if (user?.role === 'student') {
      // Update student data
      const student = useDataStore.getState().students.find(s => s.id === user.id);
      if (student) {
        updateStudent(student.id, {
          xp: student.xp + xpGained,
          score: student.score + score,
        });
      }

      // Record in local evidence store for immediate UI updates
      useEvidenceStore.getState().recordAttempt({
        studentId: user.id,
        studentName: user.name || 'Học sinh',
        className: (user as any)?.className || '7A1',
        isCorrect: score >= sessionQuestions.length * 5,
        topic: 'Quiz',
      });

      // Save to Supabase / central storage
      const normScore = sessionQuestions.length > 0 
        ? Number(((score / (sessionQuestions.length * 10)) * 10).toFixed(1))
        : 8.0;

      syncSaveAttempt(
        {
          student_id: user.id,
          activity_id: `quiz_${mode}`,
          activity_type: 'quiz',
          score: Math.min(10, Math.max(0, normScore)),
          max_score: 10,
          started_at: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
          completed_at: new Date().toISOString(),
          is_demo: Boolean((user as any)?.isDemo),
        },
        undefined,
        {
          studentCode: (user as any)?.studentCode || 'HS01',
          classCode: (user as any)?.className || '7A1',
          displayName: user.name || 'Học sinh',
        }
      ).catch((err) => console.warn('Quiz attempt sync error:', err));
    }
    
    if (score > 0) {
      confetti({
        particleCount: 150,
        spread: 100,
        origin: { y: 0.6 }
      });
    }
  };

  if (isFinished) {
    return (
      <div className="max-w-xl mx-auto text-center py-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }}
          className="bg-slate-800 p-8 md:p-12 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl relative overflow-hidden text-white"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Trophy className="w-48 h-48" />
          </div>
          
          <div className="w-28 h-28 bg-gradient-to-tr from-yellow-400 to-amber-500 rounded-3xl border-4 border-b-8 border-amber-800 flex items-center justify-center mx-auto mb-6 shadow-xl animate-bounce">
            <Trophy className="w-16 h-16 text-white drop-shadow-md" />
          </div>

          {score >= 60 ? (
            <>
              <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-400 to-cyan-300 mb-3 uppercase tracking-wider" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                🎉 TUYỆT VỜI, BẠN ĐÃ HOÀN THÀNH XUẤT SẮC! 🏆
              </h2>
              <p className="text-emerald-300 text-lg md:text-xl font-bold mb-8">
                ✨ BẠN ĐÃ ĐẠT ĐIỂM SỐ XUẤT SẮC VÀ NẮM VỮNG KIẾN THỨC BẢNG TÍNH! 🚀
              </p>
            </>
          ) : (
            <>
              <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-rose-400 via-orange-400 to-yellow-300 mb-3 uppercase tracking-wider" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                ⚠️ CHƯA ĐẠT YÊU CẦU! CẦN LÀM LẠI NGAY! 📚
              </h2>
              <p className="text-rose-200 text-lg md:text-xl font-bold mb-8">
                💡 BẠN CHƯA HOÀN THÀNH TỐT BÀI NÀY. HÃY ÔN LẠI LÝ THUYẾT VÀ LÀM LẠI ĐỂ ĐẠT KẾT QUẢ CAO HƠN NHÉ! 🔄
              </p>
            </>
          )}
          
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-slate-900/90 p-5 rounded-2xl border-2 border-slate-700 shadow-inner">
              <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">⭐ ĐIỂM SỐ</div>
              <div className="text-4xl font-black text-cyan-400" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>{score}</div>
            </div>
            <div className="bg-slate-900/90 p-5 rounded-2xl border-2 border-slate-700 shadow-inner">
              <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">🔮 XP NHẬN ĐƯỢC</div>
              <div className="text-4xl font-black text-purple-400" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>+{xpGained}</div>
            </div>
            <div className="col-span-2 bg-slate-900/90 p-5 rounded-2xl border-2 border-slate-700 shadow-inner">
              <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">🔥 COMBO CAO NHẤT</div>
              <div className="text-3xl font-black text-amber-400 flex items-center justify-center gap-2" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                <span>🔥</span> x{maxCombo}
              </div>
            </div>
          </div>
          
          <div className="flex gap-4">
            <button 
              onClick={() => navigate('/student/game')}
              className="flex-1 py-4 bg-slate-700 hover:bg-slate-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-slate-900 shadow-xl transition-all text-lg"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              🚪 ĐÓNG
            </button>
            <button 
              onClick={() => window.location.reload()}
              className="flex-1 py-4 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-xl hover:scale-105 active:scale-95 transition-all text-lg"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              🔄 CHƠI LẠI
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (!currentQuestion) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto flex flex-col min-h-[calc(100vh-140px)] pb-28">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4 flex-1">
          <Button variant="ghost" size="sm" onClick={() => navigate('/student/game')} className="text-slate-400 p-2">
            <X className="w-5 h-5" />
          </Button>
          <div className="flex-1 max-w-md h-3 bg-slate-200 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-blue-500"
              initial={{ width: 0 }}
              animate={{ width: `${((currentIndex) / sessionQuestions.length) * 100}%` }}
            />
          </div>
        </div>
        
        <div className="flex gap-4 items-center">
          {combo >= 2 && (
            <motion.div 
              initial={{ scale: 0 }} animate={{ scale: 1 }}
              className="flex items-center gap-1 text-orange-500 font-bold bg-orange-100 px-3 py-1 rounded-full"
            >
              <Flame className="w-4 h-4 fill-current" /> x{combo}
            </motion.div>
          )}
          {mode === 'speed' && (
            <div className={`flex items-center gap-1 font-bold px-3 py-1 rounded-full ${timeLeft <= 5 ? 'text-red-500 bg-red-100' : 'text-blue-500 bg-blue-100'}`}>
              <Zap className="w-4 h-4 fill-current" /> {timeLeft}s
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col justify-center">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="w-full"
        >
          <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-8 md:p-10 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl mb-8 relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Zap className="w-40 h-40" />
            </div>

            {currentQuestion.cognitiveLevel && (
              <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-yellow-400 text-slate-950 font-black rounded-full text-xs uppercase tracking-wider mb-4 shadow-lg border-2 border-yellow-200">
                <span>🌟 MỨC {currentQuestion.cognitiveLevel}: {
                  currentQuestion.cognitiveLevel === 1 ? 'NHẬN BIẾT HÀM' :
                  currentQuestion.cognitiveLevel === 2 ? 'NHẬN DẠNG CÚ PHÁP' :
                  currentQuestion.cognitiveLevel === 3 ? 'CHỌN HÀM PHÙ HỢP' :
                  currentQuestion.cognitiveLevel === 4 ? 'PHÂN TÍCH CÔNG THỨC' :
                  currentQuestion.cognitiveLevel === 5 ? 'PHÁT HIỆN LỖI' :
                  'VẬN DỤNG VÀO BẢNG TÍNH THỰC TẾ'
                }</span>
              </div>
            )}

            <h2 className="text-2xl md:text-4xl font-black text-white leading-relaxed tracking-wider uppercase relative z-10" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
              {currentQuestion.content}
            </h2>
          </div>

          <div className="w-full">
            {/* Multiple Choice, True/False, Drag & Drop */}
            {(currentQuestion.type === 'mcq' || currentQuestion.type === 'true_false' || currentQuestion.type === 'drag_drop' || (!['matching', 'ordering', 'fill_blank'].includes(currentQuestion.type))) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {currentQuestion.options?.map((option, idx) => {
                  const isSelected = selectedAnswer === option;
                  const isCorrectOption = option === currentQuestion.answer;
                  
                  const colors = [
                    "from-cyan-500 to-blue-600 border-blue-900 text-white",
                    "from-purple-500 to-indigo-600 border-indigo-900 text-white",
                    "from-pink-500 to-rose-600 border-rose-900 text-white",
                    "from-amber-500 to-orange-600 border-orange-900 text-white"
                  ];
                  const colorClass = colors[idx % colors.length];

                  let btnClass = "h-auto py-6 px-8 text-xl md:text-2xl font-black justify-between text-left border-4 border-b-8 rounded-2xl shadow-xl transition-all duration-200 uppercase tracking-wider ";
                  
                  if (isAnswered) {
                    if (isCorrectOption) {
                      btnClass += " border-green-800 bg-gradient-to-r from-emerald-500 to-green-600 text-white animate-bounce";
                    } else if (isSelected && !isCorrectOption) {
                      btnClass += " border-red-900 bg-gradient-to-r from-red-600 to-rose-700 text-white opacity-60";
                    } else {
                      btnClass += " border-slate-700 bg-slate-800 text-slate-400 opacity-40";
                    }
                  } else {
                    btnClass += ` bg-gradient-to-r ${colorClass} hover:scale-[1.02] active:scale-95 active:border-b-2 active:translate-y-1 cursor-pointer`;
                  }

                  return (
                    <button
                      key={idx}
                      className={btnClass}
                      onClick={() => handleSubmit(option)}
                      disabled={isAnswered}
                      style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span>{option}</span>
                        {isAnswered && isCorrectOption && <Check className="w-8 h-8 text-white bg-emerald-700 rounded-full p-1 border-2 border-white shadow-lg shrink-0 ml-3" />}
                        {isAnswered && isSelected && !isCorrectOption && <X className="w-8 h-8 text-white bg-red-700 rounded-full p-1 border-2 border-white shadow-lg shrink-0 ml-3" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Interactive Matching Game */}
            {currentQuestion.type === 'matching' && (
              <MatchingQuestionView
                key={currentQuestion.id}
                question={currentQuestion}
                isAnswered={isAnswered}
                onComplete={(isCorrectVal, chosenAnswer) => handleSubmit(chosenAnswer, isCorrectVal)}
              />
            )}

            {/* Interactive Ordering Game */}
            {currentQuestion.type === 'ordering' && (
              <OrderingQuestionView
                key={currentQuestion.id}
                question={currentQuestion}
                isAnswered={isAnswered}
                onComplete={(isCorrectVal, chosenAnswer) => handleSubmit(chosenAnswer, isCorrectVal)}
              />
            )}
            
            {/* Fill Blank */}
            {currentQuestion.type === 'fill_blank' && (
              <div className="col-span-1 md:col-span-2">
                <input 
                  type="text" 
                  disabled={isAnswered}
                  value={selectedAnswer}
                  onChange={(e) => setSelectedAnswer(e.target.value.toUpperCase())}
                  onKeyDown={(e) => {
                    if(e.key === 'Enter' && selectedAnswer && !isAnswered) {
                      handleSubmit(selectedAnswer);
                    }
                  }}
                  className={`w-full text-center text-2xl font-bold p-6 rounded-2xl border-4 outline-none transition-colors ${
                    isAnswered 
                      ? isCorrect ? 'border-green-500 bg-green-50 text-green-700' : 'border-red-500 bg-red-50 text-red-700'
                      : 'border-slate-200 focus:border-blue-500 text-slate-800'
                  }`}
                  placeholder="Nhập tên hàm..."
                  autoFocus
                />
                {!isAnswered && (
                  <Button 
                    className="w-full mt-4 h-14 text-lg rounded-2xl" 
                    onClick={() => handleSubmit(selectedAnswer)}
                    disabled={!selectedAnswer}
                  >
                    Kiểm tra
                  </Button>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Footer Feedback */}
      <AnimatePresence>
        {isAnswered && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-0 left-0 right-0 p-6 md:p-10 border-t-2 z-50 ${
              isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
            }`}
          >
            <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${
                  isCorrect ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  {isCorrect ? <Check className="w-6 h-6 text-green-600" /> : <X className="w-6 h-6 text-red-600" />}
                </div>
                <div>
                  <h3 className={`text-xl font-black mb-1 ${
                    isCorrect ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {isCorrect ? 'Chính xác!' : 'Chưa chính xác!'}
                  </h3>
                  <p className={`font-medium ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                    {currentQuestion.explanation}
                  </p>
                </div>
              </div>
              <Button 
                onClick={handleNext}
                className={`shrink-0 h-12 px-8 rounded-2xl ${
                  isCorrect 
                    ? 'bg-green-600 hover:bg-green-700 shadow-[0_4px_0_0_rgba(21,128,61,1)] hover:shadow-[0_2px_0_0_rgba(21,128,61,1)]' 
                    : 'bg-red-600 hover:bg-red-700 shadow-[0_4px_0_0_rgba(185,28,28,1)] hover:shadow-[0_2px_0_0_rgba(185,28,28,1)]'
                }`}
              >
                Tiếp tục <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
