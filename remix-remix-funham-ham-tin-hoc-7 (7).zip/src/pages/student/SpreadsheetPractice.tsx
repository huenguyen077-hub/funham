import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Unlock, Heart, Trophy, ArrowLeft, Sparkles, Coins, Map } from 'lucide-react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { useDataStore } from '../../store/dataStore';
import { useAuthStore } from '../../store/authStore';
import { syncSaveAttempt } from '../../services/databaseService';

// Game Levels Data
const gameLevels = {
  sum: [
    {
      q: "Tính TỔNG số Vàng thu thập được trong các rương.",
      grid: [
        { col: 'A', row: 1, val: 'Rương', isHeader: true }, { col: 'B', row: 1, val: 'Vàng', isHeader: true },
        { col: 'A', row: 2, val: 'Rương 1' }, { col: 'B', row: 2, val: '50', highlight: true },
        { col: 'A', row: 3, val: 'Rương 2' }, { col: 'B', row: 3, val: '30', highlight: true },
        { col: 'A', row: 4, val: 'Rương 3' }, { col: 'B', row: 4, val: '20', highlight: true },
      ],
      correctFunc: 'SUM',
      correctRange: 'B2:B4',
      optionsFunc: ['SUM', 'MIN', 'MAX', 'COUNT'],
      optionsRange: ['A2:A4', 'B2:B4', 'B1:B4', 'A1:B4']
    },
    {
      q: "Tính TỔNG điểm kinh nghiệm (XP) của đội.",
      grid: [
        { col: 'A', row: 1, val: 'Thành viên', isHeader: true }, { col: 'B', row: 1, val: 'XP', isHeader: true },
        { col: 'A', row: 2, val: 'Ninja' }, { col: 'B', row: 2, val: '100', highlight: true },
        { col: 'A', row: 3, val: 'Knight' }, { col: 'B', row: 3, val: '150', highlight: true },
        { col: 'A', row: 4, val: 'Mage' }, { col: 'B', row: 4, val: '120', highlight: true },
      ],
      correctFunc: 'SUM',
      correctRange: 'B2:B4',
      optionsFunc: ['SUM', 'AVERAGE', 'MIN', 'MAX'],
      optionsRange: ['B2:B4', 'A2:A4', 'A1:B4', 'B1:B4']
    }
  ],
  average: [
    {
      q: "Tính mức sát thương TRUNG BÌNH của đội.",
      grid: [
        { col: 'A', row: 1, val: 'Thành viên', isHeader: true }, { col: 'B', row: 1, val: 'Damage', isHeader: true },
        { col: 'A', row: 2, val: 'Xạ thủ' }, { col: 'B', row: 2, val: '40', highlight: true },
        { col: 'A', row: 3, val: 'Pháp sư' }, { col: 'B', row: 3, val: '60', highlight: true },
        { col: 'A', row: 4, val: 'Chiến binh' }, { col: 'B', row: 4, val: '50', highlight: true },
      ],
      correctFunc: 'AVERAGE',
      correctRange: 'B2:B4',
      optionsFunc: ['AVERAGE', 'SUM', 'MAX', 'COUNT'],
      optionsRange: ['B2:B4', 'A2:A4', 'B1:B4', 'A1:B4']
    },
    {
      q: "Tính thời gian TRUNG BÌNH hoàn thành nhiệm vụ.",
      grid: [
        { col: 'A', row: 1, val: 'Nhiệm vụ', isHeader: true }, { col: 'B', row: 1, val: 'Phút', isHeader: true },
        { col: 'A', row: 2, val: 'Diệt Slime' }, { col: 'B', row: 2, val: '12', highlight: true },
        { col: 'A', row: 3, val: 'Lấy ngọc' }, { col: 'B', row: 3, val: '15', highlight: true },
      ],
      correctFunc: 'AVERAGE',
      correctRange: 'B2:B3',
      optionsFunc: ['AVERAGE', 'MIN', 'MAX', 'SUM'],
      optionsRange: ['B2:B3', 'A2:A3', 'A1:B3', 'B1:B3']
    }
  ],
  min: [
    {
      q: "Tìm lượng máu (HP) THẤP NHẤT trong bầy quái vật.",
      grid: [
        { col: 'A', row: 1, val: 'Quái vật', isHeader: true }, { col: 'B', row: 1, val: 'HP', isHeader: true },
        { col: 'A', row: 2, val: 'Slime' }, { col: 'B', row: 2, val: '15', highlight: true },
        { col: 'A', row: 3, val: 'Goblin' }, { col: 'B', row: 3, val: '45', highlight: true },
        { col: 'A', row: 4, val: 'Orc' }, { col: 'B', row: 4, val: '120', highlight: true },
      ],
      correctFunc: 'MIN',
      correctRange: 'B2:B4',
      optionsFunc: ['MAX', 'MIN', 'AVERAGE', 'SUM'],
      optionsRange: ['A2:A4', 'B1:B4', 'B2:B4', 'A1:B4']
    },
    {
      q: "Tìm vật phẩm có giá RẺ NHẤT.",
      grid: [
        { col: 'A', row: 1, val: 'Vật phẩm', isHeader: true }, { col: 'B', row: 1, val: 'Giá (vàng)', isHeader: true },
        { col: 'A', row: 2, val: 'Bình máu' }, { col: 'B', row: 2, val: '50', highlight: true },
        { col: 'A', row: 3, val: 'Bánh mì' }, { col: 'B', row: 3, val: '10', highlight: true },
      ],
      correctFunc: 'MIN',
      correctRange: 'B2:B3',
      optionsFunc: ['MIN', 'MAX', 'COUNT', 'AVERAGE'],
      optionsRange: ['B2:B3', 'A2:A3', 'A1:B3', 'B1:B3']
    }
  ],
  max: [
    {
      q: "Tìm sát thương LỚN NHẤT của vũ khí.",
      grid: [
        { col: 'A', row: 1, val: 'Vũ khí', isHeader: true }, { col: 'B', row: 1, val: 'Damage', isHeader: true },
        { col: 'A', row: 2, val: 'Kiếm Gỗ' }, { col: 'B', row: 2, val: '5', highlight: true },
        { col: 'A', row: 3, val: 'Kiếm Sắt' }, { col: 'B', row: 3, val: '25', highlight: true },
        { col: 'A', row: 4, val: 'Cung Tên' }, { col: 'B', row: 4, val: '18', highlight: true },
      ],
      correctFunc: 'MAX',
      correctRange: 'B2:B4',
      optionsFunc: ['MAX', 'MIN', 'SUM', 'COUNT'],
      optionsRange: ['B2:B4', 'A2:A4', 'B1:B4', 'A1:B4']
    },
    {
      q: "Tìm cấp độ (Level) CAO NHẤT trong đội.",
      grid: [
        { col: 'A', row: 1, val: 'Thành viên', isHeader: true }, { col: 'B', row: 1, val: 'Level', isHeader: true },
        { col: 'A', row: 2, val: 'Anh Hùng' }, { col: 'B', row: 2, val: '99', highlight: true },
        { col: 'A', row: 3, val: 'Pháp Sư' }, { col: 'B', row: 3, val: '85', highlight: true },
      ],
      correctFunc: 'MAX',
      correctRange: 'B2:B3',
      optionsFunc: ['MAX', 'AVERAGE', 'MIN', 'SUM'],
      optionsRange: ['B2:B3', 'A2:A3', 'A1:B3', 'B1:B3']
    }
  ],
  count: [
    {
      q: "ĐẾM số lượng rương có chứa vàng (chỉ đếm ô có số).",
      grid: [
        { col: 'A', row: 1, val: 'Vị trí', isHeader: true }, { col: 'B', row: 1, val: 'Vàng', isHeader: true },
        { col: 'A', row: 2, val: 'Góc phòng' }, { col: 'B', row: 2, val: '100', highlight: true },
        { col: 'A', row: 3, val: 'Gầm bàn' }, { col: 'B', row: 3, val: 'Trống', highlight: false },
        { col: 'A', row: 4, val: 'Trên giá' }, { col: 'B', row: 4, val: '50', highlight: true },
      ],
      correctFunc: 'COUNT',
      correctRange: 'B2:B4',
      optionsFunc: ['COUNT', 'SUM', 'AVERAGE', 'MIN'],
      optionsRange: ['A2:A4', 'B2:B4', 'B1:B4', 'A1:B4']
    },
    {
      q: "ĐẾM số thành viên đã sẵn sàng (có dữ liệu Level).",
      grid: [
        { col: 'A', row: 1, val: 'Thành viên', isHeader: true }, { col: 'B', row: 1, val: 'Level', isHeader: true },
        { col: 'A', row: 2, val: 'Ninja' }, { col: 'B', row: 2, val: 'Chưa', highlight: false },
        { col: 'A', row: 3, val: 'Knight' }, { col: 'B', row: 3, val: '40', highlight: true },
      ],
      correctFunc: 'COUNT',
      correctRange: 'B2:B3',
      optionsFunc: ['COUNT', 'MAX', 'MIN', 'SUM'],
      optionsRange: ['B2:B3', 'A2:A3', 'A1:B3', 'B1:B3']
    }
  ]
};

export const SpreadsheetPractice = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { updateStudent } = useDataStore();
  
  // Resolve current function/levels
  const requestedFunc = searchParams.get('func') || 'sum';
  const validFuncId = Object.keys(gameLevels).includes(requestedFunc) ? requestedFunc : 'sum';
  const levels = gameLevels[validFuncId as keyof typeof gameLevels];

  const [currentLevelIndex, setCurrentLevelIndex] = useState(0);
  const currentLevel = levels[currentLevelIndex];

  // Game State
  const [selectedFunc, setSelectedFunc] = useState<string | null>(null);
  const [selectedRange, setSelectedRange] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'success' | 'error' | 'win' | 'gameover'>('idle');
  const [lives, setLives] = useState(3);
  const [score, setScore] = useState(0);

  // Reset state when funcId changes (if user navigates without full reload)
  useEffect(() => {
    setCurrentLevelIndex(0);
    setSelectedFunc(null);
    setSelectedRange(null);
    setStatus('idle');
    setLives(3);
    setScore(0);
  }, [validFuncId]);

  const handleUnlock = () => {
    if (!selectedFunc || !selectedRange || status !== 'idle') return;
    
    if (selectedFunc === currentLevel.correctFunc && selectedRange === currentLevel.correctRange) {
      setStatus('success');
      setScore(s => s + 100);
      
      setTimeout(() => {
        if (currentLevelIndex < levels.length - 1) {
          setCurrentLevelIndex(i => i + 1);
          setSelectedFunc(null);
          setSelectedRange(null);
          setStatus('idle');
        } else {
          setStatus('win');
          const user = useAuthStore.getState().user;
          if (user && user.role === 'student') {
            const student = useDataStore.getState().students.find(s => s.id === user.id);
            if (student) {
              updateStudent(student.id, { xp: student.xp + 150 });
            }

            // Sync practice attempt to central database
            syncSaveAttempt(
              {
                student_id: user.id,
                activity_id: `practice_${validFuncId}`,
                activity_type: 'practice',
                score: 10,
                max_score: 10,
                started_at: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
                completed_at: new Date().toISOString(),
                is_demo: Boolean((user as any)?.isDemo),
              },
              undefined,
              {
                studentCode: (user as any)?.studentCode || 'HS01',
                classCode: (user as any)?.className || '7A1',
                displayName: user.name || 'Học sinh',
              }
            ).catch(err => console.warn('Practice sync error:', err));
          }
        }
      }, 1500);
    } else {
      setStatus('error');
      setLives(l => l - 1);
      
      setTimeout(() => {
        if (lives > 1) {
          setStatus('idle');
          setSelectedFunc(null);
          setSelectedRange(null);
        } else {
          setStatus('gameover');
        }
      }, 1000);
    }
  };

  const renderGrid = (gridData: any[]) => {
    const cols = Array.from(new Set(gridData.map(c => c.col))).sort();
    const rows = Array.from(new Set(gridData.map(c => c.row))).sort();

    return (
      <div className="overflow-hidden bg-white/5 rounded-xl border border-white/10 shadow-inner backdrop-blur-sm">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr>
              <th className="bg-white/10 border border-white/10 w-8 py-1"></th>
              {cols.map(c => (
                <th key={c} className="bg-white/10 border border-white/10 px-2 py-1 text-center font-bold text-blue-200">{c}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r}>
                <td className="bg-white/10 border border-white/10 text-center font-bold text-blue-200 w-8 py-2">{r}</td>
                {cols.map(c => {
                  const cell = gridData.find(d => d.col === c && d.row === r);
                  return (
                    <td key={c} className={`border border-white/10 px-3 py-2 text-center text-white
                      ${cell?.isHeader ? 'font-bold bg-white/5 text-blue-100' : ''} 
                      ${cell?.highlight ? 'bg-yellow-400/20 text-yellow-300 font-bold outline outline-1 outline-yellow-400/50' : ''}`}>
                      {cell?.val || ''}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  // --- Screens ---

  if (status === 'win') {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <motion.div 
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', bounce: 0.5, duration: 1 }}
        >
          <Trophy className="w-48 h-48 text-yellow-400 drop-shadow-[0_0_50px_rgba(250,204,21,0.6)] mb-8" />
        </motion.div>
        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500 mb-4 text-center">
          CHIẾN THẮNG!
        </h1>
        <p className="text-xl text-slate-300 mb-8 text-center max-w-md">
          Bạn đã giải mã thành công tất cả các kho báu bằng hàm {validFuncId.toUpperCase()}! Điểm của bạn: <strong className="text-yellow-400">{score}</strong> XP
        </p>
        <div className="flex gap-4">
          <Button size="lg" onClick={() => navigate('/student/lesson')} variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
            Về bài học
          </Button>
          <Button size="lg" onClick={() => {
            setCurrentLevelIndex(0);
            setStatus('idle');
            setScore(0);
            setLives(3);
            setSelectedFunc(null);
            setSelectedRange(null);
          }} className="bg-blue-600 hover:bg-blue-500">
            Chơi lại
          </Button>
        </div>
      </div>
    )
  }

  if (status === 'gameover') {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <motion.div 
          animate={{ rotate: [-10, 10, -10, 10, 0] }}
          transition={{ duration: 0.5 }}
        >
          <Heart className="w-48 h-48 text-red-500 fill-red-500/20 drop-shadow-[0_0_50px_rgba(239,68,68,0.4)] mb-8 opacity-50" />
        </motion.div>
        <h1 className="text-5xl font-black text-red-500 mb-4 text-center">
          THẤT BẠI
        </h1>
        <p className="text-xl text-slate-300 mb-8 text-center max-w-md">
          Bạn đã hết lượt thử. Hãy ôn lại kiến thức và thử lại nhé!
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Button size="lg" onClick={() => navigate('/student/lesson')} variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
            Về bài học
          </Button>
          <Button size="lg" onClick={() => navigate('/student/doctor')} className="bg-teal-600 hover:bg-teal-500 text-white">
            🩺 Khám lỗi với AI
          </Button>
          <Button size="lg" onClick={() => {
            setCurrentLevelIndex(0);
            setStatus('idle');
            setScore(0);
            setLives(3);
            setSelectedFunc(null);
            setSelectedRange(null);
          }} className="bg-blue-600 hover:bg-blue-500">
            Thử lại ngay
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4 font-sans pb-24">
      {/* Header */}
      <div className="flex justify-between items-center max-w-5xl mx-auto mb-8 pt-4">
        <button
          onClick={() => navigate('/student/game')}
          className="px-6 py-3.5 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-2xl hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 transition-all flex items-center gap-2 text-lg"
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
        >
          <span className="text-2xl">⬅️</span> TRỞ VỀ 🎮
        </button>
        
        <div className="flex items-center gap-3 bg-slate-800 px-6 py-3 rounded-2xl border-2 border-b-6 border-slate-700 shadow-lg">
          <span className="text-3xl">🗺️</span>
          <h1 
            className="text-2xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-400 to-pink-500 uppercase tracking-wider"
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
          >
            TRUY TÌM KHO BÁU 💎
          </h1>
        </div>

        <div className="flex gap-2 bg-slate-800 px-4 py-2.5 rounded-2xl border border-slate-700 shadow-inner">
          {[...Array(3)].map((_, i) => (
            <motion.div key={i} animate={i >= lives ? { opacity: 0.2, scale: 0.8 } : { opacity: 1, scale: 1 }}>
              <Heart className={`w-8 h-8 ${i < lives ? 'text-red-500 fill-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.9)] animate-pulse' : 'text-slate-600'}`} />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Main Game Area */}
      <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left: Mission & Grid */}
        <div className="bg-slate-800 rounded-3xl p-6 md:p-10 border-4 border-b-8 border-slate-700 shadow-2xl relative overflow-hidden flex flex-col">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-500" />
          
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-black text-amber-300 flex items-center gap-2 uppercase tracking-wide">
              <span>🎯</span> NHIỆM VỤ {currentLevelIndex + 1}/{levels.length}
            </h2>
            <div className="text-yellow-300 font-black bg-yellow-500/20 border border-yellow-500/40 px-4 py-1.5 rounded-2xl text-base shadow-sm">
              ⭐ {score} XP
            </div>
          </div>
          
          <p className="text-xl md:text-2xl font-extrabold mb-8 leading-relaxed text-white uppercase tracking-wide bg-slate-900/60 p-5 rounded-2xl border-2 border-slate-700 shadow-inner">
            {currentLevel.q}
          </p>
          
          {/* Visual Table */}
          <div className="mt-auto">
            {renderGrid(currentLevel.grid)}
          </div>
        </div>

        {/* Right: The Lock & Formula Builder */}
        <div className="bg-slate-800 rounded-3xl p-6 md:p-8 border border-slate-700 shadow-2xl relative flex flex-col items-center">
          
          {/* Status Overlay / Lock Icon */}
          <div className="h-40 flex items-center justify-center w-full relative mb-6">
            <AnimatePresence mode="wait">
              {status === 'success' ? (
                <motion.div 
                  key="success"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  className="absolute flex flex-col items-center"
                >
                  <Unlock className="w-24 h-24 text-green-400 drop-shadow-[0_0_30px_rgba(74,222,128,0.8)] mb-2" />
                  <Coins className="w-12 h-12 text-yellow-400 absolute -bottom-4 animate-bounce" />
                </motion.div>
              ) : status === 'error' ? (
                <motion.div 
                  key="error"
                  initial={{ x: -20 }}
                  animate={{ x: [0, -10, 10, -10, 10, 0] }}
                  transition={{ duration: 0.4 }}
                  className="absolute"
                >
                  <Lock className="w-24 h-24 text-red-500 drop-shadow-[0_0_30px_rgba(239,68,68,0.8)]" />
                </motion.div>
              ) : (
                <motion.div 
                  key="idle"
                  animate={{ y: [0, -8, 0] }} 
                  transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                  className="absolute"
                >
                  <Lock className="w-24 h-24 text-yellow-400 drop-shadow-[0_0_20px_rgba(250,204,21,0.4)]" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Formula Builder Slot */}
          <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3 text-xl md:text-3xl font-mono bg-slate-900/80 p-4 rounded-2xl border border-slate-700 shadow-inner w-full mb-8">
            <span className="text-pink-400 font-black">=</span>
            <div 
              className={`min-w-[90px] md:min-w-[120px] text-center px-3 py-2 rounded-xl border-2 transition-colors ${selectedFunc ? 'border-blue-400 bg-blue-500/20 text-blue-300 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 'border-dashed border-slate-600 text-slate-500 cursor-pointer hover:border-slate-400 hover:bg-slate-800'}`}
              onClick={() => {if(status === 'idle') setSelectedFunc(null)}}
            >
              {selectedFunc || 'HÀM'}
            </div>
            <span className="text-pink-400 font-black">(</span>
            <div 
              className={`min-w-[90px] md:min-w-[120px] text-center px-3 py-2 rounded-xl border-2 transition-colors ${selectedRange ? 'border-green-400 bg-green-500/20 text-green-300 shadow-[0_0_15px_rgba(34,197,94,0.3)]' : 'border-dashed border-slate-600 text-slate-500 cursor-pointer hover:border-slate-400 hover:bg-slate-800'}`}
              onClick={() => {if(status === 'idle') setSelectedRange(null)}}
            >
              {selectedRange || 'VÙNG'}
            </div>
            <span className="text-pink-400 font-black">)</span>
          </div>

          {/* Choices */}
          <div className="w-full space-y-6">
            <div>
              <div className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                1. Chọn Phép Thuật (Hàm)
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
                {currentLevel.optionsFunc.map(f => (
                  <button 
                    key={f}
                    disabled={status !== 'idle'}
                    onClick={() => setSelectedFunc(f)}
                    className={`px-2 py-3 rounded-xl font-bold font-mono text-sm md:text-base transition-all
                      ${selectedFunc === f 
                        ? 'bg-blue-500 text-white shadow-[0_0_20px_rgba(59,130,246,0.5)] scale-105 border-2 border-blue-300' 
                        : 'bg-slate-900 text-slate-300 border border-slate-700 hover:bg-slate-700 hover:scale-105'}
                      ${status !== 'idle' && selectedFunc !== f ? 'opacity-50' : ''}
                    `}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <div className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                2. Chọn Mục Tiêu (Vùng Dữ Liệu)
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
                {currentLevel.optionsRange.map(r => (
                  <button 
                    key={r}
                    disabled={status !== 'idle'}
                    onClick={() => setSelectedRange(r)}
                    className={`px-2 py-3 rounded-xl font-bold font-mono text-sm md:text-base transition-all
                      ${selectedRange === r 
                        ? 'bg-green-500 text-white shadow-[0_0_20px_rgba(34,197,94,0.5)] scale-105 border-2 border-green-300' 
                        : 'bg-slate-900 text-slate-300 border border-slate-700 hover:bg-slate-700 hover:scale-105'}
                      ${status !== 'idle' && selectedRange !== r ? 'opacity-50' : ''}
                    `}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Unlock Button */}
          <Button 
            size="lg"
            className={`w-full mt-8 text-lg font-black h-16 rounded-xl transition-all duration-300
              ${(!selectedFunc || !selectedRange || status !== 'idle') 
                ? 'opacity-50 cursor-not-allowed bg-slate-700 text-slate-400 hover:bg-slate-700' 
                : status === 'success' 
                  ? 'bg-green-500 text-white shadow-[0_0_30px_rgba(74,222,128,0.5)]'
                  : status === 'error'
                    ? 'bg-red-500 text-white shadow-[0_0_30px_rgba(239,68,68,0.5)]'
                    : 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 text-white shadow-[0_0_30px_rgba(245,158,11,0.4)] hover:scale-[1.02]'
              }
            `}
            onClick={handleUnlock}
            disabled={!selectedFunc || !selectedRange || status !== 'idle'}
          >
            {status === 'idle' && 'MỞ KHÓA KHO BÁU'}
            {status === 'success' && 'THÀNH CÔNG! (+100 XP)'}
            {status === 'error' && 'SAI RỒI!'}
          </Button>
        </div>

      </div>
    </div>
  );
};
