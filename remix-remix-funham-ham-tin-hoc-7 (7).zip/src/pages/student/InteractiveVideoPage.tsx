import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, RotateCcw, Volume2, SkipForward, SkipBack } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { cn } from '../../utils';

const SCENES = [
  {
    id: 'intro',
    duration: 5000,
    text: "Chào các em! Hôm nay chúng ta sẽ tìm hiểu về các hàm tính toán cơ bản trong bảng tính.",
    functionName: "Giới thiệu",
    animation: "intro"
  },
  {
    id: 'sum',
    duration: 8000,
    text: "Đầu tiên là hàm SUM. Hàm SUM giúp tính tổng các giá trị trong các ô một cách nhanh chóng. Ví dụ: =SUM(A1:A3)",
    functionName: "SUM",
    formula: "=SUM(10, 20, 30)",
    result: "60",
    animation: "calculate"
  },
  {
    id: 'average',
    duration: 8000,
    text: "Hàm AVERAGE dùng để tính trung bình cộng của các số. Ví dụ: =AVERAGE(10, 20, 30) sẽ lấy (10+20+30)/3.",
    functionName: "AVERAGE",
    formula: "=AVERAGE(10, 20, 30)",
    result: "20",
    animation: "calculate"
  },
  {
    id: 'max',
    duration: 7000,
    text: "Hàm MAX giúp tìm ra giá trị lớn nhất trong danh sách. Trong 10, 20, 30 thì 30 là lớn nhất.",
    functionName: "MAX",
    formula: "=MAX(10, 20, 30)",
    result: "30",
    animation: "highlight-max"
  },
  {
    id: 'min',
    duration: 7000,
    text: "Ngược lại, hàm MIN sẽ tìm ra giá trị nhỏ nhất. Số nhỏ nhất ở đây là 10.",
    functionName: "MIN",
    formula: "=MIN(10, 20, 30)",
    result: "10",
    animation: "highlight-min"
  },
  {
    id: 'count',
    duration: 8000,
    text: "Cuối cùng, hàm COUNT dùng để đếm xem có bao nhiêu ô chứa dữ liệu là chữ số. Ở đây có 3 ô chứa số.",
    functionName: "COUNT",
    formula: "=COUNT(A1:A3)",
    result: "3",
    animation: "count"
  },
  {
    id: 'outro',
    duration: 5000,
    text: "Tuyệt vời! Các em đã nắm được 5 hàm cơ bản nhất. Hãy vào phần Thực hành để luyện tập nhé!",
    functionName: "Hoàn thành",
    animation: "outro"
  }
];

export function InteractiveVideoPage() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [showResult, setShowResult] = useState(false);
  
  const progressInterval = useRef<NodeJS.Timeout | null>(null);
  const sceneTimer = useRef<NodeJS.Timeout | null>(null);
  const animationTimer = useRef<NodeJS.Timeout | null>(null);

  const currentScene = SCENES[currentSceneIndex];

  const startTimers = () => {
    const sceneStartTime = Date.now() - (progress / 100) * currentScene.duration;
    
    progressInterval.current = setInterval(() => {
      const elapsed = Date.now() - sceneStartTime;
      const newProgress = (elapsed / currentScene.duration) * 100;
      
      if (newProgress >= 100) {
        handleNextScene();
      } else {
        setProgress(newProgress);
      }
    }, 50);

    // Timing to show result mid-animation
    if (['calculate', 'highlight-max', 'highlight-min', 'count'].includes(currentScene.animation) && !showResult) {
      const timeRemaining = currentScene.duration - (progress / 100) * currentScene.duration;
      if (timeRemaining > 3000) {
         animationTimer.current = setTimeout(() => {
           setShowResult(true);
         }, timeRemaining - 3000);
      } else {
         setShowResult(true);
      }
    }
  };

  const clearTimers = () => {
    if (progressInterval.current) clearInterval(progressInterval.current);
    if (sceneTimer.current) clearTimeout(sceneTimer.current);
    if (animationTimer.current) clearTimeout(animationTimer.current);
  };

  useEffect(() => {
    if (isPlaying) {
      startTimers();
    } else {
      clearTimers();
    }
    return clearTimers;
  }, [isPlaying, currentSceneIndex]);

  useEffect(() => {
    // Reset showResult when scene changes
    setShowResult(false);
  }, [currentSceneIndex]);

  const handleNextScene = () => {
    if (currentSceneIndex < SCENES.length - 1) {
      setCurrentSceneIndex(prev => prev + 1);
      setProgress(0);
    } else {
      setIsPlaying(false);
      setProgress(100);
    }
  };

  const handlePrevScene = () => {
    if (currentSceneIndex > 0) {
      setCurrentSceneIndex(prev => prev - 1);
      setProgress(0);
    }
  };

  const togglePlay = () => {
    if (currentSceneIndex === SCENES.length - 1 && progress >= 100) {
      setCurrentSceneIndex(0);
      setProgress(0);
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-slate-800 tracking-tight">Bài giảng Video Tương Tác</h1>
        <p className="text-slate-500 font-medium">Khám phá các hàm tính toán cơ bản trong bảng tính</p>
      </div>

      <Card className="overflow-hidden bg-slate-900 border-0 shadow-2xl rounded-3xl">
        {/* Video Canvas */}
        <div className="relative aspect-video bg-slate-900 flex items-center justify-center p-8 overflow-hidden">
          {/* Background Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_70%,transparent_100%)] opacity-20" />

          <AnimatePresence mode="wait">
            <motion.div
              key={currentScene.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative z-10 w-full max-w-2xl"
            >
              {currentScene.animation === 'intro' && (
                <div className="text-center">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="inline-flex items-center justify-center w-24 h-24 rounded-3xl bg-blue-500/20 text-blue-400 mb-8"
                  >
                    <Play className="w-12 h-12 ml-2" />
                  </motion.div>
                  <h2 className="text-4xl md:text-5xl font-black text-white mb-4">Các Hàm Cơ Bản</h2>
                  <p className="text-xl text-slate-400">SUM, AVERAGE, MIN, MAX, COUNT</p>
                </div>
              )}

              {currentScene.animation === 'outro' && (
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-24 h-24 rounded-3xl bg-green-500/20 text-green-400 mb-8">
                    <Volume2 className="w-12 h-12" />
                  </div>
                  <h2 className="text-4xl md:text-5xl font-black text-white mb-4">Hoàn Thành!</h2>
                  <Button onClick={() => { setCurrentSceneIndex(0); setProgress(0); setIsPlaying(true); }} className="mt-4">
                    Xem Lại Video
                  </Button>
                </div>
              )}

              {['calculate', 'highlight-max', 'highlight-min', 'count'].includes(currentScene.animation) && (
                <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 md:p-10 shadow-2xl">
                  <div className="text-center mb-8">
                    <span className="inline-block px-4 py-1 rounded-full bg-blue-500/20 text-blue-400 font-bold text-sm tracking-widest mb-4">
                      HÀM {currentScene.functionName}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-8">
                    {[10, 20, 30].map((num, i) => {
                      let isHighlight = false;
                      if (showResult) {
                        if (currentScene.animation === 'highlight-max' && num === 30) isHighlight = true;
                        if (currentScene.animation === 'highlight-min' && num === 10) isHighlight = true;
                        if (currentScene.animation === 'count' || currentScene.animation === 'calculate') isHighlight = true;
                      }

                      return (
                        <motion.div
                          key={i}
                          animate={isHighlight ? { 
                            scale: 1.05, 
                            backgroundColor: 'rgba(59, 130, 246, 0.2)',
                            borderColor: 'rgba(59, 130, 246, 0.5)'
                          } : { 
                            scale: 1,
                            backgroundColor: 'rgba(30, 41, 59, 1)',
                            borderColor: 'rgba(51, 65, 85, 1)'
                          }}
                          className="aspect-square flex items-center justify-center text-3xl font-black text-white rounded-xl border-2"
                        >
                          {num}
                        </motion.div>
                      );
                    })}
                  </div>

                  <div className="h-24 bg-slate-900 rounded-xl border border-slate-700 flex items-center px-6 relative overflow-hidden">
                    <div className="font-mono text-xl text-slate-300 mr-4">fx</div>
                    <div className="font-mono text-xl text-green-400 flex-1">{currentScene.formula}</div>
                    
                    <AnimatePresence>
                      {showResult && (
                        <motion.div
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="absolute right-6 flex items-center"
                        >
                          <span className="text-slate-500 mr-4">=</span>
                          <span className="text-3xl font-black text-white">{currentScene.result}</span>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Subtitles Overlay */}
          <div className="absolute bottom-8 left-8 right-8 text-center z-20 pointer-events-none">
            <motion.div
              key={currentScene.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-block bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10"
            >
              <p className="text-white text-lg md:text-xl font-medium shadow-black drop-shadow-md">
                {currentScene.text}
              </p>
            </motion.div>
          </div>
        </div>

        {/* Video Controls */}
        <div className="bg-slate-950 p-6 border-t border-slate-800">
          {/* Progress Bar */}
          <div className="relative h-2 bg-slate-800 rounded-full mb-6 overflow-hidden cursor-pointer">
            <motion.div 
              className="absolute top-0 left-0 bottom-0 bg-blue-500 rounded-full"
              style={{ width: `${progress}%` }}
              layout
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={handlePrevScene}
                disabled={currentSceneIndex === 0}
                className="text-slate-400 hover:text-white disabled:opacity-50 transition-colors"
              >
                <SkipBack className="w-6 h-6" />
              </button>
              
              <button
                onClick={togglePlay}
                className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-500 flex items-center justify-center text-white transition-colors"
              >
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
              </button>
              
              <button
                onClick={handleNextScene}
                disabled={currentSceneIndex === SCENES.length - 1}
                className="text-slate-400 hover:text-white disabled:opacity-50 transition-colors"
              >
                <SkipForward className="w-6 h-6" />
              </button>
            </div>

            <div className="text-slate-400 font-medium">
              Bài {currentSceneIndex + 1} / {SCENES.length} • {currentScene.functionName}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
