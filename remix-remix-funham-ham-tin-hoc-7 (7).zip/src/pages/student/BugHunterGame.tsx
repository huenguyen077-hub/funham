import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Bug, Shield, CheckCircle, XCircle, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { useAuthStore } from '../../store/authStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { syncSaveAttempt } from '../../services/databaseService';

const BUGS = [
  {
    id: 1,
    category: 'Lỗi lựa chọn hàm',
    errorType: 'Dùng hàm SUM thay vì AVERAGE',
    formula: '=SUM(C4:C8)',
    requirement: 'Tính điểm trung bình từ ô C4 đến C8',
    options: ['=AVERAGE(C4:C8)', '=SUM(C4:C8)', '=MAX(C4:C8)'],
    correct: 0,
    hint: 'Theo SGK Tin học 7, để tính trung bình cộng ta dùng hàm AVERAGE, còn SUM là hàm tính tổng.'
  },
  {
    id: 2,
    category: 'Lỗi chọn vùng dữ liệu',
    errorType: 'Thiếu ô trong vùng dữ liệu',
    formula: '=SUM(C4:C7)',
    requirement: 'Tính tổng các giá trị từ ô C4 đến C8',
    options: ['=SUM(C4:C7)', '=SUM(C4:C8)', '=SUM(C3:C8)'],
    correct: 1,
    hint: 'Yêu cầu tính tổng đến ô C8 nhưng công thức mới quét tới C7, dẫn đến thiếu dữ liệu ô C8.'
  },
  {
    id: 3,
    category: 'Lỗi lựa chọn hàm',
    errorType: 'Dùng hàm MIN thay vì MAX',
    formula: '=MIN(C4:C8)',
    requirement: 'Tìm giá trị lớn nhất trong vùng C4:C8',
    options: ['=MIN(C4:C8)', '=AVERAGE(C4:C8)', '=MAX(C4:C8)'],
    correct: 2,
    hint: 'Yêu cầu tìm giá trị lớn nhất (MAX) nhưng công thức lại sử dụng hàm MIN (nhỏ nhất).'
  },
  {
    id: 4,
    category: 'Lỗi chọn vùng dữ liệu',
    errorType: 'Tham chiếu nhầm cột dữ liệu',
    formula: '=COUNT(D4:D8)',
    requirement: 'Đếm số lượng ô chứa số trong vùng C4:C8',
    options: ['=COUNT(D4:D8)', '=COUNT(C4:C8)', '=COUNTA(C4:C8)'],
    correct: 1,
    hint: 'Yêu cầu đếm vùng C4:C8 nhưng công thức lại tham chiếu nhầm sang cột D (D4:D8).'
  },
  {
    id: 5,
    category: 'Lỗi cú pháp',
    errorType: 'Thiếu dấu bằng ở đầu công thức',
    formula: 'SUM(A1:A5)',
    requirement: 'Nhập công thức hàm SUM cho vùng A1:A5',
    options: ['=SUM(A1:A5)', 'SUM(A1:A5)=', 'SUM=(A1:A5)'],
    correct: 0,
    hint: 'Mọi công thức hoặc hàm trong bảng tính bắt buộc phải bắt đầu bằng dấu bằng (=).'
  },
  {
    id: 6,
    category: 'Lỗi cú pháp',
    errorType: 'Sai dấu ngăn cách vùng (dùng dấu cách thay vì dấu hai chấm)',
    formula: '=AVERAGE(B2 B10)',
    requirement: 'Tính trung bình vùng B2 đến B10',
    options: ['=AVERAGE(B2, B10)', '=AVERAGE(B2:B10)', '=AVERAGE(B2;B10)'],
    correct: 1,
    hint: 'Để chỉ định một vùng dữ liệu liên tục từ ô này đến ô khác, SGK Tin học 7 quy định phải dùng dấu hai chấm (:).'
  },
  {
    id: 7,
    category: 'Lỗi cú pháp',
    errorType: 'Sai loại dấu ngoặc (dùng ngoặc vuông thay vì ngoặc đơn)',
    formula: '=MAX[C1:C20]',
    requirement: 'Tìm giá trị lớn nhất trong vùng C1:C20',
    options: ['=MAX{C1:C20}', '=MAX<C1:C20>', '=MAX(C1:C20)'],
    correct: 2,
    hint: 'Trong bảng tính, tên hàm luôn đi kèm cặp dấu ngoặc tròn () chứa tham số, không dùng ngoặc vuông.'
  },
  {
    id: 8,
    category: 'Lỗi cú pháp',
    errorType: 'Thiếu dấu ngoặc đóng ở cuối hàm',
    formula: '=COUNT(D1:D5',
    requirement: 'Đếm số lượng ô chứa số trong vùng D1:D5',
    options: ['=COUNT(D1:D5)', '=COUNT)D1:D5(', '=COUNT(D1:D5))'],
    correct: 0,
    hint: "Mỗi dấu ngoặc mở '(' luôn phải có tương ứng một dấu ngoặc đóng ')' ở cuối hàm."
  }
];

export function BugHunterGame() {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lives, setLives] = useState(3);
  const [score, setScore] = useState(0);
  const [status, setStatus] = useState<'playing' | 'success' | 'error' | 'gameover' | 'win'>('playing');

  const currentBug = BUGS[currentIndex];

  useEffect(() => {
    if (status === 'win' || status === 'gameover') {
      const user = useAuthStore.getState().user;
      if (user && user.role === 'student') {
        const studentCode = (user as any)?.studentCode || 'HS01';
        const className = (user as any)?.className || '7A1';
        const displayName = user.name || 'Học sinh';

        useEvidenceStore.getState().recordAttempt({
          studentId: user.id,
          studentName: displayName,
          className,
          isCorrect: status === 'win',
          topic: 'BugHunter',
        });

        syncSaveAttempt(
          {
            student_id: user.id,
            activity_id: 'game_bug_hunter',
            activity_type: 'game',
            score: status === 'win' ? 10 : Math.max(3, Math.round((score / 150) * 10)),
            max_score: 10,
            started_at: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
            completed_at: new Date().toISOString(),
            is_demo: Boolean((user as any)?.isDemo),
          },
          [
            {
              error_code: 'E01',
              corrected: status === 'win',
              hint_count: 1,
            }
          ],
          {
            studentCode,
            classCode: className,
            displayName
          }
        ).catch((err) => console.warn('Bug hunter sync error:', err));
      }
    }
  }, [status]);

  const handleAnswer = (selectedIndex: number) => {
    if (status !== 'playing') return;

    if (selectedIndex === currentBug.correct) {
      setStatus('success');
      setScore(s => s + 50);
      setTimeout(() => {
        if (currentIndex < BUGS.length - 1) {
          setCurrentIndex(i => i + 1);
          setStatus('playing');
        } else {
          setStatus('win');
        }
      }, 1500);
    } else {
      setStatus('error');
      setLives(l => l - 1);
      setTimeout(() => {
        if (lives > 1) {
          setStatus('playing');
        } else {
          setStatus('gameover');
        }
      }, 1500);
    }
  };

  if (status === 'win') {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <Shield className="w-48 h-48 text-green-400 drop-shadow-[0_0_50px_rgba(74,222,128,0.6)] mb-8" />
        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-500 mb-4 text-center">
          THỢ SĂN TÀI BA!
        </h1>
        <p className="text-xl text-slate-300 mb-8 text-center max-w-md">
          Bạn đã diệt sạch tất cả các lỗi cú pháp! Điểm của bạn: <strong className="text-yellow-400">{score}</strong> XP
        </p>
        <Button size="lg" onClick={() => navigate('/student/game')} className="bg-blue-600 hover:bg-blue-500">
          Về khu vui chơi
        </Button>
      </div>
    );
  }

  if (status === 'gameover') {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <Bug className="w-48 h-48 text-red-500 drop-shadow-[0_0_50px_rgba(239,68,68,0.6)] mb-8 opacity-50" />
        <h1 className="text-5xl font-black text-red-500 mb-4 text-center">
          HỆ THỐNG QUÁ TẢI LỖI
        </h1>
        <p className="text-xl text-slate-300 mb-8 text-center max-w-md">
          Bạn đã hết lượt diệt lỗi. Đừng nản chí, hãy thử lại nhé!
        </p>
        <div className="flex gap-4">
          <Button size="lg" onClick={() => navigate('/student/game')} variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
            Thoát
          </Button>
          <Button size="lg" onClick={() => {
            setCurrentIndex(0);
            setLives(3);
            setScore(0);
            setStatus('playing');
          }} className="bg-red-600 hover:bg-red-500">
            Quét lại từ đầu
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4 font-sans pb-24 relative overflow-hidden">
      {/* Background Matrix Effect (Simulated) */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#4ADE80 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

      {/* Header */}
      <div className="flex justify-between items-center max-w-4xl mx-auto mb-10 pt-4 relative z-10">
        <button
          onClick={() => navigate('/student/game')}
          className="px-5 py-3 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-xl hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 transition-all flex items-center gap-2 text-base"
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
        >
          <span className="text-xl">⬅️</span> TRỞ VỀ 🎮
        </button>
        
        <div className="flex items-center gap-3 bg-gradient-to-r from-red-600 to-orange-600 px-6 py-3 rounded-2xl border-2 border-b-6 border-red-900 shadow-lg">
          <span className="text-2xl">🕵️‍♂️</span>
          <h1 
            className="text-2xl md:text-3xl font-black text-white tracking-wider uppercase"
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
          >
            THỢ SĂN LỖI 🐛
          </h1>
        </div>

        <div className="flex gap-1.5 bg-slate-800 px-4 py-2 rounded-2xl border border-slate-700 shadow-inner">
          {[...Array(3)].map((_, i) => (
            <Heart key={i} className={`w-7 h-7 ${i < lives ? 'text-red-500 fill-red-500 animate-bounce' : 'text-slate-700'}`} />
          ))}
        </div>
      </div>

      <div className="max-w-3xl mx-auto relative z-10">
        <div className="flex justify-between items-end mb-4">
          <div className="text-amber-400 font-black uppercase tracking-wider text-base">
            🎯 MỤC TIÊU {currentIndex + 1} / {BUGS.length}
          </div>
          <div className="text-yellow-300 font-black bg-yellow-500/20 border border-yellow-500/40 px-4 py-1.5 rounded-2xl text-base shadow-sm">
            ⭐ {score} XP
          </div>
        </div>

        <div className="bg-slate-800 border-4 border-b-8 border-slate-700 rounded-3xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500" />
          
          <div className="text-center mb-10">
            {currentBug.category && (
              <div className="inline-block bg-purple-600/30 border-2 border-purple-400/50 text-purple-300 px-4 py-1.5 rounded-2xl font-black text-xs md:text-sm mb-3 uppercase tracking-wider shadow-sm">
                🏷️ THỂ LOẠI: {currentBug.category}
              </div>
            )}
            {currentBug.requirement && (
              <div className="block bg-blue-600/30 border-2 border-blue-400/50 text-blue-300 px-5 py-2 rounded-2xl font-black text-sm md:text-base mb-4 uppercase tracking-wider shadow-sm">
                📌 YÊU CẦU: {currentBug.requirement}
              </div>
            )}

            <div className="bg-slate-950 p-6 md:p-8 rounded-2xl border-4 border-red-500/40 font-mono text-2xl md:text-4xl font-black text-red-400 tracking-wider shadow-[0_0_40px_rgba(239,68,68,0.3)]">
              {currentBug.formula}
            </div>
                        <AnimatePresence mode="wait">
              {status === 'error' && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="mt-6 text-red-400 font-black text-lg flex items-center justify-center gap-2 bg-red-950/50 p-4 rounded-xl border border-red-500/30"
                >
                  <XCircle className="w-6 h-6 text-red-500 shrink-0" /> Sai rồi! Gợi ý: {currentBug.hint}
                </motion.div>
              )}
              {status === 'success' && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="mt-6 bg-green-950/60 p-5 rounded-2xl border-2 border-green-500/50 text-left space-y-3 shadow-xl"
                >
                  <div className="flex items-center gap-2 text-green-400 font-black text-lg">
                    <CheckCircle className="w-6 h-6 shrink-0" /> Tuyệt vời! Đã sửa lỗi thành công! 🎉
                  </div>
                  <div className="bg-slate-900/90 p-4 rounded-xl border border-green-500/35 space-y-1.5">
                    <div className="text-purple-300 font-bold text-xs uppercase tracking-wide flex items-center gap-1.5">
                      <span>🏷️</span> Thể loại lỗi: <span className="text-white font-black">{currentBug.category}</span>
                    </div>
                    <div className="text-amber-300 font-bold text-sm uppercase tracking-wide flex items-center gap-1.5 pt-1 border-t border-slate-800/60">
                      <span>🔍</span> Lỗi cần phát hiện: <span className="text-white font-black">{currentBug.errorType}</span>
                    </div>
                    <div className="text-slate-300 text-sm flex items-start gap-1.5 pt-1 border-t border-slate-800">
                      <span>💡</span> <span>{currentBug.hint}</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="space-y-4">
            <p className="font-black text-slate-200 mb-4 text-center text-lg uppercase tracking-wider">🛠️ CHỌN CÁCH SỬA ĐÚNG NHẤT:</p>
            {currentBug.options.map((opt, idx) => (
              <button
                key={idx}
                disabled={status !== 'playing'}
                onClick={() => handleAnswer(idx)}
                className={`w-full p-5 rounded-2xl font-mono text-xl font-black transition-all duration-200 border-4 border-b-6
                  ${status !== 'playing' ? 'opacity-50 cursor-not-allowed' : 'hover:scale-[1.02] active:translate-y-1 active:border-b-2 cursor-pointer'}
                  bg-slate-900 border-slate-700 hover:border-orange-500 hover:bg-slate-800 text-white shadow-lg
                `}
                style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
