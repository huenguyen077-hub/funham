import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { cn } from '../../utils';

export function GameLobby() {
  const navigate = useNavigate();

  const games = [
    {
      title: "Chinh Phục Tháp 4 Tầng",
      desc: "Leo tháp săn XP: Vượt ải Nhận diện ➔ Phù thủy Cú pháp ➔ Cao thủ Bảng tính ➔ Diệt trùm Sửa lỗi!",
      badge: "🔥 LEO THÁP SĂN XP",
      icon: "🏰⚡",
      color: "from-rose-500 via-amber-500 to-yellow-500",
      borderColor: "border-rose-600",
      bgCard: "bg-gradient-to-br from-rose-50 via-amber-50 to-orange-100",
      shadowColor: "shadow-rose-500/30",
      path: "/student/tiers"
    },
    {
      title: "Đại Chiến 6 Ải Đấu Trí",
      desc: "Phá đảo 6 ải cam go: Bắt bài cú pháp, Chọn chuẩn phép tính, Săn lùng lỗi sai & Giật cúp Vô địch!",
      badge: "⚔️ ĐẤU TRƯỜNG ĐỈNH CAO",
      icon: "⚔️🏆",
      color: "from-cyan-400 to-blue-600",
      borderColor: "border-blue-600",
      bgCard: "bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-100",
      shadowColor: "shadow-blue-500/30",
      path: "/student/quiz?mode=cognitive"
    },
    {
      title: "Đường Đua Tốc Độ",
      desc: "Giải công thức bảng tính thật nhanh trong 60 giây!",
      icon: "🏎️💨",
      color: "from-orange-400 to-amber-500",
      borderColor: "border-orange-600",
      bgCard: "bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100",
      shadowColor: "shadow-orange-500/30",
      path: "/student/formula-racing"
    },
    {
      title: "Truy Tìm Kho Báu",
      desc: "Vận dụng các hàm vào bảng tính để mở khóa kho báu.",
      icon: "💎🗺️",
      color: "from-yellow-400 to-amber-500",
      borderColor: "border-yellow-600",
      bgCard: "bg-gradient-to-br from-yellow-50 via-amber-50 to-yellow-100",
      shadowColor: "shadow-yellow-500/30",
      path: "/student/spreadsheet"
    },
    {
      title: "Ghép Thẻ Phép Thuật",
      desc: "Nối hàm tính toán với đúng chức năng của chúng.",
      icon: "🔮✨",
      color: "from-blue-400 to-indigo-500",
      borderColor: "border-blue-600",
      bgCard: "bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-100",
      shadowColor: "shadow-blue-500/30",
      path: "/student/match-game"
    },
    {
      title: "Thợ Săn Lỗi",
      desc: "Tìm và sửa lỗi cú pháp trong các công thức bị hỏng.",
      icon: "🕵️‍♂️🔍",
      color: "from-rose-400 to-red-500",
      borderColor: "border-rose-600",
      bgCard: "bg-gradient-to-br from-rose-50 via-red-50 to-rose-100",
      shadowColor: "shadow-rose-500/30",
      path: "/student/bug-hunter"
    },
    {
      title: "Lật Thẻ Trí Nhớ",
      desc: "Rèn luyện trí nhớ qua trò chơi lật thẻ tìm cặp tương ứng.",
      icon: "🧠🃏",
      color: "from-purple-400 to-pink-500",
      borderColor: "border-purple-600",
      bgCard: "bg-gradient-to-br from-purple-50 via-pink-50 to-purple-100",
      shadowColor: "shadow-purple-500/30",
      path: "/student/memory-game"
    },
    {
      title: "Luyện tập trắc nghiệm",
      desc: "Ôn luyện các câu hỏi trắc nghiệm kiến thức Tin học 7.",
      icon: "🎯📚",
      color: "from-emerald-400 to-teal-500",
      borderColor: "border-emerald-600",
      bgCard: "bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-100",
      shadowColor: "shadow-emerald-500/30",
      path: "/student/quiz?mode=practice"
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-12">
      <div className="text-center mb-8">
        <div className="inline-block bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 py-5 px-8 md:px-12 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl">
          <h2 className="text-2xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-300 to-cyan-300 uppercase tracking-wider" style={{ textShadow: '0 3px 6px rgba(0,0,0,0.4)' }}>
            🎮 THƯ VIỆN TRÒ CHƠI 🏆
          </h2>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {games.map((game, idx) => (
          <GameModeCard 
            key={idx}
            title={game.title}
            desc={game.desc}
            badge={game.badge}
            icon={game.icon}
            color={game.color}
            borderColor={game.borderColor}
            bgCard={game.bgCard}
            shadowColor={game.shadowColor}
            path={game.path}
            onClick={() => navigate(game.path)}
          />
        ))}
      </div>
    </div>
  );
}

interface GameModeCardProps {
  key?: React.Key;
  title: string;
  desc: string;
  badge?: string;
  icon: string;
  color: string;
  borderColor: string;
  bgCard: string;
  shadowColor: string;
  path: string;
  onClick: () => void;
}

function GameModeCard({ title, desc, badge, icon, color, borderColor, bgCard, shadowColor, onClick }: GameModeCardProps) {
  return (
    <motion.div
      whileHover={{ y: -6, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <div 
        onClick={onClick}
        className={cn(
          "cursor-pointer h-full flex flex-col justify-between rounded-3xl p-7 transition-all duration-300 border-4 border-b-8 shadow-xl relative overflow-hidden",
          bgCard,
          borderColor,
          shadowColor
        )}
      >
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-32 h-32 bg-white/20 rounded-full blur-xl pointer-events-none" />
        
        <div>
          <div className="flex items-center justify-between mb-5">
            <div className="w-22 h-22 md:w-24 md:h-24 rounded-3xl bg-white border-3 border-b-6 border-slate-300 flex items-center justify-center text-4xl md:text-5xl shadow-xl transform -rotate-3 hover:rotate-0 transition-transform">
              {icon}
            </div>
            {badge && (
              <span className="px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider bg-white/95 text-slate-800 shadow-md border-2 border-slate-300">
                {badge}
              </span>
            )}
          </div>
          <h3 
            className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 mb-3 uppercase tracking-wider"
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.15)' }}
          >
            {title.toUpperCase()}
          </h3>
          <p className="text-slate-900 font-black mb-8 text-base md:text-lg leading-relaxed">{desc.toUpperCase()}</p>
        </div>

        <button 
          className={cn(
            "w-full text-white font-black py-5 px-6 rounded-2xl shadow-xl border-3 border-b-8 active:border-b-0 active:translate-y-1.5 transition-all flex items-center justify-center gap-3 text-xl uppercase tracking-wider bg-gradient-to-r",
            color,
            borderColor
          )}
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.4)' }}
        >
          <span>VÀO CHƠI NGAY</span>
          <span className="text-2xl">🚀</span>
        </button>
      </div>
    </motion.div>
  );
}
