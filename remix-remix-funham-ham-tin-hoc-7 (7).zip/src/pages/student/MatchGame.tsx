import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Check, Trophy, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { useAuthStore } from '../../store/authStore';
import { useDataStore } from '../../store/dataStore';
import { soundManager } from '../../utils/sound';

const PAIRS = [
  { id: 'sum', left: 'Tính tổng các giá trị', right: '=SUM()' },
  { id: 'avg', left: 'Tính trung bình cộng', right: '=AVERAGE()' },
  { id: 'min', left: 'Tìm giá trị nhỏ nhất', right: '=MIN()' },
  { id: 'max', left: 'Tìm giá trị lớn nhất', right: '=MAX()' },
  { id: 'cnt', left: 'Đếm các ô chứa số', right: '=COUNT()' },
];

export function MatchGame() {
  const navigate = useNavigate();
  const user = useAuthStore(s => s.user);
  const { updateStudent } = useDataStore();
  const [leftItems, setLeftItems] = useState<any[]>([]);
  const [rightItems, setRightItems] = useState<any[]>([]);
  
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [selectedRight, setSelectedRight] = useState<string | null>(null);
  const [matched, setMatched] = useState<string[]>([]);
  
  const [score, setScore] = useState(0);
  const [mistakes, setMistakes] = useState(0);

  useEffect(() => {
    // Shuffle the items independently
    const shuffledLeft = [...PAIRS].sort(() => Math.random() - 0.5);
    const shuffledRight = [...PAIRS].sort(() => Math.random() - 0.5);
    setLeftItems(shuffledLeft);
    setRightItems(shuffledRight);
  }, []);

  useEffect(() => {
    if (selectedLeft && selectedRight) {
      if (selectedLeft === selectedRight) {
        // Match!
        soundManager.playCorrect();
        setMatched(prev => {
          const next = [...prev, selectedLeft];
          if (next.length === PAIRS.length) {
            setTimeout(() => soundManager.playVictory(), 300);
            if (user && user.role === 'student') {
              const student = useDataStore.getState().students.find(s => s.id === user.id);
              if (student) {
                updateStudent(student.id, { xp: student.xp + 100 });
              }
            }
          }
          return next;
        });
        setScore(s => s + 20);
        setSelectedLeft(null);
        setSelectedRight(null);
      } else {
        // No match
        soundManager.playWrong();
        setMistakes(m => m + 1);
        setTimeout(() => {
          setSelectedLeft(null);
          setSelectedRight(null);
        }, 500);
      }
    }
  }, [selectedLeft, selectedRight]);

  const isWin = matched.length === PAIRS.length;

  if (isWin) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <motion.div 
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', bounce: 0.5, duration: 1 }}
        >
          <Trophy className="w-48 h-48 text-yellow-400 drop-shadow-[0_0_50px_rgba(250,204,21,0.6)] mb-8" />
        </motion.div>
        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-green-400 mb-4 text-center">
          HOÀN THÀNH XUẤT SẮC!
        </h1>
        <p className="text-xl text-slate-300 mb-8 text-center max-w-md">
          Bạn đã ghép đúng tất cả các phép thuật! Điểm của bạn: <strong className="text-yellow-400">{score}</strong> XP
          {mistakes > 0 && <span className="block mt-2 text-sm text-slate-400">Số lần sai: {mistakes}</span>}
        </p>
        <div className="flex gap-4">
          <Button size="lg" onClick={() => navigate('/student/game')} variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
            Về khu vui chơi
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4 font-sans pb-24">
      {/* Header */}
      <div className="flex justify-between items-center max-w-5xl mx-auto mb-8 pt-4">
        <button
          onClick={() => navigate('/student/game')}
          className="px-6 py-3.5 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-2xl hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 transition-all flex items-center gap-2 text-lg"
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
        >
          <span className="text-2xl">⬅️</span> TRỞ VỀ 🎮
        </button>
        
        <div className="flex items-center gap-3 bg-slate-800 px-6 py-3 rounded-2xl border-2 border-b-6 border-slate-700 shadow-lg">
          <span className="text-3xl">🔮</span>
          <h1 
            className="text-2xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-teal-400 to-green-400 uppercase tracking-wider"
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
          >
            GHÉP THẺ PHÉP THUẬT ✨
          </h1>
        </div>

        <div className="text-yellow-300 font-black bg-yellow-500/20 border border-yellow-500/40 px-5 py-2.5 rounded-2xl text-lg shadow-sm">
          ⭐ {score} XP
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        <p className="text-center text-slate-200 font-black mb-10 text-xl uppercase tracking-wider bg-slate-800/80 p-4 rounded-2xl border border-slate-700 shadow-inner">
          💡 Nối thẻ mô tả ở bên trái với hàm tương ứng ở bên phải!
        </p>
        
        <div className="grid grid-cols-2 gap-8 md:gap-16">
          {/* Left Column */}
          <div className="space-y-5">
            {leftItems.map((item) => {
              const isMatched = matched.includes(item.id);
              const isSelected = selectedLeft === item.id;
              const isWrong = isSelected && selectedRight && selectedLeft !== selectedRight;

              return (
                <motion.button
                  key={item.id}
                  disabled={isMatched}
                  onClick={() => setSelectedLeft(item.id)}
                  animate={isWrong ? { x: [-5, 5, -5, 5, 0] } : {}}
                  transition={{ duration: 0.3 }}
                  className={`w-full p-5 rounded-2xl border-4 border-b-6 text-left font-black text-lg md:text-xl transition-all duration-200 relative overflow-hidden shadow-lg
                    ${isMatched ? 'bg-green-500/20 border-green-600 text-green-300 opacity-50 cursor-default' : 
                      isSelected ? 'bg-gradient-to-r from-blue-600 to-indigo-600 border-blue-900 text-white shadow-2xl scale-105 z-10' : 
                      'bg-slate-800 border-slate-700 hover:border-slate-500 text-white hover:bg-slate-700'}
                  `}
                  style={{ textShadow: '0 1px 2px rgba(0,0,0,0.3)' }}
                >
                  {isMatched && <Check className="absolute right-4 top-1/2 -translate-y-1/2 w-7 h-7 text-green-400" />}
                  {item.left}
                </motion.button>
              );
            })}
          </div>

          {/* Right Column */}
          <div className="space-y-5">
            {rightItems.map((item) => {
              const isMatched = matched.includes(item.id);
              const isSelected = selectedRight === item.id;
              const isWrong = isSelected && selectedLeft && selectedLeft !== selectedRight;

              return (
                <motion.button
                  key={item.id}
                  disabled={isMatched}
                  onClick={() => setSelectedRight(item.id)}
                  animate={isWrong ? { x: [-5, 5, -5, 5, 0] } : {}}
                  transition={{ duration: 0.3 }}
                  className={`w-full p-5 rounded-2xl border-4 border-b-6 text-center font-mono font-black text-xl md:text-2xl transition-all duration-200 relative overflow-hidden shadow-lg
                    ${isMatched ? 'bg-green-500/20 border-green-600 text-green-300 opacity-50 cursor-default' : 
                      isSelected ? 'bg-gradient-to-r from-purple-600 to-pink-600 border-purple-900 text-white shadow-2xl scale-105 z-10' : 
                      'bg-slate-800 border-slate-700 hover:border-slate-500 text-white hover:bg-slate-700'}
                  `}
                  style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
                >
                  {isMatched && <Check className="absolute left-4 top-1/2 -translate-y-1/2 w-7 h-7 text-green-400" />}
                  {item.right}
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
