import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Calculator, Activity, ArrowDownToLine, ArrowUpToLine, Hash, Play, AlertTriangle, CheckCircle2, Sparkles, RefreshCw } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { useNavigate } from 'react-router-dom';
import { FunctionVideo } from '../../components/FunctionVideo';
import { CognitiveLevelsPractice } from '../../components/CognitiveLevelsPractice';
import confetti from 'canvas-confetti';
import { cn } from '../../utils';

const functions = [
  {
    id: 'sum',
    name: 'SUM',
    icon: <Calculator className="w-8 h-8 text-blue-500" />,
    color: 'blue',
    syntax: '=SUM(vùng_dữ_liệu)',
    example: '=SUM(C3:C10)',
    desc: 'Tính tổng các giá trị trong vùng dữ liệu.',
    bg: 'bg-blue-50',
    videoId: 'k1VYJGQ8zFA'
  },
  {
    id: 'average',
    name: 'AVERAGE',
    icon: <Activity className="w-8 h-8 text-purple-500" />,
    color: 'purple',
    syntax: '=AVERAGE(vùng_dữ_liệu)',
    example: '=AVERAGE(B2:B6)',
    desc: 'Tính giá trị trung bình cộng.',
    bg: 'bg-purple-50',
    videoId: 'pXzQ-h2Xz7A'
  },
  {
    id: 'min',
    name: 'MIN',
    icon: <ArrowDownToLine className="w-8 h-8 text-green-500" />,
    color: 'green',
    syntax: '=MIN(vùng_dữ_liệu)',
    example: '=MIN(A1:A5)',
    desc: 'Tìm giá trị nhỏ nhất.',
    bg: 'bg-green-50',
    videoId: 'rF8Pj0Jj49U'
  },
  {
    id: 'max',
    name: 'MAX',
    icon: <ArrowUpToLine className="w-8 h-8 text-red-500" />,
    color: 'red',
    syntax: '=MAX(vùng_dữ_liệu)',
    example: '=MAX(D2:D10)',
    desc: 'Tìm giá trị lớn nhất.',
    bg: 'bg-red-50',
    videoId: 'rF8Pj0Jj49U'
  },
  {
    id: 'count',
    name: 'COUNT',
    icon: <Hash className="w-8 h-8 text-yellow-500" />,
    color: 'yellow',
    syntax: '=COUNT(vùng_dữ_liệu)',
    example: '=COUNT(E2:E20)',
    desc: 'Đếm số ô chứa dữ liệu số.',
    bg: 'bg-yellow-50',
    videoId: '2D0U97_u3l0'
  }
];

export function LessonPage() {
  const [selectedFunc, setSelectedFunc] = useState<string | null>(null);
  const navigate = useNavigate();

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-slate-800 p-8 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl gap-6">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-teal-400 to-green-400 tracking-wider mb-3 uppercase" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
            📚 THƯ VIỆN HÀM SỐ BẢNG TÍNH 🔮
          </h1>
          <p className="text-slate-200 text-lg md:text-xl font-bold">
            ✨ Khám phá lý thuyết, cú pháp và thực hành các hàm số trong chương trình Tin học 7! 🚀
          </p>
        </div>
        <button 
          onClick={() => navigate('/student/game')}
          className="px-8 py-4 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3 text-xl shrink-0"
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
        >
          <span>🎮</span> THƯ VIỆN TRÒ CHƠI ⚡
        </button>
      </div>

      {/* Function Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {functions.map((func) => {
          const cardColors = [
            "from-blue-600 to-indigo-700 border-indigo-900",
            "from-purple-600 to-indigo-600 border-indigo-900",
            "from-emerald-600 to-teal-700 border-teal-900",
            "from-rose-600 to-pink-700 border-pink-900",
            "from-amber-500 to-orange-600 border-orange-900"
          ];
          const colorStyle = cardColors[functions.indexOf(func) % cardColors.length];

          return (
            <motion.div
              key={func.id}
              layoutId={`card-${func.id}`}
              onClick={() => setSelectedFunc(func.id)}
              className="cursor-pointer"
              whileHover={{ y: -8, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className={`h-full bg-slate-800 p-8 rounded-3xl border-4 border-b-8 ${colorStyle} shadow-2xl flex flex-col justify-between transition-all relative overflow-hidden group`}>
                <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl group-hover:scale-125 transition-transform">
                  ✨
                </div>
                <div>
                  <div className="w-20 h-20 rounded-2xl bg-white/20 border-2 border-white/40 flex items-center justify-center mb-6 text-4xl shadow-inner">
                    {func.id === 'sum' ? '➕' : func.id === 'average' ? '📊' : func.id === 'min' ? '📉' : func.id === 'max' ? '📈' : '🔢'}
                  </div>
                  <h3 className="text-3xl font-black text-white mb-3 tracking-wide uppercase" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>{func.name}</h3>
                  <div className="text-base font-mono font-black text-yellow-300 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-700 inline-block mb-4 shadow-inner">
                    {func.syntax}
                  </div>
                  <p className="text-slate-200 text-lg font-bold leading-relaxed">{func.desc}</p>
                </div>
                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-white font-black uppercase text-sm tracking-wider">
                  <span>Khám phá chi tiết</span>
                  <span className="text-xl">➡️</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {selectedFunc && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm"
            onClick={() => setSelectedFunc(null)}
          >
            <motion.div
              layoutId={`card-${selectedFunc}`}
              className="w-full max-w-4xl bg-white rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {(() => {
                const func = functions.find(f => f.id === selectedFunc)!;
                return (
                  <div className="p-8 md:p-10 overflow-y-auto">
                    <div className="flex items-center justify-between mb-8 pb-4 border-b-2 border-slate-100">
                      <div className="flex items-center gap-5">
                        <div className={`w-20 h-20 rounded-2xl flex items-center justify-center text-4xl border-2 border-b-4 border-slate-300 shadow-md ${func.bg}`}>
                          {func.id === 'sum' ? '➕' : func.id === 'average' ? '📊' : func.id === 'min' ? '📉' : func.id === 'max' ? '📈' : '🔢'}
                        </div>
                        <div>
                          <h2 className="text-4xl font-black text-slate-900 tracking-wider uppercase" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.1)' }}>HÀM {func.name}</h2>
                          <p className="text-slate-600 font-black text-base uppercase mt-1">HƯỚNG DẪN CHI TIẾT & BẢNG TÍNH MẪU</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setSelectedFunc(null)}
                        className="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-red-100 hover:text-red-600 text-slate-700 font-black text-xl flex items-center justify-center transition-colors border-2 border-slate-300"
                      >
                        ✕
                      </button>
                    </div>

                    <div className="space-y-6">
                      <div className="bg-slate-900 text-white p-6 rounded-2xl border-3 border-indigo-600 shadow-lg">
                        <div className="text-xs font-black uppercase text-indigo-400 mb-1">Cú pháp chuẩn</div>
                        <div className="font-mono text-2xl font-black text-yellow-300">{func.syntax}</div>
                        <div className="mt-4 pt-4 border-t border-slate-800 text-xs font-black uppercase text-emerald-400">Ví dụ minh họa: <span className="font-mono text-white text-base">{func.example}</span></div>
                      </div>

                      <div className="bg-blue-50 p-6 rounded-2xl border-3 border-blue-200">
                        <h4 className="font-black text-blue-900 uppercase text-lg mb-2">💡 Giải thích hoạt động:</h4>
                        <p className="text-slate-700 font-bold text-base leading-relaxed">{func.desc}</p>
                      </div>

                      <div>
                        <h4 className="font-black text-slate-900 uppercase text-lg mb-4">🎬 Video minh họa trực quan:</h4>
                        <div className="rounded-2xl overflow-hidden border-4 border-slate-300 shadow-md">
                          <FunctionVideo functionId={func.id} />
                        </div>
                      </div>

                      {/* Luyện tập 6 mức độ cho riêng hàm này */}
                      <div className="pt-2">
                        <CognitiveLevelsPractice 
                          filterTopic={func.name as any} 
                          title={`LUYỆN TẬP 6 MỨC ĐỘ: HÀM ${func.name}`} 
                          subtitle={`Kiểm tra năng lực nhận biết, cú pháp, phát hiện lỗi và vận dụng thực tế cho riêng hàm ${func.name}`} 
                        />
                      </div>

                      <div className="pt-6 flex justify-end gap-4">
                        <Button onClick={() => setSelectedFunc(null)} className="px-6 py-3 bg-slate-200 hover:bg-slate-300 text-slate-800 font-black uppercase rounded-2xl">
                          Đóng
                        </Button>
                        <Button onClick={() => { setSelectedFunc(null); navigate('/student/spreadsheet'); }} className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase rounded-2xl border-2 border-b-4 border-blue-900">
                          Thực Hành Ngay trên Bảng Tính 📊
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
