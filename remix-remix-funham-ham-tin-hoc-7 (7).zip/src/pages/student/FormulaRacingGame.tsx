import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Timer, Trophy, ArrowLeft, Play, Zap, Flame, Flag } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { useAuthStore } from '../../store/authStore';
import { useDataStore } from '../../store/dataStore';
import { Student } from '../../types';
import { cn } from '../../utils';
import { soundManager } from '../../utils/sound';
import { useEvidenceStore } from '../../store/evidenceStore';
import { syncSaveAttempt } from '../../services/databaseService';

type Question = {
  formula: string;
  correctAnswer: number;
  options: number[];
  grid: Record<string, number>;
};

const CELL_IDS = ['A1', 'B1', 'A2', 'B2', 'A3', 'B3'];

function generateGrid(level: string): Record<string, number> {
  const grid: Record<string, number> = {};
  const maxVal = level === 'yeu' ? 10 : level === 'trung_binh' ? 15 : level === 'kha' ? 20 : 35;
  CELL_IDS.forEach(id => {
    grid[id] = Math.floor(Math.random() * maxVal) + 1;
  });
  return grid;
}

function calculateResult(func: string, range: string[], grid: Record<string, number>): number {
  const values = range.map(id => grid[id]);
  switch (func) {
    case 'SUM': return values.reduce((a, b) => a + b, 0);
    case 'AVERAGE': return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
    case 'MAX': return Math.max(...values);
    case 'MIN': return Math.min(...values);
    case 'COUNT': return values.length;
    default: return 0;
  }
}

function generateOptions(correctAnswer: number): number[] {
  const options = new Set<number>();
  options.add(correctAnswer);
  while (options.size < 4) {
    const offset = Math.floor(Math.random() * 11) - 5;
    const wrongAnswer = correctAnswer + offset;
    if (wrongAnswer !== correctAnswer && wrongAnswer >= 0) {
      options.add(wrongAnswer);
    }
  }
  return Array.from(options).sort(() => Math.random() - 0.5);
}

function generateQuestion(level: string): Question {
  const grid = generateGrid(level);
  const functions = level === 'yeu' ? ['SUM', 'COUNT'] : level === 'trung_binh' ? ['SUM', 'AVERAGE', 'COUNT'] : ['SUM', 'AVERAGE', 'MAX', 'MIN', 'COUNT'];
  const ranges = level === 'yeu' ? [
    { name: 'A1:A2', cells: ['A1', 'A2'] },
    { name: 'B1:B2', cells: ['B1', 'B2'] },
  ] : [
    { name: 'A1:A3', cells: ['A1', 'A2', 'A3'] },
    { name: 'B1:B3', cells: ['B1', 'B2', 'B3'] },
    { name: 'A1:B2', cells: ['A1', 'B1', 'A2', 'B2'] },
    { name: 'A2:B3', cells: ['A2', 'B2', 'A3', 'B3'] },
  ];

  const func = functions[Math.floor(Math.random() * functions.length)];
  const range = ranges[Math.floor(Math.random() * ranges.length)];
  
  const correctAnswer = calculateResult(func, range.cells, grid);
  const options = generateOptions(correctAnswer);

  return {
    formula: `=${func}(${range.name})`,
    correctAnswer,
    options,
    grid
  };
}

export function FormulaRacingGame() {
  const { user } = useAuthStore();
  const { updateStudent } = useDataStore();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const level = searchParams.get('level') || 'trung_binh';

  const gameDuration = level === 'yeu' ? 90 : level === 'trung_binh' ? 75 : level === 'kha' ? 60 : 45;
  const xpMultiplier = level === 'yeu' ? 1 : level === 'trung_binh' ? 1.2 : level === 'kha' ? 1.5 : 2;

  const [gameState, setGameState] = useState<'intro' | 'playing' | 'gameover'>('intro');
  const [timeLeft, setTimeLeft] = useState(gameDuration);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [question, setQuestion] = useState<Question | null>(null);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  const startGame = () => {
    setGameState('playing');
    setTimeLeft(gameDuration);
    setScore(0);
    setCombo(0);
    setQuestion(generateQuestion(level));
  };

  useEffect(() => {
    if (gameState === 'playing' && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && gameState === 'playing') {
      endGame();
    }
  }, [timeLeft, gameState]);

  const endGame = () => {
    setGameState('gameover');
    soundManager.playVictory();
    if (score > 0 && user && user.role === 'student') {
      const student = user as Student;
      const finalXp = Math.round(score * xpMultiplier);
      updateStudent(student.id, { xp: student.xp + finalXp });

      const studentCode = (user as any)?.studentCode || 'HS01';
      const className = (user as any)?.className || '7A1';
      const displayName = user.name || 'Học sinh';

      useEvidenceStore.getState().recordAttempt({
        studentId: user.id,
        studentName: displayName,
        className,
        isCorrect: score >= 50,
        topic: 'FormulaRacing',
      });

      syncSaveAttempt(
        {
          student_id: user.id,
          activity_id: 'game_formula_racing',
          activity_type: 'game',
          score: Math.min(10, Math.max(3, Math.round((score / 100) * 10))),
          max_score: 10,
          started_at: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
          completed_at: new Date().toISOString(),
          is_demo: Boolean((user as any)?.isDemo),
        },
        undefined,
        {
          studentCode,
          classCode: className,
          displayName
        }
      ).catch((err) => console.warn('Racing sync error:', err));
    }
  };

  const handleAnswer = (answer: number) => {
    if (!question || feedback) return;

    if (answer === question.correctAnswer) {
      soundManager.playCorrect();
      setFeedback('correct');
      const pts = level === 'yeu' ? 15 : level === 'trung_binh' ? 12 : 10;
      setScore(prev => prev + pts + (combo * 2));
      setCombo(prev => prev + 1);
    } else {
      soundManager.playWrong();
      setFeedback('wrong');
      setCombo(0);
      if (level !== 'yeu') {
        const penalty = level === 'gioi' ? 5 : level === 'kha' ? 3 : 1;
        setTimeLeft(prev => Math.max(0, prev - penalty));
      }
    }

    setTimeout(() => {
      setFeedback(null);
      setQuestion(generateQuestion(level));
    }, 800);
  };

  // Progress for the racing car (max visual width)
  const progressPercent = Math.min(100, (score / 150) * 100);

  return (
    <div className="max-w-4xl mx-auto pb-12">
      <div className="mb-6">
        <button
          onClick={() => navigate('/student/game')}
          className="px-5 py-3 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-purple-900 shadow-xl hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 transition-all flex items-center gap-2 text-base"
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
        >
          <span className="text-xl">⬅️</span> TRỞ VỀ 🎮
        </button>
      </div>

      {gameState === 'intro' && (
        <Card className="text-center p-12 bg-gradient-to-b from-orange-50 to-white border-4 border-b-8 border-orange-900 rounded-3xl shadow-2xl">
          <div className="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-orange-300 shadow-inner">
            <Zap className="w-12 h-12 text-orange-600 fill-orange-500" />
          </div>
          <h1 className="text-5xl font-black text-slate-900 tracking-wider uppercase mb-4" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>ĐƯỜNG ĐUA TỐC ĐỘ</h1>
          <p className="text-slate-800 font-black text-xl mb-8 max-w-lg mx-auto uppercase">
            GIẢI QUYẾT CÁC CÔNG THỨC NHANH NHẤT CÓ THỂ TRONG {gameDuration} GIÂY. TRẢ LỜI ĐÚNG LIÊN TIẾP SẼ NHẬN ĐIỂM COMBO, TRẢ LỜI SAI SẼ BỊ TRỪ THỜI GIAN!
          </p>
          <button 
            onClick={startGame} 
            className="bg-gradient-to-r from-orange-500 to-amber-600 text-white font-black text-2xl uppercase tracking-wider px-12 py-5 rounded-2xl border-4 border-b-8 border-orange-950 shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3 mx-auto"
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.4)' }}
          >
            <span>🚀</span> BẮT ĐẦU ĐUA <span>🏁</span>
          </button>
        </Card>
      )}

      {gameState === 'playing' && question && (
        <div className="space-y-6">
          {/* Header Stats */}
          <div className="grid grid-cols-2 gap-6">
            <div className={cn(
              "p-5 rounded-3xl border-4 border-b-8 shadow-xl flex items-center justify-between transition-all",
              timeLeft <= 10 
                ? "bg-gradient-to-r from-red-500 to-rose-600 border-red-800 text-white animate-pulse" 
                : "bg-gradient-to-r from-blue-500 to-indigo-600 border-blue-800 text-white"
            )}>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-white/20 border-2 border-white/40 flex items-center justify-center font-black text-3xl shadow-md">
                  ⏱️
                </div>
                <div>
                  <div className="text-xs font-black uppercase tracking-widest text-blue-100">THỜI GIAN CÒN LẠI</div>
                  <div className="text-4xl font-black tracking-wider" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                    {timeLeft}s
                  </div>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-3xl border-4 border-b-8 border-purple-800 bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-xl flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-white/20 border-2 border-white/40 flex items-center justify-center font-black text-3xl shadow-md">
                  ⭐
                </div>
                <div>
                  <div className="text-xs font-black uppercase tracking-widest text-purple-100">ĐIỂM SỐ TÍCH LŨY</div>
                  <div className="text-4xl font-black tracking-wider" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                    {score} XP
                  </div>
                </div>
              </div>
              {combo > 1 && (
                <div className="bg-amber-400 text-amber-950 px-4 py-2 rounded-2xl font-black text-lg animate-bounce border-2 border-amber-600 shadow-lg">
                  🔥 {combo} COMBO!
                </div>
              )}
            </div>
          </div>

          {/* Race Track */}
          <Card className="p-4 bg-slate-900 border-0 overflow-hidden relative">
            <div className="h-4 bg-slate-800 rounded-full relative overflow-hidden">
              <div className="absolute top-0 bottom-0 right-0 w-8 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiNmZmZmZmYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNNCAxNWwtLjYxLTEuODRBNiA2IDAgMCAwIDEgMTBaIi8+PHBhdGggZD0iTTQgMTV2NEExIDEgMCAwIDAgNSAyMGg0YTEgMSAwIDAgMCAxLTF2LTRMNyA4LjU5QzYuMzggNi40MSA1IDQgMyA0YzAgMCAyIDIuNCAxLjgyIDcuMTZsLjU4IDEuODQiLz48cGF0aCBkPSJNMjAgMTV2NEExIDEgMCAwIDEgMTkgMjBoLTRhMSAxIDAgMCAxLTEtMXYtNGwzLTYuNDFDMTcuNjIgNi40MSAxOSA0IDIxIDRjMCAwLTIgMi40LTEuODIgNy4xNmwtLjU4IDEuODQiLz48cGF0aCBkPSJNMjAgMTVsLjYxLTEuODRBNiA2IDAgMCAxIDIzIDEwWiIvPjxwYXRoIGQ9Ik0xMiAxMXY5Ii8+PHBhdGggZD0iTTEyIDR2MyIvPjwvc3ZnPg==')] opacity-20" />
            </div>
            <motion.div 
              className="absolute top-2.5 z-10 text-3xl"
              animate={{ left: `${progressPercent}%` }}
              transition={{ type: "spring", stiffness: 100 }}
              style={{ transform: 'translateX(-50%)' }}
            >
              🏎️
            </motion.div>
            <div className="absolute right-4 top-2.5 z-0 text-3xl opacity-50">
               🏁
            </div>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Grid display - Real Excel Style */}
            <Card className="bg-slate-100 border-2 border-slate-300 p-4 flex flex-col shadow-inner">
               {/* Excel Top Ribbon / Formula Bar */}
               <div className="bg-white rounded-xl border border-slate-300 p-3 mb-3 shadow-sm flex items-center gap-3">
                 <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600 text-white rounded-lg font-bold text-xs">
                   <span>📊</span> Excel
                 </div>
                 <div className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded border border-slate-200">
                   fx
                 </div>
                 <div className="text-sm font-mono font-black text-slate-800 tracking-wide">
                   {question.formula}
                 </div>
               </div>

               {/* Spreadsheet Table */}
               <div className="bg-white rounded-xl border border-slate-300 overflow-hidden shadow-sm">
                 <table className="w-full border-collapse text-center font-mono">
                   <thead>
                     <tr className="bg-slate-100 text-slate-600 text-xs border-b border-slate-300 font-bold">
                       <th className="p-2.5 border-r border-slate-300 w-12 bg-slate-200 text-slate-500">#</th>
                       <th className="p-2.5 border-r border-slate-300">A</th>
                       <th className="p-2.5">B</th>
                     </tr>
                   </thead>
                   <tbody>
                     {['1', '2', '3'].map((row) => {
                       const isCellInFormula = (col: string) => {
                         const cellId = `${col}${row}`;
                         const match = question.formula.match(/\((.*?)\)/);
                         if (!match) return false;
                         const range = match[1]; // e.g. A1:A3 or A1:B2
                         if (range.includes(':')) {
                           const [start, end] = range.split(':');
                           const startCol = start[0];
                           const startRow = parseInt(start[1]);
                           const endCol = end[0];
                           const endRow = parseInt(end[1]);
                           const curColIdx = col.charCodeAt(0);
                           const curRow = parseInt(row);
                           return curColIdx >= startCol.charCodeAt(0) && curColIdx <= endCol.charCodeAt(0) &&
                                  curRow >= startRow && curRow <= endRow;
                         }
                         return range.includes(cellId);
                       };

                       return (
                         <tr key={row} className="border-b border-slate-200 text-sm">
                           <td className="bg-slate-100 font-bold text-slate-500 border-r border-slate-300 py-3">
                             {row}
                           </td>
                           {['A', 'B'].map((col) => {
                             const highlighted = isCellInFormula(col);
                             return (
                               <td 
                                 key={col} 
                                 className={cn(
                                   "py-3 border-r border-slate-200 font-black text-lg transition-all",
                                   highlighted ? "bg-emerald-100 text-emerald-900 border-2 border-emerald-500 shadow-inner" : "bg-white text-slate-700"
                                 )}
                               >
                                 {question.grid[`${col}${row}`]}
                                 {highlighted && (
                                   <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                                 )}
                               </td>
                             );
                           })}
                         </tr>
                       );
                     })}
                   </tbody>
                 </table>
               </div>
               <div className="text-center mt-3 text-xs font-bold text-slate-500">
                 💡 Các ô trong vùng tính toán của công thức được <span className="text-emerald-700 font-black">tô sáng màu xanh lá</span>.
               </div>
            </Card>

            {/* Question & Answer */}
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-6 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <Zap className="w-32 h-32" />
                </div>
                <div className="relative z-10">
                  <div className="text-blue-200 text-xs font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                    <span>⚡</span> TÍNH KẾT QUẢ CÔNG THỨC SAU:
                  </div>
                  <div className="text-3xl md:text-4xl font-mono font-black tracking-wider text-white" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                    {question.formula}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {question.options.map((opt, i) => {
                  const colors = [
                    "from-cyan-500 to-blue-600 border-blue-800 text-white",
                    "from-purple-500 to-indigo-600 border-indigo-800 text-white",
                    "from-pink-500 to-rose-600 border-rose-800 text-white",
                    "from-amber-500 to-orange-600 border-orange-800 text-white"
                  ];
                  const colorClass = colors[i % colors.length];

                  return (
                    <button 
                      key={i}
                      disabled={feedback !== null}
                      onClick={() => handleAnswer(opt)}
                      className={cn(
                        "h-20 text-3xl font-black rounded-2xl transition-all duration-200 border-4 border-b-8 shadow-xl flex items-center justify-center uppercase tracking-wider",
                        feedback === null 
                          ? cn("bg-gradient-to-r hover:scale-105 active:scale-95 active:border-b-2 active:translate-y-1 cursor-pointer", colorClass) 
                          : (opt === question.correctAnswer ? "bg-gradient-to-r from-emerald-500 to-green-600 border-green-800 text-white animate-bounce" : 
                          (feedback === 'wrong' ? "bg-slate-700 border-slate-900 text-slate-400 opacity-50" : "bg-gradient-to-r " + colorClass))
                      )}
                      style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {gameState === 'gameover' && (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <Card className="text-center p-12 bg-gradient-to-b from-blue-50 to-white border-4 border-b-8 border-indigo-900 rounded-3xl shadow-2xl max-w-xl mx-auto">
            <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner border-2 border-yellow-300">
              <Trophy className="w-12 h-12 text-yellow-600 fill-yellow-500" />
            </div>
            
            {score >= 30 ? (
              <>
                <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-3 uppercase tracking-wider">🎉 TUYỆT VỜI, BẠN ĐÃ HOÀN THÀNH XUẤT SẮC!</h2>
                <p className="text-emerald-700 font-bold text-lg mb-8 uppercase">✨ Tốc độ và kiến thức bảng tính của bạn rất xuất sắc!</p>
              </>
            ) : (
              <>
                <h2 className="text-3xl md:text-4xl font-black text-rose-700 mb-3 uppercase tracking-wider">⚠️ CHƯA ĐẠT YÊU CẦU! CẦN LÀM LẠI NGAY!</h2>
                <p className="text-rose-600 font-bold text-lg mb-8 uppercase">💡 Điểm số chưa đạt yêu cầu. Hãy bấm chơi lại để luyện tập tốc độ và công thức tốt hơn nhé!</p>
              </>
            )}
            
            <div className="bg-white rounded-3xl p-6 border-3 border-b-6 border-slate-300 shadow-inner max-w-sm mx-auto mb-8">
              <div className="text-xs font-black text-slate-500 uppercase tracking-widest mb-1">⭐ ĐIỂM SỐ ĐẠT ĐƯỢC</div>
              <div className="text-5xl font-black text-blue-600">{score} XP</div>
            </div>

            <div className="flex gap-4 justify-center">
              <button 
                onClick={() => navigate('/student/game')}
                className="px-6 py-4 bg-slate-200 hover:bg-slate-300 text-slate-800 font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-slate-400 shadow-md transition-all text-base"
              >
                VỀ KHU VUI CHƠI
              </button>
              <button 
                onClick={startGame}
                className="px-8 py-4 bg-gradient-to-r from-orange-500 to-amber-600 text-white font-black uppercase tracking-wider rounded-2xl border-3 border-b-6 border-orange-950 shadow-xl hover:scale-105 active:scale-95 transition-all text-base flex items-center gap-2"
                style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
              >
                <span>🔄</span> CHƠI LẠI NGAY
              </button>
            </div>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
