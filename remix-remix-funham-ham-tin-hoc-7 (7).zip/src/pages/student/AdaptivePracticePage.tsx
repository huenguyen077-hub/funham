import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Target, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Sparkles, 
  RotateCcw, 
  BookOpen, 
  Flame,
  ShieldCheck,
  Cpu,
  Play,
  Eye,
  EyeOff
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { useAuthStore } from '../../store/authStore';
import { useDataStore } from '../../store/dataStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { syncSaveAttempt } from '../../services/databaseService';
import { cn } from '../../utils';

interface PracticeScenario {
  id: string;
  category: 'E01' | 'E02' | 'E04' | 'E08' | 'ADVANCED';
  categoryTitle: string;
  title: string;
  requirement: string;
  faultyFormula?: string;
  expectedFormula: string;
  hint: string;
  gridPreview: {
    headers: string[];
    rows: (string | number)[][];
  };
}

const PRESET_SCENARIOS: PracticeScenario[] = [
  {
    id: 'sc_01',
    category: 'E01',
    categoryTitle: 'Khắc phục Lỗi E01: Quên dấu bằng (=)',
    title: 'Nhiệm vụ 1: Chìa khóa vàng dấu =',
    requirement: 'Học sinh đang gõ "SUM(B2:B5)" nhưng phần mềm chỉ hiển thị chữ chứ không tính toán. Hãy sửa lại cho đúng!',
    faultyFormula: 'SUM(B2:B5)',
    expectedFormula: '=SUM(B2:B5)',
    hint: 'Mọi công thức trong bảng tính đều phải có dấu "=" ở đầu.',
    gridPreview: {
      headers: ['A: Khoản chi', 'B: Số tiền (k)'],
      rows: [['Mua vở', 45], ['Bút viết', 25], ['Thước kẻ', 15], ['Hộp bút', 30]]
    }
  },
  {
    id: 'sc_02',
    category: 'E02',
    categoryTitle: 'Khắc phục Lỗi E02: Sai chính tả tên hàm',
    title: 'Nhiệm vụ 2: Chuẩn hóa tên hàm tiếng Anh',
    requirement: 'Học sinh viết "=AVERGE(C2:C6)" để tính điểm trung bình. Phần mềm báo lỗi #NAME?. Hãy sửa tên hàm cho đúng chính tả!',
    faultyFormula: '=AVERGE(C2:C6)',
    expectedFormula: '=AVERAGE(C2:C6)',
    hint: 'Tên hàm tính trung bình cộng trong SGK Tin học 7 là AVERAGE (có chữ A ở giữa R và G).',
    gridPreview: {
      headers: ['A: STT', 'B: Học sinh', 'C: Điểm kiểm tra'],
      rows: [[1, 'Lan', 8.5], [2, 'Minh', 9.0], [3, 'Hùng', 7.5], [4, 'Cúc', 10.0], [5, 'Bảo', 8.0]]
    }
  },
  {
    id: 'sc_03',
    category: 'E04',
    categoryTitle: 'Khắc phục Lỗi E04: Sai ký hiệu vùng ô (:)',
    title: 'Nhiệm vụ 3: Dấu hai chấm nối dải ô',
    requirement: 'Học sinh viết "=SUM(B2-B6)" để tính tổng từ B2 đến B6 nhưng máy lại hiểu là B2 trừ B6. Hãy sửa lại ký hiệu vùng!',
    faultyFormula: '=SUM(B2-B6)',
    expectedFormula: '=SUM(B2:B6)',
    hint: 'Trong bảng tính, dải ô liên tục luôn dùng dấu hai chấm (:), ví dụ B2:B6.',
    gridPreview: {
      headers: ['A: Ngày', 'B: Số bước đi'],
      rows: [['T2', 4500], ['T3', 6200], ['T4', 5800], ['T5', 7100], ['T6', 6400]]
    }
  },
  {
    id: 'sc_04',
    category: 'E08',
    categoryTitle: 'Khắc phục Lỗi E08: Phân biệt SUM và AVERAGE',
    title: 'Nhiệm vụ 4: Chọn đúng giữa Tổng và Trung bình cộng',
    requirement: 'Đề bài yêu cầu "Tính chiều cao TRUNG BÌNH của 4 bạn trong tổ từ D2 đến D5". Hãy nhập công thức đúng chuẩn!',
    faultyFormula: '=SUM(D2:D5)',
    expectedFormula: '=AVERAGE(D2:D5)',
    hint: 'Yêu cầu tính trung bình nên phải dùng hàm AVERAGE, không dùng hàm SUM (tổng).',
    gridPreview: {
      headers: ['A: STT', 'B: Họ tên', 'C: Giới tính', 'D: Chiều cao (cm)'],
      rows: [[1, 'An', 'Nam', 155], [2, 'Bình', 'Nữ', 152], [3, 'Cường', 'Nam', 160], [4, 'Dung', 'Nữ', 157]]
    }
  },
  {
    id: 'sc_05',
    category: 'ADVANCED',
    categoryTitle: 'Vận dụng nâng cao: Quản lý chi tiêu gia đình',
    title: 'Nhiệm vụ 5: Tìm khoản chi LỚN NHẤT',
    requirement: 'Trong bảng theo dõi chi tiêu gia đình tháng 10 (cột C từ C2 đến C8), hãy viết công thức tìm khoản chi lớn nhất!',
    expectedFormula: '=MAX(C2:C8)',
    hint: 'Dùng hàm MAX để tìm giá trị lớn nhất trong vùng C2:C8.',
    gridPreview: {
      headers: ['A: Ngày', 'B: Nội dung', 'C: Số tiền (nghìn đồng)'],
      rows: [
        ['01/10', 'Tiền điện', 650],
        ['05/10', 'Tiền nước', 120],
        ['10/10', 'Internet', 220],
        ['15/10', 'Đi chợ', 850],
        ['20/10', 'Gas', 380],
        ['25/10', 'Sách vở', 150],
        ['30/10', 'Khác', 90]
      ]
    }
  }
];

// Bộ sinh bài tập biến thể AI thông minh dự phòng - Đảm bảo chạy 100% trên điện thoại, máy khác và ngoại tuyến
function generateDynamicVariant(category: 'ALL' | 'E01' | 'E02' | 'E04' | 'E08' | 'ADVANCED'): PracticeScenario {
  const effectiveCategory = category === 'ALL' 
    ? (['E01', 'E02', 'E04', 'E08', 'ADVANCED'][Math.floor(Math.random() * 5)] as any) 
    : category;

  const templates: Record<string, Array<{
    title: string;
    requirement: string;
    faultyFormula: string;
    expectedFormula: string;
    hint: string;
    gridPreview: { headers: string[]; rows: (string | number)[][] };
  }>> = {
    E01: [
      {
        title: 'Bảng chi phí mua sắm đồ dùng học tập',
        requirement: 'Nhập công thức vào ô B7 để tính tổng số tiền mua sắm đồ dùng học tập. Đảm bảo phần mềm nhận biết đây là công thức tính toán thay vì một chuỗi văn bản thuần túy (không được quên dấu bắt đầu).',
        faultyFormula: 'SUM(B2:B6)',
        expectedFormula: '=SUM(B2:B6)',
        hint: 'Mọi công thức trong phần mềm bảng tính đều bắt buộc phải mở đầu bằng dấu bằng (=).',
        gridPreview: {
          headers: ['A: Đồ dùng học tập', 'B: Số tiền (nghìn đồng)'],
          rows: [
            ['Vở kẻ ngang (10 cuốn)', 95],
            ['Bút bi xanh (1 hộp)', 60],
            ['Bộ thước kẻ eke', 25],
            ['Hộp bút chì màu', 45],
            ['Bút dạ quang đánh dấu', 30]
          ]
        }
      },
      {
        title: 'Bảng kế hoạch nhỏ quyên góp giấy vụn chi đội 7A',
        requirement: 'Nhập công thức vào ô B7 để tính tổng số kg giấy vụn của cả 5 tổ quyên góp được. Hãy gõ chính xác dấu mở đầu công thức để bảng tính thực hiện tính toán.',
        faultyFormula: 'SUM(B2:B6)',
        expectedFormula: '=SUM(B2:B6)',
        hint: 'Mọi công thức bắt buộc phải bắt đầu bằng dấu "=" rồi đến tên hàm và dải ô liên tục.',
        gridPreview: {
          headers: ['A: Tổ học tập', 'B: Số kg giấy vụn'],
          rows: [
            ['Tổ 1 (Sao Vàng)', 42],
            ['Tổ 2 (Măng Non)', 38],
            ['Tổ 3 (Hoa Phượng)', 45],
            ['Tổ 4 (Kim Đồng)', 35],
            ['Tổ 5 (Đoàn Kết)', 40]
          ]
        }
      },
      {
        title: 'Bảng theo dõi số trang sách đọc được trong tuần',
        requirement: 'Tính tổng số trang sách em đã đọc trong 5 ngày tại ô B7. Khắc phục lỗi thiếu dấu bằng (=) ở đầu công thức.',
        faultyFormula: 'SUM(B2:B6)',
        expectedFormula: '=SUM(B2:B6)',
        hint: 'Gõ =SUM(B2:B6) để phần mềm nhận diện lệnh tính tổng thay vì chuỗi văn bản.',
        gridPreview: {
          headers: ['A: Ngày trong tuần', 'B: Số trang đọc'],
          rows: [
            ['Thứ Hai', 18],
            ['Thứ Ba', 25],
            ['Thứ Tư', 20],
            ['Thứ Năm', 30],
            ['Thứ Sáu', 22]
          ]
        }
      }
    ],
    E02: [
      {
        title: 'Bảng điểm rèn luyện thi đua các tuần',
        requirement: 'Tính điểm rèn luyện trung bình 4 tuần tại ô B6. Một bạn học sinh đã gõ =AVERGE(B2:B5) bị báo lỗi #NAME?. Hãy sửa lại đúng chuẩn tên tiếng Anh của hàm.',
        faultyFormula: '=AVERGE(B2:B5)',
        expectedFormula: '=AVERAGE(B2:B5)',
        hint: 'Tên hàm tính trung bình cộng là AVERAGE (chú ý có chữ A giữa R và G).',
        gridPreview: {
          headers: ['A: Tuần thi đua', 'B: Điểm rèn luyện'],
          rows: [
            ['Tuần 1', 9.2],
            ['Tuần 2', 8.8],
            ['Tuần 3', 9.6],
            ['Tuần 4', 9.4]
          ]
        }
      },
      {
        title: 'Bảng theo dõi thời gian ôn bài tại nhà (phút)',
        requirement: 'Tính tổng số phút ôn tập các môn tại ô B7. Trước đó bạn học sinh gõ =SUMM(B2:B6) dẫn đến lỗi cú pháp tên hàm. Hãy chỉnh lại cho đúng chuẩn.',
        faultyFormula: '=SUMM(B2:B6)',
        expectedFormula: '=SUM(B2:B6)',
        hint: 'Hàm tính tổng trong SGK chỉ gồm 3 chữ cái S-U-M, không có chữ M thứ hai.',
        gridPreview: {
          headers: ['A: Môn học', 'B: Thời gian (phút)'],
          rows: [
            ['Toán', 60],
            ['Ngữ văn', 45],
            ['Tiếng Anh', 50],
            ['Tin học', 40],
            ['KHTN', 55]
          ]
        }
      },
      {
        title: 'Bảng sĩ số các nhóm học tập STEM',
        requirement: 'Đếm số lượng nhóm học tập đã nộp danh sách thành viên tại ô B6. Dùng hàm COUNT đúng chuẩn tên tiếng Anh thay vì viết nhầm =COUN(B2:B5).',
        faultyFormula: '=COUN(B2:B5)',
        expectedFormula: '=COUNT(B2:B5)',
        hint: 'Hàm đếm các ô chứa dữ liệu số là COUNT (C-O-U-N-T).',
        gridPreview: {
          headers: ['A: Nhóm dự án STEM', 'B: Sĩ số nhóm'],
          rows: [
            ['Nhóm 1 - Robot tự hành', 6],
            ['Nhóm 2 - Cầu dây văng', 5],
            ['Nhóm 3 - Năng lượng sạch', 7],
            ['Nhóm 4 - Xử lý nước', 6]
          ]
        }
      }
    ],
    E04: [
      {
        title: 'Bảng điểm kiểm tra thường xuyên môn Toán',
        requirement: 'Tính điểm trung bình các bài kiểm tra tại ô B7. Học sinh viết nhầm =AVERAGE(B2-B6) khiến phần mềm hiểu nhầm là phép trừ. Hãy sửa thành ký hiệu dải ô liên tục đúng chuẩn.',
        faultyFormula: '=AVERAGE(B2-B6)',
        expectedFormula: '=AVERAGE(B2:B6)',
        hint: 'Để chỉ dải ô từ B2 đến B6, ta dùng dấu hai chấm (:) ngăn cách, tức B2:B6.',
        gridPreview: {
          headers: ['A: Bài kiểm tra', 'B: Điểm số'],
          rows: [
            ['Bài kiểm tra 1', 8.5],
            ['Bài kiểm tra 2', 8.0],
            ['Bài kiểm tra 3', 9.0],
            ['Bài kiểm tra 4', 9.5],
            ['Bài kiểm tra 5', 8.5]
          ]
        }
      },
      {
        title: 'Bảng thành tích chạy bền 800m giải Phù Đổng',
        requirement: 'Tìm thời gian chạy nhanh nhất (giá trị nhỏ nhất) từ B2 đến B5. Sửa lỗi dùng dấu hai chấm (:) nối dải ô thay vì dùng dấu gạch ngang hoặc dấu chấm.',
        faultyFormula: '=MIN(B2..B5)',
        expectedFormula: '=MIN(B2:B5)',
        hint: 'Dải ô trong bảng tính luôn dùng dấu hai chấm (:), viết là B2:B5.',
        gridPreview: {
          headers: ['A: Vận động viên', 'B: Thời gian (phút)'],
          rows: [
            ['Hải Nam', 3.4],
            ['Tuấn Hùng', 3.1],
            ['Quang Minh', 3.6],
            ['Đức Anh', 2.9]
          ]
        }
      },
      {
        title: 'Bảng khối lượng rau thu hoạch vườn trường (kg)',
        requirement: 'Tính tổng khối lượng rau thu hoạch tại ô B6. Hãy sửa công thức gõ sai dải ô =SUM(B2;B5) thành dải ô liên tục chuẩn SGK Tin học 7.',
        faultyFormula: '=SUM(B2;B5)',
        expectedFormula: '=SUM(B2:B5)',
        hint: 'Dải ô liên tục từ ô đầu đến ô cuối phải dùng dấu hai chấm (B2:B5).',
        gridPreview: {
          headers: ['A: Luống rau', 'B: Khối lượng (kg)'],
          rows: [
            ['Luống 1 (Cải ngọt)', 18],
            ['Luống 2 (Xà lách)', 14],
            ['Luống 3 (Rau muống)', 22],
            ['Luống 4 (Cà chua)', 16]
          ]
        }
      }
    ],
    E08: [
      {
        title: 'Bảng theo dõi nhiệt độ trung bình ngày (°C)',
        requirement: "Đề bài yêu cầu: 'Hãy tính nhiệt độ TRUNG BÌNH của cả 5 ngày tại ô B7'. Học sinh gõ nhầm hàm SUM (tổng). Hãy chọn đúng hàm cần dùng.",
        faultyFormula: '=SUM(B2:B6)',
        expectedFormula: '=AVERAGE(B2:B6)',
        hint: 'Tính trung bình cộng dùng hàm AVERAGE, còn hàm SUM dùng để tính tổng.',
        gridPreview: {
          headers: ['A: Ngày trong tuần', 'B: Nhiệt độ (°C)'],
          rows: [
            ['Thứ Hai', 26],
            ['Thứ Ba', 28],
            ['Thứ Tư', 27],
            ['Thứ Năm', 29],
            ['Thứ Sáu', 25]
          ]
        }
      },
      {
        title: 'Bảng tiền vé tham quan bảo tàng lịch sử',
        requirement: "Yêu cầu: 'Tính TỔNG số tiền vé của cả 4 tổ tại ô B6'. Học sinh viết nhầm =AVERAGE(B2:B5). Hãy sửa lại đúng hàm tính tổng.",
        faultyFormula: '=AVERAGE(B2:B5)',
        expectedFormula: '=SUM(B2:B5)',
        hint: 'Đề bài yêu cầu tính TỔNG nên phải dùng hàm SUM, không dùng AVERAGE.',
        gridPreview: {
          headers: ['A: Tổ học tập', 'B: Tiền vé (nghìn đồng)'],
          rows: [
            ['Tổ 1 (12 bạn)', 120],
            ['Tổ 2 (15 bạn)', 150],
            ['Tổ 3 (14 bạn)', 140],
            ['Tổ 4 (13 bạn)', 130]
          ]
        }
      }
    ],
    ADVANCED: [
      {
        title: 'Bảng điểm tổng kết câu lạc bộ Tin học',
        requirement: 'Tìm điểm số CAO NHẤT trong nhóm tại ô B7 từ dải B2 đến B6.',
        faultyFormula: '=SUM(B2:B6)',
        expectedFormula: '=MAX(B2:B6)',
        hint: 'Dùng hàm MAX(B2:B6) để tìm điểm cao nhất.',
        gridPreview: {
          headers: ['A: Học sinh', 'B: Điểm bài tập lớn'],
          rows: [
            ['Nguyễn An', 9.5],
            ['Trần Bình', 8.5],
            ['Lê Cúc', 10.0],
            ['Phạm Dũng', 9.0],
            ['Vũ Hoa', 8.8]
          ]
        }
      },
      {
        title: 'Bảng tiêu hao điện năng các phòng học (kWh)',
        requirement: 'Tìm mức tiêu thụ điện năng THẤP NHẤT trong số các phòng học tại ô B7.',
        faultyFormula: '=MAX(B2:B6)',
        expectedFormula: '=MIN(B2:B6)',
        hint: 'Dùng hàm MIN(B2:B6) để tìm giá trị nhỏ nhất.',
        gridPreview: {
          headers: ['A: Phòng học chức năng', 'B: Điện năng (kWh)'],
          rows: [
            ['Phòng Tin học 1', 45],
            ['Phòng Tin học 2', 52],
            ['Phòng Ngoại ngữ', 38],
            ['Phòng Thí nghiệm KHTN', 60],
            ['Thư viện trường', 35]
          ]
        }
      }
    ]
  };

  const pool = templates[effectiveCategory] || templates['E01'];
  const chosen = pool[Math.floor(Math.random() * pool.length)];

  const categoryTitles: Record<string, string> = {
    E01: 'Khắc phục Lỗi E01: Quên dấu bằng (=)',
    E02: 'Khắc phục Lỗi E02: Sai chính tả tên hàm',
    E04: 'Khắc phục Lỗi E04: Sai ký hiệu vùng ô (:)',
    E08: 'Khắc phục Lỗi E08: Phân biệt SUM và AVERAGE',
    ADVANCED: 'Vận dụng nâng cao: Các hàm bảng tính Tin học 7'
  };

  return {
    id: `ai_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    category: effectiveCategory as any,
    categoryTitle: `✨ AI Biến Thể: ${categoryTitles[effectiveCategory] || effectiveCategory}`,
    title: `✨ AI: ${chosen.title}`,
    requirement: chosen.requirement,
    faultyFormula: chosen.faultyFormula,
    expectedFormula: chosen.expectedFormula,
    hint: chosen.hint,
    gridPreview: chosen.gridPreview
  };
}

export function AdaptivePracticePage() {
  const { user } = useAuthStore();
  const { updateStudent } = useDataStore();
  const { recordAttempt } = useEvidenceStore();

  const [activeCategory, setActiveCategory] = useState<'ALL' | 'E01' | 'E02' | 'E04' | 'E08' | 'ADVANCED'>('ALL');
  const [customScenarios, setCustomScenarios] = useState<PracticeScenario[]>([]);
  const [currentScenarioIdx, setCurrentScenarioIdx] = useState(0);

  const allScenarios = [...PRESET_SCENARIOS, ...customScenarios];
  const filteredScenarios = activeCategory === 'ALL'
    ? allScenarios
    : allScenarios.filter(s => s.category === activeCategory);

  const activeScenario = filteredScenarios[currentScenarioIdx] || filteredScenarios[0] || PRESET_SCENARIOS[0];

  const [userFormula, setUserFormula] = useState(activeScenario.faultyFormula || '');
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [aiGeneratedTask, setAiGeneratedTask] = useState<PracticeScenario | null>(null);
  const [showAiAnswer, setShowAiAnswer] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleSelectScenario = (idx: number) => {
    setCurrentScenarioIdx(idx);
    const target = filteredScenarios[idx] || filteredScenarios[0] || PRESET_SCENARIOS[0];
    setUserFormula(target.faultyFormula || '');
    setIsAnswered(false);
    setIsCorrect(false);
    setShowHint(false);
  };

  const handleCheck = () => {
    const cleanUser = userFormula.trim().toUpperCase().replace(/\s+/g, '');
    const cleanExpected = activeScenario.expectedFormula.trim().toUpperCase().replace(/\s+/g, '');
    const correct = cleanUser === cleanExpected;

    setIsAnswered(true);
    setIsCorrect(correct);

    const studentId = user?.id || 'hs_current';
    const studentName = user?.name || 'Học sinh';
    const className = (user as any)?.className || '7A1';

    recordAttempt({
      studentId,
      studentName,
      className,
      isCorrect: correct,
      topic: activeScenario.category,
      mistakePattern: userFormula
    });

    if (correct) {
      confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      if (user && user.role === 'student') {
        const studentXp = (user as any).xp ?? 950;
        updateStudent(studentId, { xp: studentXp + 30 });
      }
    }

    // Save to central database / Supabase
    if (user && user.role === 'student') {
      const studentCode = (user as any)?.studentCode || 'HS01';
      syncSaveAttempt(
        {
          student_id: user.id,
          activity_id: `adaptive_${activeScenario.id}`,
          activity_type: 'adaptive',
          score: correct ? 10 : 5,
          max_score: 10,
          started_at: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
          completed_at: new Date().toISOString(),
          is_demo: Boolean((user as any)?.isDemo),
        },
        [
          {
            error_code: activeScenario.category.startsWith('E') ? activeScenario.category : 'E01',
            corrected: correct,
            hint_count: showHint ? 1 : 0,
          }
        ],
        {
          studentCode,
          classCode: className,
          displayName: studentName
        }
      ).catch((err) => console.warn('Adaptive attempt sync error:', err));
    }
  };

  // Tạo thêm bài tập tương tự với AI (Hỗ trợ kép: Server Gemini API + Bộ sinh biến thể thông minh hoạt động 100% trên điện thoại & máy khác)
  const handleGenerateAiTask = async () => {
    setIsAiLoading(true);
    try {
      let taskData: PracticeScenario | null = null;

      // 1. Thử gọi API server Gemini nếu có kết nối
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);

        const res = await fetch('/api/ai/adaptive-task', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            frequentErrorCodes: [activeScenario.category],
            studentLevel: 'Lớp 7',
            topic: activeScenario.categoryTitle
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (!data.fallback && data.taskTitle && data.expectedFormula) {
            taskData = {
              id: `ai_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
              category: (activeCategory === 'ALL' ? activeScenario.category : activeCategory) as any,
              categoryTitle: `✨ AI Biến Thể: ${data.taskTitle}`,
              title: `✨ AI: ${data.taskTitle}`,
              requirement: data.requirement,
              faultyFormula: data.faultyFormula || data.expectedFormula.replace('=', '').replace(':', '-'),
              expectedFormula: data.expectedFormula,
              hint: data.remedialAdvice || 'Quan sát kỹ cấu trúc tên hàm và dải ô trong bảng tính.',
              gridPreview: data.gridData && data.gridData.headers ? data.gridData : {
                headers: ['A: Khoản mục', 'B: Số lượng'],
                rows: [['Mục 1', 25], ['Mục 2', 40], ['Mục 3', 15], ['Mục 4', 30]]
              }
            };
          }
        }
      } catch (apiErr) {
        console.warn('API /api/ai/adaptive-task not reachable, using Intelligent AI Engine:', apiErr);
      }

      // 2. Dự phòng thông minh cho điện thoại / máy khác / Netlify / ngoại tuyến
      if (!taskData) {
        await new Promise((resolve) => setTimeout(resolve, 600));
        taskData = generateDynamicVariant(activeCategory === 'ALL' ? activeScenario.category : activeCategory);
      }

      // 3. Đưa vào danh sách bài tập và hiển thị thẻ mới
      setAiGeneratedTask(taskData);
      setCustomScenarios(prev => [taskData!, ...prev]);
      setShowAiAnswer(false);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (err) {
      console.warn('AI task generation error:', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Nạp bài tập biến thể AI vào làm ngay lập tức
  const handleLoadAiTaskToPractice = (task: PracticeScenario) => {
    const updatedCustom = customScenarios.some(s => s.id === task.id)
      ? customScenarios
      : [task, ...customScenarios];
    setCustomScenarios(updatedCustom);

    if (activeCategory !== 'ALL' && activeCategory !== task.category) {
      setActiveCategory('ALL');
    }

    setTimeout(() => {
      const all = [...PRESET_SCENARIOS, ...updatedCustom];
      const targetList = (activeCategory === 'ALL' || activeCategory === task.category)
        ? all.filter(s => activeCategory === 'ALL' || s.category === activeCategory)
        : all;
      const targetIdx = targetList.findIndex(s => s.id === task.id);
      if (targetIdx !== -1) {
        setCurrentScenarioIdx(targetIdx);
      }
      setUserFormula(task.faultyFormula || '');
      setIsAnswered(false);
      setIsCorrect(false);
      setShowHint(false);

      // Cuộn lên mượt mà trên cả điện thoại và máy tính
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 50);
  };

  return (
    <div className="p-4 sm:p-6 md:p-10 space-y-8 pb-16">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-teal-700 via-emerald-700 to-blue-800 p-6 md:p-8 rounded-3xl border-4 border-b-8 border-teal-950 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-80 h-80 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase tracking-wider border border-yellow-400/30">
              <Zap className="w-4 h-4 text-yellow-300" />
              <span>CÁ NHÂN HÓA HỌC TẬP TIN HỌC 7</span>
            </div>
            <h1 className="text-2xl md:text-5xl font-black uppercase tracking-wider text-yellow-300 drop-shadow-md">
              🎯 LUYỆN TẬP KHẮC PHỤC LỖI
            </h1>
            <p className="text-teal-100 text-sm md:text-base font-bold leading-relaxed">
              Hệ thống tự động đề xuất lộ trình bổ trợ cá nhân hóa.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border-2 border-white/20 text-center shrink-0">
            <div className="text-xs font-black uppercase text-teal-200 mb-1">Mục tiêu</div>
            <div className="text-xl md:text-2xl font-black text-white">Triệt Tiêu Lỗi Sai</div>
            <div className="text-xs text-teal-200 mt-1">Nâng Cao Năng Lực</div>
          </div>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-2 bg-white rounded-2xl border-2 border-slate-200 shadow-sm">
        {[
          { key: 'ALL', label: 'Tất cả chủ đề' },
          { key: 'E01', label: 'Lỗi E01: Quên dấu =' },
          { key: 'E02', label: 'Lỗi E02: Sai tên hàm' },
          { key: 'E04', label: 'Lỗi E04: Ký hiệu vùng :' },
          { key: 'E08', label: 'Lỗi E08: Nhầm SUM/AVG' },
          { key: 'ADVANCED', label: 'Vận dụng nâng cao' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => {
              setActiveCategory(tab.key as any);
              setCurrentScenarioIdx(0);
              setIsAnswered(false);
              setShowHint(false);
            }}
            className={cn(
              "px-3 py-2 rounded-xl font-black text-[10px] sm:text-xs uppercase tracking-wide transition-all cursor-pointer",
              activeCategory === tab.key
                ? "bg-teal-600 text-white shadow-md scale-102"
                : "text-slate-600 hover:bg-slate-100"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Task & Practice Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
        <div className="lg:col-span-8 space-y-6">
          <Card className="bg-white p-4 sm:p-6 md:p-8 rounded-3xl border-4 border-b-8 border-slate-300 shadow-xl space-y-6">
            <div className="flex items-start justify-between gap-4 border-b-2 border-slate-100 pb-4">
              <div>
                <span className="inline-block px-3 py-1 bg-teal-100 text-teal-800 rounded-lg text-xs font-black uppercase mb-1">
                  {activeScenario.categoryTitle}
                </span>
                <h2 className="text-xl md:text-2xl font-black text-slate-900">
                  {activeScenario.title}
                </h2>
              </div>
              <Badge className="bg-slate-100 text-slate-800 font-black">
                Bài {currentScenarioIdx + 1} / {filteredScenarios.length}
              </Badge>
            </div>

            {activeScenario.id.startsWith('ai_') && (
              <div className="p-3 bg-gradient-to-r from-purple-100 to-indigo-100 border-2 border-purple-300 rounded-2xl flex items-center justify-between gap-2 text-purple-900 text-xs font-black uppercase">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>Bài tập biến thể do AI tạo riêng cho em! (+30 XP)</span>
                </div>
                <Badge className="bg-purple-600 text-white text-[10px]">AI Custom</Badge>
              </div>
            )}

            <div className="p-4 bg-teal-50 border-2 border-teal-200 rounded-2xl text-teal-950 font-bold text-sm leading-relaxed">
              {activeScenario.requirement}
            </div>

            {/* Grid Preview */}
            <div className="space-y-2">
              <span className="text-xs font-black uppercase text-slate-500">Bảng tính tham chiếu:</span>
              <div className="overflow-x-auto border-2 border-slate-200 rounded-2xl shadow-inner bg-slate-50">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-200 text-slate-800 font-black border-b border-slate-300">
                      {activeScenario.gridPreview.headers.map((h, i) => (
                        <th key={i} className="px-3 py-2 border-r border-slate-300 text-center">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {activeScenario.gridPreview.rows.map((row, rIdx) => (
                      <tr key={rIdx} className="border-b border-slate-200 bg-white">
                        {row.map((c, cIdx) => (
                          <td key={cIdx} className="px-3 py-2 border-r border-slate-200 text-center font-medium text-slate-800">
                            {c}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Formula Input */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-black uppercase text-slate-700">
                Nhập công thức đã sửa hoàn chỉnh:
              </label>
              <input
                type="text"
                value={userFormula}
                onChange={(e) => setUserFormula(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCheck();
                }}
                placeholder="Ví dụ: =AVERAGE(C2:C6)"
                className="w-full px-5 py-4 bg-slate-50 text-blue-900 font-mono text-lg font-black rounded-2xl border-2 border-slate-300 focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/20"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t-2 border-slate-100">
              <Button
                variant="outline"
                onClick={() => setShowHint(!showHint)}
                className="text-xs uppercase font-black px-4 py-2.5 rounded-xl border-amber-300 text-amber-800 hover:bg-amber-50"
              >
                💡 {showHint ? 'Ẩn gợi ý' : 'Xem gợi ý hướng dẫn'}
              </Button>

              <Button
                onClick={handleCheck}
                className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-black text-xs uppercase px-8 py-3.5 rounded-xl shadow-lg border-2 border-b-4 border-teal-900 cursor-pointer"
              >
                Kiểm tra & Ghi nhận kết quả ➔
              </Button>
            </div>

            {/* Hint Box */}
            {showHint && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-amber-50 border-2 border-amber-300 rounded-2xl text-amber-900 text-xs font-bold leading-relaxed"
              >
                <strong>💡 Gợi ý:</strong> {activeScenario.hint}
              </motion.div>
            )}

            {/* Feedback Box */}
            {isAnswered && (
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className={cn(
                  "p-5 rounded-2xl border-2 text-xs font-bold space-y-1.5",
                  isCorrect 
                    ? "bg-emerald-50 border-emerald-400 text-emerald-950" 
                    : "bg-rose-50 border-rose-400 text-rose-950"
                )}
              >
                <div className="flex items-center gap-2 font-black uppercase text-sm">
                  {isCorrect ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>CHÍNH XÁC! BẠN ĐÃ KHẮC PHỤC LỖI THÀNH CÔNG (+30 XP)</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-5 h-5 text-rose-600" />
                      <span>CHƯA ĐÚNG! HÃY KIỂM TRA LẠI KÝ TỰ BẮT ĐẦU HOẶC VÙNG Ô</span>
                    </>
                  )}
                </div>
                <p>
                  Đáp án chuẩn bám sát SGK: <strong className="font-mono text-sm underline">{activeScenario.expectedFormula}</strong>
                </p>
              </motion.div>
            )}
          </Card>
        </div>

        {/* Right Column: AI Practice Generator & Scenario List */}
        <div className="lg:col-span-4 space-y-6">
          {/* AI Task Generator Card */}
          <Card className="bg-gradient-to-br from-purple-900 to-indigo-950 p-6 rounded-3xl border-4 border-b-8 border-purple-950 text-white shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-yellow-300" />
                <h3 className="text-sm font-black uppercase tracking-wider text-yellow-300">
                  TRỢ LÝ TẠO BIẾN THỂ BÀI TẬP AI
                </h3>
              </div>
              <span className="px-2 py-0.5 bg-yellow-400/20 text-yellow-300 border border-yellow-400/30 rounded-full text-[10px] font-black uppercase">
                Mọi thiết bị
              </span>
            </div>

            <p className="text-xs text-purple-200 font-bold leading-relaxed">
              Bạn muốn thử sức thêm với các tình huống bảng tính thực tế mới lạ? Hãy để Gemini AI sinh bài tập riêng cho bạn! Hoạt động 100% mượt mà trên cả điện thoại và máy tính.
            </p>

            <Button
              onClick={handleGenerateAiTask}
              disabled={isAiLoading}
              className="w-full bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-300 hover:to-amber-400 text-slate-950 font-black text-xs uppercase py-3.5 rounded-xl shadow-lg border border-yellow-200 cursor-pointer flex items-center justify-center gap-2"
            >
              {isAiLoading ? (
                <>
                  <Cpu className="w-4 h-4 animate-spin text-slate-950" /> Đang tạo bài tập biến thể...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  Tạo bài tập biến thể với AI 🚀
                </>
              )}
            </Button>

            {aiGeneratedTask && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border-2 border-yellow-400/40 text-xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <Badge className="bg-yellow-400 text-slate-950 font-black flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> MỚI TẠO TỪ AI
                  </Badge>
                  <button
                    onClick={() => setShowAiAnswer(!showAiAnswer)}
                    className="text-[11px] font-bold text-yellow-300 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    {showAiAnswer ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    {showAiAnswer ? 'Ẩn đáp án' : 'Xem đáp án'}
                  </button>
                </div>

                <div className="font-black text-yellow-200 text-sm">
                  {aiGeneratedTask.title.replace('✨ AI: ', '')}
                </div>
                <div className="text-white font-medium leading-relaxed">
                  {aiGeneratedTask.requirement}
                </div>

                {showAiAnswer && (
                  <div className="p-2.5 bg-slate-900/80 rounded-xl font-mono text-emerald-300 text-xs border border-emerald-500/30 flex items-center justify-between">
                    <span>Đáp án: <strong className="underline">{aiGeneratedTask.expectedFormula}</strong></span>
                  </div>
                )}

                <Button
                  onClick={() => handleLoadAiTaskToPractice(aiGeneratedTask)}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase py-3 rounded-xl shadow-lg border border-emerald-300 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  👉 LÀM BÀI TẬP BIẾN THỂ NÀY NGAY ✍️
                </Button>
              </motion.div>
            )}
          </Card>

          {/* List of Tasks in Current Category */}
          <Card className="bg-white p-6 rounded-3xl border-3 border-slate-200 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-slate-700 tracking-wider">
                Danh sách bài tập ({filteredScenarios.length}):
              </h4>
              {customScenarios.length > 0 && (
                <span className="text-[10px] font-black text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
                  +{customScenarios.length} bài AI
                </span>
              )}
            </div>

            <div className="space-y-2">
              {filteredScenarios.map((s, idx) => {
                const isAi = s.id.startsWith('ai_');
                return (
                  <button
                    key={s.id}
                    onClick={() => handleSelectScenario(idx)}
                    className={cn(
                      "w-full p-3 rounded-xl text-left font-bold text-xs border-2 transition-all cursor-pointer flex items-center justify-between gap-2",
                      currentScenarioIdx === idx
                        ? isAi 
                          ? "bg-purple-50 border-purple-500 text-purple-950 shadow-sm"
                          : "bg-teal-50 border-teal-500 text-teal-900 shadow-sm"
                        : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
                    )}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      {isAi && (
                        <span className="px-1.5 py-0.5 bg-purple-600 text-white rounded text-[10px] font-black uppercase shrink-0">
                          AI
                        </span>
                      )}
                      <span className="truncate">{s.title}</span>
                    </div>
                    <ArrowRight className="w-4 h-4 shrink-0 text-slate-400" />
                  </button>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
