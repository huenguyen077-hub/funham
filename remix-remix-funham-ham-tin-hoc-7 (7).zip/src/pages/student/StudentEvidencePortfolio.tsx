import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Award, 
  CheckCircle2, 
  Layers, 
  Sparkles, 
  Heart, 
  Plus, 
  Table as TableIcon, 
  FileText, 
  TrendingUp, 
  Send, 
  Eye, 
  ArrowLeft,
  Smile,
  Zap,
  HelpCircle
} from 'lucide-react';
import { useEvidenceStore } from '../../store/evidenceStore';
import { useAuthStore } from '../../store/authStore';
import { Button } from '../../components/ui/Button';
import { useNavigate } from 'react-router-dom';
import { cn } from '../../utils';
import confetti from 'canvas-confetti';

export function StudentEvidencePortfolio() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { 
    studentsStat, 
    artifacts, 
    submitArtifact, 
    recordInterestRating,
    commonMistakes 
  } = useEvidenceStore();

  const [activeTab, setActiveTab] = useState<'my_stats' | 'my_artifacts' | 'bug_diary' | 'interest_survey'>('my_stats');

  // Bug fixing diary state
  const [bugLogs, setBugLogs] = useState([
    {
      id: 'bug_1',
      title: 'Nhầm dấu dải ô',
      formulaWrong: '=SUM(B2-B8)',
      formulaCorrect: '=SUM(B2:B8)',
      errorType: 'Dùng dấu trừ (-) thay vì dấu hai chấm (:)',
      date: '05/10/2026',
      status: 'Đã khắc phục hoàn toàn',
      teacherNote: 'Nắm rất chắc cú pháp sau khi luyện tập ở Tầng 4.'
    },
    {
      id: 'bug_2',
      title: 'Quên dấu bằng',
      formulaWrong: 'SUM(A1:A5)',
      formulaCorrect: '=SUM(A1:A5)',
      errorType: 'Thiếu dấu bằng (=) ở đầu công thức',
      date: '06/10/2026',
      status: 'Đã khắc phục hoàn toàn',
      teacherNote: 'Đã tạo thói quen kiểm tra dấu = trước khi gõ hàm.'
    },
    {
      id: 'bug_3',
      title: 'Chọn sai hàm Min/Max',
      formulaWrong: '=MIN(C4:C8)',
      formulaCorrect: '=MAX(C4:C8)',
      errorType: 'Sai hàm so với yêu cầu (tìm giá trị lớn nhất)',
      date: '07/10/2026',
      status: 'Đã khắc phục hoàn toàn',
      teacherNote: 'Phân biệt chính xác giữa MAX và MIN.'
    }
  ]);
  const [showAddBugModal, setShowAddBugModal] = useState(false);
  const [newBugTitle, setNewBugTitle] = useState('');
  const [newBugWrong, setNewBugWrong] = useState('');
  const [newBugCorrect, setNewBugCorrect] = useState('');
  const [newBugErrorType, setNewBugErrorType] = useState('');

  // AI Assistant state
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiFormulaInput, setAiFormulaInput] = useState('=AVERAGE(C1-C10)');
  const [aiErrorTypeInput, setAiErrorTypeInput] = useState('Sai dấu phân cách dải ô');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<{
    explanation: string;
    stepByStep: string[];
    practiceTask: { title: string; prompt: string; sampleFormula: string };
  } | null>({
    explanation: 'Dấu trừ (-) thực hiện phép trừ đại số thay vì dấu hai chấm (:) dùng để chỉ định dải ô trong hàm.',
    stepByStep: [
      'Bước 1: Nhấp vào ô chứa công thức có dấu trừ (-)',
      'Bước 2: Thay thế dấu trừ (-) bằng dấu hai chấm (:)',
      'Bước 3: Nhấn Enter để hoàn tất và nhận kết quả chính xác'
    ],
    practiceTask: {
      title: 'Luyện tập hàm AVERAGE',
      prompt: 'Tính điểm trung bình từ ô C1 đến C10',
      sampleFormula: '=AVERAGE(C1:C10)'
    }
  });
  const [aiEvidenceLogs, setAiEvidenceLogs] = useState<Array<{ timestamp: string; formula: string; result: any }>>([
    {
      timestamp: '14:30 - 07/10/2026',
      formula: '=SUM(B2-B8)',
      result: {
        explanation: 'Dấu trừ (-) thực hiện phép trừ đại số giữa ô B2 và B8 thay vì tính tổng cả vùng từ B2 đến B8.',
        stepByStep: ['Bước 1: Chọn ô chứa công thức sai', 'Bước 2: Sửa dấu trừ (-) thành dấu hai chấm (:)', 'Bước 3: Nhấn Enter để cập nhật kết quả'],
        practiceTask: { title: 'Luyện tập hàm SUM', prompt: 'Tính tổng điểm từ ô D2 đến D10', sampleFormula: '=SUM(D2:D10)' }
      }
    }
  ]);

  const handleAskAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiFormulaInput.trim()) return;
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/explain-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          formula: aiFormulaInput,
          errorType: aiErrorTypeInput,
          context: 'Học sinh lớp 7 luyện tập bảng tính Excel / Google Sheets',
          studentQuestion: 'Tại sao công thức này báo lỗi hoặc tính sai? Xin AI giải thích và gợi ý từng bước.'
        })
      });
      const data = await res.json();
      setAiResult(data);
      const newLog = {
        timestamp: new Date().toLocaleTimeString() + ' - ' + new Date().toLocaleDateString(),
        formula: aiFormulaInput,
        result: data
      };
      setAiEvidenceLogs(prev => [newLog, ...prev]);
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };


  // Artifact submission state
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [projectTitle, setProjectTitle] = useState('');
  const [category, setCategory] = useState<'Bảng điểm' | 'Kế hoạch nhỏ' | 'Theo dõi thể thao' | 'Quản lý thu chi'>('Bảng điểm');
  const [formulasInput, setFormulasInput] = useState('');
  const [tableDataJson, setTableDataJson] = useState(
    JSON.stringify([
      ['STT', 'Hạng mục', 'Số lượng', 'Đơn giá', 'Thành tiền'],
      [1, 'Sách bài tập', 2, 25000, '=C2*D2'],
      [2, 'Vở viết', 5, 8000, '=C3*D3'],
      ['Tổng', '', '', '', '=SUM(E2:E3)']
    ], null, 2)
  );

  // Interest rating survey state
  const [surveyExcitement, setSurveyExcitement] = useState(5);
  const [surveyConfidence, setSurveyConfidence] = useState(5);
  const [surveyGameAppeal, setSurveyGameAppeal] = useState(5);
  const [surveyEaseOfUse, setSurveyEaseOfUse] = useState(5);
  const [surveyContinued, setSurveyContinued] = useState(5);
  const [preferredFeature, setPreferredFeature] = useState('4 Tầng học tập');
  const [studentComment, setStudentComment] = useState('');
  const [surveySubmitted, setSurveySubmitted] = useState(false);

  // Current student stat
  const currentStudentName = user?.name || 'Nguyễn Văn An';
  const myStat = studentsStat.find((s) => s.studentName.toLowerCase() === currentStudentName.toLowerCase()) || studentsStat[0];
  const myArtifacts = artifacts.filter((a) => a.studentName.toLowerCase() === currentStudentName.toLowerCase());

  const handleArtifactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectTitle.trim()) return;

    let parsedRows: (string | number)[][] = [];
    try {
      parsedRows = JSON.parse(tableDataJson);
    } catch {
      parsedRows = [
        ['Mục 1', 'Mục 2', 'Tổng cộng'],
        [10, 20, 30]
      ];
    }

    const headers = (parsedRows[0] || []).map(String);
    const rows = parsedRows.slice(1);

    const formulasArray = formulasInput.split('\n').map((f) => f.trim()).filter(Boolean);

    submitArtifact({
      studentId: myStat.studentId,
      studentName: myStat.studentName,
      className: myStat.className,
      projectTitle,
      category,
      formulasUsed: formulasArray.length > 0 ? formulasArray : ['=SUM(B2:D2)', '=AVERAGE(B2:D2)'],
      tablePreview: {
        headers: headers.length > 0 ? headers : ['Họ tên', 'Điểm', 'Tổng'],
        rows: rows.length > 0 ? rows : [['An', 9, 9]],
      },
    });

    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    setShowSubmitModal(false);
    setProjectTitle('');
    setFormulasInput('');
    setActiveTab('my_artifacts');
  };

  const handleAddBugLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBugTitle.trim() || !newBugWrong.trim() || !newBugCorrect.trim()) return;
    setBugLogs([
      {
        id: `bug_${Date.now()}`,
        title: newBugTitle,
        formulaWrong: newBugWrong,
        formulaCorrect: newBugCorrect,
        errorType: newBugErrorType || 'Lỗi cú pháp bảng tính',
        date: new Date().toLocaleDateString('vi-VN'),
        status: 'Đã khắc phục',
        teacherNote: 'Em tự phát hiện và sửa lỗi xuất sắc!'
      },
      ...bugLogs
    ]);
    confetti({ particleCount: 50, spread: 50, origin: { y: 0.6 } });
    setShowAddBugModal(false);
    setNewBugTitle('');
    setNewBugWrong('');
    setNewBugCorrect('');
    setNewBugErrorType('');
  };

  const handleSurveySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const overall = Number(((surveyExcitement + surveyConfidence + surveyGameAppeal + surveyEaseOfUse + surveyContinued) / 5).toFixed(1));

    recordInterestRating({
      studentId: myStat.studentId,
      studentName: myStat.studentName,
      className: myStat.className,
      overallInterest: overall,
      criteria: {
        excitement: surveyExcitement,
        confidence: surveyConfidence,
        gameAppeal: surveyGameAppeal,
        easeOfUse: surveyEaseOfUse,
        continuedDesire: surveyContinued,
      },
      preferredFeature,
      studentComment: studentComment || 'Em rất thích học hàm trên FunHàm, các bài tập rất trực quan!',
    });

    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    setSurveySubmitted(true);
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <Button
          onClick={() => navigate('/student')}
          className="bg-white hover:bg-slate-100 text-slate-700 border-2 border-slate-300 font-black text-xs uppercase px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" /> Bảng điều khiển
        </Button>

        <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 border border-amber-300 text-amber-800 rounded-full text-xs font-black uppercase">
          <Award className="w-3.5 h-3.5 text-amber-600" />
          <span>Hồ Sơ Minh Chứng Học Tập Của Em</span>
        </div>
      </div>

      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-blue-950 p-6 md:p-8 rounded-3xl border-4 border-b-8 border-indigo-900 shadow-2xl text-white relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-400/20 text-emerald-300 rounded-full text-xs font-black uppercase border border-emerald-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>MINH CHỨNG NĂNG LỰC TIN HỌC 7</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black uppercase text-white">
              HỒ SƠ HỌC TẬP & SẢN PHẨM: <span className="text-yellow-300">{myStat.studentName}</span>
            </h1>
            <p className="text-slate-300 text-xs md:text-sm font-bold">
              Lớp: <span className="text-cyan-300 font-black">{myStat.className}</span> • Ghi nhận kết quả câu đúng, số lần làm, tiến bộ trước/sau và sản phẩm bảng tính thực tế.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              onClick={() => setShowSubmitModal(true)}
              className="bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase px-4 py-3 rounded-xl shadow-lg border-2 border-b-4 border-amber-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Nộp Sản Phẩm Bảng Tính
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="flex flex-wrap gap-2 bg-white p-2 rounded-2xl border-2 border-slate-200 shadow-sm">
        {[
          { id: 'my_stats', label: '📊 Tiến độ & Kết quả Trước/Sau', emoji: '📈' },
          { id: 'my_artifacts', label: `📑 Sản phẩm thực hành (${myArtifacts.length})`, emoji: '💼' },
          { id: 'bug_diary', label: `🐛 Nhật kí sửa lỗi (${bugLogs.length})`, emoji: '🔍' },
          { id: 'interest_survey', label: '❤️ Đánh giá mức độ hứng thú', emoji: '⭐' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "px-4 py-2.5 rounded-xl font-black text-xs uppercase transition-all flex items-center gap-2 cursor-pointer",
              activeTab === tab.id
                ? "bg-slate-900 text-white shadow-md scale-102"
                : "bg-slate-50 text-slate-600 hover:bg-slate-100"
            )}
          >
            <span>{tab.emoji}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* ====================== TAB 1: MY STATS & PRE-POST ====================== */}
      {activeTab === 'my_stats' && (
        <div className="space-y-6">
          {/* 4 Highlights */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-3xl border-3 border-emerald-300 shadow-md">
              <span className="text-xs font-black text-emerald-700 uppercase block">Số câu đúng</span>
              <span className="text-3xl font-black text-emerald-800 font-mono mt-1 block">
                {myStat.correctAnswers}
              </span>
              <span className="text-xs font-bold text-slate-400 mt-1 block">
                Đạt {myStat.accuracyRate}% độ chính xác
              </span>
            </div>

            <div className="bg-white p-5 rounded-3xl border-3 border-blue-300 shadow-md">
              <span className="text-xs font-black text-blue-700 uppercase block">Số lần làm</span>
              <span className="text-3xl font-black text-blue-800 font-mono mt-1 block">
                {myStat.totalAttempts}
              </span>
              <span className="text-xs font-bold text-slate-400 mt-1 block">
                Luyện tập kiên trì, không ngại thử thách
              </span>
            </div>

            <div className="bg-white p-5 rounded-3xl border-3 border-purple-300 shadow-md">
              <span className="text-xs font-black text-purple-700 uppercase block">Mức hoàn thành</span>
              <span className="text-3xl font-black text-purple-800 font-mono mt-1 block">
                {myStat.completionRate}%
              </span>
              <span className="text-xs font-bold text-slate-400 mt-1 block">
                Vượt qua 4 cấp độ năng lực hàm
              </span>
            </div>

            <div className="bg-white p-5 rounded-3xl border-3 border-cyan-300 shadow-md">
              <span className="text-xs font-black text-cyan-700 uppercase block">Tiến bộ Trước/Sau</span>
              <span className="text-3xl font-black text-cyan-800 font-mono mt-1 block">
                +{myStat.deltaScore} đ
              </span>
              <span className="text-xs font-bold text-slate-400 mt-1 block">
                Từ {myStat.preTestScore} ➔ <span className="text-emerald-600 font-black">{myStat.postTestScore} điểm</span>
              </span>
            </div>
          </div>

          {/* Pre-Post Progress Card */}
          <div className="bg-white p-6 md:p-8 rounded-3xl border-3 border-slate-200 shadow-md space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-black text-base text-slate-900 uppercase">
                BIỂU ĐỒ MINH CHỨNG PHÁT TRIỂN NĂNG LỰC
              </h3>
              <p className="text-xs text-slate-500 font-bold">
                So sánh năng lực sử dụng hàm bảng tính của em Trước và Sau khi học cùng FUNHÀM
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-black text-slate-600">
                    <span>Trước khi dùng FUNHAM (Kiểm tra đầu vào):</span>
                    <span className="font-mono text-sm">{myStat.preTestScore} / 10</span>
                  </div>
                  <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                    <div className="h-full bg-slate-400 rounded-full" style={{ width: `${myStat.preTestScore * 10}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-black text-emerald-700">
                    <span>Sau khi học cùng FUNHAM (Kiểm tra thực nghiệm):</span>
                    <span className="font-mono text-sm text-emerald-700 font-black">{myStat.postTestScore} / 10</span>
                  </div>
                  <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden border border-emerald-300">
                    <div className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full" style={{ width: `${myStat.postTestScore * 10}%` }} />
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-emerald-50 border-2 border-emerald-200 space-y-2">
                <div className="flex items-center gap-2 text-emerald-800 font-black text-xs uppercase">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Đánh giá từ Giáo viên:</span>
                </div>
                <p className="text-xs font-bold text-slate-700 leading-relaxed">
                  "Em đã khắc phục hoàn toàn thói quen gõ nhầm dấu gạch ngang (-) thành dấu hai chấm (:). Nắm rất chắc cú pháp dải ô liền kề và đã tự tin lập bảng điểm cho cả nhóm."
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================== TAB 2: MY ARTIFACTS ====================== */}
      {activeTab === 'my_artifacts' && (
        <div className="space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-3xl border-3 border-slate-200 shadow-md space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-black text-base text-slate-900 uppercase">
                  SẢN PHẨM THỰC HÀNH CỦA EM
                </h3>
                <p className="text-xs text-slate-500 font-bold">
                  Các bảng tính thực tế em đã tạo và được lưu trữ làm hồ sơ minh chứng học tập
                </p>
              </div>

              <Button
                onClick={() => setShowSubmitModal(true)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Nộp sản phẩm mới
              </Button>
            </div>

            {myArtifacts.length === 0 ? (
              <div className="text-center py-12 space-y-3 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-300">
                <span className="text-4xl">📑</span>
                <h4 className="font-black text-sm text-slate-700 uppercase">Em chưa nộp sản phẩm nào</h4>
                <p className="text-xs text-slate-500 font-bold max-w-sm mx-auto">
                  Hãy tạo bảng tính đầu tiên (Bảng điểm, Kế hoạch nhỏ...) để làm minh chứng cho giáo viên!
                </p>
                <Button
                  onClick={() => setShowSubmitModal(true)}
                  className="bg-indigo-600 text-white font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  Nộp ngay
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {myArtifacts.map((art) => (
                  <div 
                    key={art.id}
                    className="p-5 rounded-3xl border-3 border-slate-200 bg-white shadow-md space-y-3 flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full border border-indigo-200">
                          {art.category}
                        </span>
                        <span className="font-mono text-xs font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                          Điểm: {art.rubrics.totalScore} / 10
                        </span>
                      </div>

                      <h4 className="font-black text-base text-slate-900">{art.projectTitle}</h4>

                      <div className="space-y-1">
                        <span className="text-[10px] font-black uppercase text-slate-400 block">Công thức đã dùng:</span>
                        <div className="flex flex-wrap gap-1">
                          {art.formulasUsed.map((f, i) => (
                            <span key={i} className="font-mono text-xs font-black bg-slate-900 text-yellow-300 px-2.5 py-1 rounded-lg">
                              {f}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Mini table preview */}
                      <div className="bg-slate-950 text-slate-200 p-3 rounded-2xl text-[10px] font-mono overflow-x-auto shadow-inner">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="border-b border-slate-800 text-slate-400">
                              {art.tablePreview.headers.map((h, i) => (
                                <th key={i} className="p-1">{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {art.tablePreview.rows.map((r, i) => (
                              <tr key={i} className="border-b border-slate-800">
                                {r.map((c, cIdx) => (
                                  <td key={cIdx} className="p-1">{c}</td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 space-y-1">
                      <div className="text-[11px] font-bold text-slate-500">
                        👩‍🏫 <span className="font-black text-slate-800">Nhận xét:</span> {art.teacherFeedback}
                      </div>
                      <span className="text-[10px] text-slate-400 block">{art.submittedAt}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ====================== TAB: BUG FIXING DIARY ====================== */}
      {activeTab === 'bug_diary' && (
        <div className="space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-3xl border-3 border-slate-200 shadow-md space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-black text-base text-slate-900 uppercase">
                  NHẬT KÍ SỬA LỖI & GỠ BUG CÔNG THỨC CỦA EM
                </h3>
                <p className="text-xs text-slate-500 font-bold">
                  Ghi lại hành trình phát hiện lỗi, phân tích nguyên nhân và cách khắc phục trong các bài tập & trò chơi Thợ săn lỗi
                </p>
              </div>

              <Button
                onClick={() => setShowAddBugModal(true)}
                className="bg-rose-600 hover:bg-rose-700 text-white font-black text-xs uppercase px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Ghi nhận lỗi mới
              </Button>
            </div>

            {/* AI Assistant Banner */}
            <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-5 rounded-3xl text-white shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="space-y-1 text-center md:text-left">
                <span className="bg-white/25 text-xs font-black uppercase px-3 py-1 rounded-full">
                  ✨ Trợ lý AI Thông minh (Gemini 3.8 Flash)
                </span>
                <h4 className="font-black text-lg">Hỏi AI giải thích lỗi, gợi ý từng bước & tạo nhiệm vụ luyện tập</h4>
                <p className="text-xs text-purple-100 font-bold">
                  Nhận phân tích chi tiết, hướng dẫn từng bước và bài tập thực hành cá nhân hóa ngay lập tức.
                </p>
              </div>
              <Button
                onClick={() => setShowAiModal(true)}
                className="bg-white text-indigo-900 hover:bg-purple-50 font-black text-xs uppercase px-5 py-3 rounded-2xl shadow-md shrink-0 cursor-pointer"
              >
                🤖 Hỏi AI Hỗ trợ ngay
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-rose-50 p-4 rounded-2xl border-2 border-rose-200">
                <span className="text-xs font-black text-rose-700 uppercase block">Tổng số lỗi đã phát hiện</span>
                <span className="text-3xl font-black text-rose-800 font-mono mt-1 block">{bugLogs.length} lỗi</span>
                <span className="text-[11px] font-bold text-rose-600 mt-1 block">Khắc phục thành công 100%</span>
              </div>
              <div className="bg-amber-50 p-4 rounded-2xl border-2 border-amber-200">
                <span className="text-xs font-black text-amber-700 uppercase block">Lỗi thường gặp nhất</span>
                <span className="text-sm font-black text-amber-900 mt-1 block">Ký hiệu dải ô (: vs -)</span>
                <span className="text-[11px] font-bold text-amber-600 mt-1 block">Đã thành thạo tuyệt đối</span>
              </div>
              <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-200">
                <span className="text-xs font-black text-emerald-700 uppercase block">Trạng thái tư duy sửa lỗi</span>
                <span className="text-sm font-black text-emerald-900 mt-1 block">🌟 Thợ săn lỗi xuất sắc</span>
                <span className="text-[11px] font-bold text-emerald-600 mt-1 block">Không lặp lại lỗi cũ</span>
              </div>
            </div>

            <div className="space-y-4">
              {bugLogs.map((bug) => (
                <div 
                  key={bug.id}
                  className="p-5 rounded-3xl border-3 border-slate-200 bg-slate-50 shadow-sm hover:border-rose-300 transition-all space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase bg-rose-100 text-rose-700 px-3 py-1 rounded-full border border-rose-200">
                        🐛 {bug.title}
                      </span>
                      <span className="text-xs font-bold text-slate-400">📅 {bug.date}</span>
                    </div>
                    <span className="text-xs font-black text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-200">
                      ✨ {bug.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3.5 rounded-2xl bg-red-950 text-red-300 font-mono text-xs space-y-1">
                      <span className="text-[10px] font-black uppercase text-red-400 block">❌ Công thức hỏng (Trước khi sửa):</span>
                      <div className="text-base font-black tracking-wider">{bug.formulaWrong}</div>
                      <div className="text-[11px] text-red-200/80 pt-1 border-t border-red-900">
                        <strong>Nguyên nhân:</strong> {bug.errorType}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-emerald-950 text-emerald-300 font-mono text-xs space-y-1">
                      <span className="text-[10px] font-black uppercase text-emerald-400 block">✅ Công thức chuẩn (Sau khi sửa):</span>
                      <div className="text-base font-black tracking-wider">{bug.formulaCorrect}</div>
                      <div className="text-[11px] text-emerald-200/80 pt-1 border-t border-emerald-900">
                        <strong>Giải pháp:</strong> Đã kiểm tra và chạy kết quả chính xác trên bảng tính.
                      </div>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 flex items-center gap-2">
                    <span>👩‍🏫 Lời phê giáo viên:</span>
                    <span className="text-indigo-700 font-black">{bug.teacherNote}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ====================== TAB 3: INTEREST SURVEY ====================== */}
      {activeTab === 'interest_survey' && (
        <div className="space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-3xl border-3 border-slate-200 shadow-md space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <h3 className="font-black text-base text-slate-900 uppercase">
                ĐÁNH GIÁ MỨC ĐỘ HỨNG THÚ & ĐỘNG LỰC HỌC TẬP CỦA EM
              </h3>
              <p className="text-xs text-slate-500 font-bold">
                Ý kiến chân thực của em là minh chứng quý giá giúp thầy cô hoàn thiện đề tài nghiên cứu dạy học!
              </p>
            </div>

            {surveySubmitted ? (
              <div className="p-8 rounded-3xl bg-emerald-50 border-2 border-emerald-300 text-center space-y-3">
                <span className="text-4xl">🎉</span>
                <h4 className="font-black text-lg text-emerald-800 uppercase">
                  CẢM ƠN EM ĐÃ GỬI ĐÁNH GIÁ!
                </h4>
                <p className="text-xs text-emerald-700 font-bold max-w-md mx-auto">
                  Dữ liệu đánh giá của em đã được ghi nhận thành công!
                </p>
                <Button
                  onClick={() => setSurveySubmitted(false)}
                  className="bg-emerald-600 text-white font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  Đánh giá lại
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSurveySubmit} className="space-y-6">
                <div className="space-y-4">
                  {[
                    { label: '1. Mức độ hào hứng khi học hàm cùng FUNHAM', val: surveyExcitement, set: setSurveyExcitement },
                    { label: '2. Mức độ tự tin khi tự lập công thức', val: surveyConfidence, set: setSurveyConfidence },
                    { label: '3. Sức hút của các trò chơi (Đua xe, Săn lỗi, 4 tầng)', val: surveyGameAppeal, set: setSurveyGameAppeal },
                    { label: '4. Độ dễ hiểu của bài học và bảng tính minh họa', val: surveyEaseOfUse, set: setSurveyEaseOfUse },
                    { label: '5. Em có mong muốn tiếp tục học Tin học theo cách này?', val: surveyContinued, set: setSurveyContinued },
                  ].map((item, idx) => (
                    <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <span className="text-xs font-black text-slate-800">{item.label}</span>
                      <div className="flex items-center gap-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => item.set(star)}
                            className={cn(
                              "w-8 h-8 rounded-xl font-black text-xs transition-all cursor-pointer",
                              item.val >= star
                                ? "bg-amber-400 text-slate-950 scale-110 shadow-sm"
                                : "bg-slate-200 text-slate-400 hover:bg-slate-300"
                            )}
                          >
                            ★
                          </button>
                        ))}
                        <span className="font-mono text-xs font-black text-slate-700 w-8 text-center">
                          {item.val}/5
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-700 uppercase block">
                    Tính năng em thích nhất trên FUNHAM:
                  </label>
                  <select
                    value={preferredFeature}
                    onChange={(e) => setPreferredFeature(e.target.value)}
                    className="w-full text-xs font-bold p-3 rounded-xl border-2 border-slate-300 bg-white"
                  >
                    <option value="4 Tầng học tập">4 Tầng học tập (Nhận biết ➔ Hiểu ➔ Bảng điểm ➔ Sửa lỗi)</option>
                    <option value="Trò chơi Săn lỗi">Trò chơi Săn lỗi công thức (Bug Hunter)</option>
                    <option value="Đua xe công thức">Đua xe công thức (Formula Racing)</option>
                    <option value="Thực hành bảng tính">Thực hành bảng tính tự do</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-700 uppercase block">
                    Cảm nghĩ hoặc góp ý của em gửi thầy cô:
                  </label>
                  <textarea
                    rows={3}
                    value={studentComment}
                    onChange={(e) => setStudentComment(e.target.value)}
                    placeholder="Em cảm thấy học hàm trên FunHàm thế nào so với trước đây..."
                    className="w-full text-xs font-medium p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-indigo-600"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-pink-600 hover:bg-pink-700 text-white font-black text-xs uppercase py-3.5 rounded-xl shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" /> Gửi Đánh Giá Minh Chứng
                </Button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* MODAL: SUBMIT PRACTICAL ARTIFACT */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-4 border-slate-300 shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 space-y-5">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-black text-lg text-slate-900 uppercase">
                NỘP SẢN PHẨM BẢNG TÍNH THỰC HÀNH
              </h3>
              <p className="text-xs text-slate-500 font-bold">
                Lưu lại bảng tính của em để làm minh chứng năng lực thực tế.
              </p>
            </div>

            <form onSubmit={handleArtifactSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">Tên đề tài / Sản phẩm:</label>
                <input
                  type="text"
                  required
                  value={projectTitle}
                  onChange={(e) => setProjectTitle(e.target.value)}
                  placeholder="Ví dụ: Bảng điểm nhóm 1 / Kế hoạch thu gom giấy vụn"
                  className="w-full text-xs font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-indigo-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">Thể loại sản phẩm:</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full text-xs font-bold p-3 rounded-xl border-2 border-slate-300 bg-white"
                >
                  <option value="Bảng điểm">Bảng điểm học tập</option>
                  <option value="Kế hoạch nhỏ">Kế hoạch nhỏ / Hoạt động Đội</option>
                  <option value="Quản lý thu chi">Quản lý chi tiêu / Dã ngoại</option>
                  <option value="Theo dõi thể thao">Theo dõi thể thao / Rèn luyện</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">
                  Các công thức em đã dùng (mỗi dòng một công thức):
                </label>
                <textarea
                  rows={2}
                  value={formulasInput}
                  onChange={(e) => setFormulasInput(e.target.value)}
                  placeholder="=SUM(B2:D2)&#10;=AVERAGE(B2:D2)&#10;=MAX(E2:E10)"
                  className="w-full text-xs font-mono font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-indigo-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">
                  Dữ liệu bảng tính (định dạng mảng JSON hoặc dùng mẫu có sẵn):
                </label>
                <textarea
                  rows={4}
                  value={tableDataJson}
                  onChange={(e) => setTableDataJson(e.target.value)}
                  className="w-full text-[11px] font-mono p-3 rounded-xl border-2 border-slate-300 bg-slate-900 text-emerald-400 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="bg-slate-200 text-slate-700 font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  Hủy
                </Button>
                <Button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase px-5 py-2 rounded-xl shadow-md"
                >
                  Nộp Sản Phẩm ➔
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD BUG LOG */}
      {showAddBugModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-4 border-slate-300 shadow-2xl max-w-lg w-full p-6 md:p-8 space-y-5">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-black text-lg text-slate-900 uppercase">
                GHI NHẬT KÍ SỬA LỖI CÔNG THỨC MỚI
              </h3>
              <p className="text-xs text-slate-500 font-bold">
                Tự ghi nhận lại một lỗi bảng tính em vừa phát hiện và khắc phục thành công.
              </p>
            </div>

            <form onSubmit={handleAddBugLog} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">Tên lỗi / Tình huống:</label>
                <input
                  type="text"
                  required
                  value={newBugTitle}
                  onChange={(e) => setNewBugTitle(e.target.value)}
                  placeholder="Ví dụ: Thiếu dấu ngoặc, Gõ sai tên hàm..."
                  className="w-full text-xs font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-rose-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">Công thức hỏng (Ban đầu):</label>
                <input
                  type="text"
                  required
                  value={newBugWrong}
                  onChange={(e) => setNewBugWrong(e.target.value)}
                  placeholder="Ví dụ: =AVERAGE(C1 C10)"
                  className="w-full text-xs font-mono font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-rose-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">Công thức chuẩn (Sau sửa):</label>
                <input
                  type="text"
                  required
                  value={newBugCorrect}
                  onChange={(e) => setNewBugCorrect(e.target.value)}
                  placeholder="Ví dụ: =AVERAGE(C1:C10)"
                  className="w-full text-xs font-mono font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-rose-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 uppercase">Loại lỗi / Nguyên nhân:</label>
                <input
                  type="text"
                  value={newBugErrorType}
                  onChange={(e) => setNewBugErrorType(e.target.value)}
                  placeholder="Ví dụ: Thiếu dấu hai chấm ngăn cách vùng"
                  className="w-full text-xs font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-rose-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  onClick={() => setShowAddBugModal(false)}
                  className="bg-slate-200 text-slate-700 font-black text-xs uppercase px-4 py-2 rounded-xl"
                >
                  Hủy
                </Button>
                <Button
                  type="submit"
                  className="bg-rose-600 hover:bg-rose-700 text-white font-black text-xs uppercase px-5 py-2 rounded-xl shadow-md"
                >
                  Lưu Nhật Kí ➔
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: AI TUTOR & ERROR EXPLANATION */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border-4 border-purple-300 shadow-2xl max-w-2xl w-full p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🤖</span>
                <div>
                  <h3 className="font-black text-lg text-slate-900 uppercase">
                    TRỢ LÝ AI HỖ TRỢ GIẢI THÍCH LỖI & TẠO NHIỆM VỤ LUYỆN TẬP
                  </h3>
                  <p className="text-xs text-purple-600 font-bold">
                    Phân tích công thức bằng Gemini 3.8 Flash • Gợi ý từng bước & Bài tập cá nhân hóa
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setShowAiModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 font-black flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAskAi} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700 uppercase">Công thức cần AI kiểm tra:</label>
                  <input
                    type="text"
                    required
                    value={aiFormulaInput}
                    onChange={(e) => setAiFormulaInput(e.target.value)}
                    placeholder="Ví dụ: =AVERAGE(C1-C10)"
                    className="w-full text-xs font-mono font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-purple-600"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700 uppercase">Triệu chứng lỗi (nếu biết):</label>
                  <input
                    type="text"
                    value={aiErrorTypeInput}
                    onChange={(e) => setAiErrorTypeInput(e.target.value)}
                    placeholder="Ví dụ: Tính sai kết quả / Sai dải ô"
                    className="w-full text-xs font-bold p-3 rounded-xl border-2 border-slate-300 bg-white outline-none focus:border-purple-600"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={aiLoading}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-sm uppercase py-3 rounded-2xl shadow-lg cursor-pointer flex items-center justify-center gap-2"
              >
                {aiLoading ? (
                  <>⏳ AI đang phân tích và tạo hướng dẫn...</>
                ) : (
                  <>✨ Gửi AI Phân Tích & Gợi Ý Từng Bước ➔</>
                )}
              </Button>
            </form>

            {aiResult && (
              <div className="space-y-4 pt-4 border-t border-slate-200">
                <div className="bg-purple-50 p-4 rounded-2xl border-2 border-purple-200 space-y-2">
                  <span className="text-xs font-black text-purple-700 uppercase flex items-center gap-1.5">
                    <span>💡</span> Giải thích bản chất lỗi từ AI:
                  </span>
                  <p className="text-xs md:text-sm font-bold text-slate-800 leading-relaxed">
                    {aiResult.explanation}
                  </p>
                </div>

                <div className="bg-blue-50 p-4 rounded-2xl border-2 border-blue-200 space-y-2">
                  <span className="text-xs font-black text-blue-700 uppercase flex items-center gap-1.5">
                    <span>🧭</span> Gợi ý từng bước khắc phục:
                  </span>
                  <ul className="space-y-1.5 pl-2">
                    {aiResult.stepByStep?.map((step, idx) => (
                      <li key={idx} className="text-xs font-bold text-blue-900 flex items-start gap-2">
                        <span className="bg-blue-200 text-blue-800 w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-black">{idx + 1}</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {aiResult.practiceTask && (
                  <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-200 space-y-2">
                    <span className="text-xs font-black text-emerald-700 uppercase flex items-center gap-1.5">
                      <span>🎯</span> Nhiệm vụ luyện tập AI tạo riêng cho em:
                    </span>
                    <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1">
                      <div className="font-black text-emerald-900 text-xs">{aiResult.practiceTask.title}</div>
                      <div className="text-xs text-slate-700">{aiResult.practiceTask.prompt}</div>
                      <div className="text-xs font-mono font-bold text-emerald-700 pt-1">Công thức mẫu: {aiResult.practiceTask.sampleFormula}</div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Minh chứng hoạt động thực tế của AI */}
            <div className="space-y-3 pt-4 border-t border-slate-200">
              <h4 className="font-black text-xs text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
                <span>📹</span> Minh chứng hoạt động thực tế của AI (AI Operation Evidence Log):
              </h4>
              <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                {aiEvidenceLogs.map((log, idx) => (
                  <div key={idx} className="p-3 bg-slate-900 text-slate-200 rounded-xl font-mono text-[11px] space-y-1 shadow-inner">
                    <div className="flex justify-between items-center text-purple-400 font-bold border-b border-slate-800 pb-1">
                      <span>🕒 {log.timestamp}</span>
                      <span className="text-emerald-400">✅ Thành công</span>
                    </div>
                    <div><strong>Formula:</strong> {log.formula}</div>
                    <div className="text-slate-300 truncate"><strong>AI Response:</strong> {log.result?.explanation}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button
                onClick={() => setShowAiModal(false)}
                className="bg-slate-800 text-white font-black text-xs uppercase px-5 py-2.5 rounded-xl cursor-pointer hover:bg-slate-900"
              >
                Đóng Cửa Sổ AI
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
