import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  Stethoscope, 
  CheckCircle2, 
  AlertTriangle, 
  HelpCircle, 
  ArrowRight, 
  RotateCcw, 
  Lightbulb, 
  Layers, 
  Send, 
  Trophy, 
  ShieldCheck, 
  BookOpen, 
  Check, 
  ChevronDown, 
  ChevronUp,
  Cpu,
  Flame,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { useAuthStore } from '../../store/authStore';
import { useEvidenceStore } from '../../store/evidenceStore';
import { useDataStore } from '../../store/dataStore';
import { 
  diagnoseFormula, 
  evaluateFormulaOnGrid, 
  TaskContext, 
  DiagnosticResult, 
  ERROR_DEFINITIONS,
  ErrorCode 
} from '../../utils/formulaValidator';
import { cn } from '../../utils';
import { syncSaveAttempt } from '../../services/databaseService';

// Ngân hàng nhiệm vụ thực hành bảng tính bám sát SGK Tin học 7 - Kết nối tri thức
const SAMPLE_TASKS: TaskContext[] = [
  {
    id: 'task_01',
    title: 'Bảng Điểm Kiểm Tra Học Kỳ Môn Tin Học 7',
    requirement: 'Tính ĐIỂM TRUNG BÌNH 3 môn Toán, Văn, Tin của bạn Lan từ cột C đến cột E (ô C2 đến E2)',
    expectedFunction: 'AVERAGE',
    expectedRange: 'C2:E2',
    gridData: {
      headers: ['A: STT', 'B: Họ và tên', 'C: Toán', 'D: Ngữ văn', 'E: Tin học', 'F: ĐTB'],
      rows: [
        [1, 'Nguyễn Thị Lan', 8.5, 9.0, 9.5, '?'],
        [2, 'Trần Minh Quang', 7.0, 8.0, 8.5, ''],
        [3, 'Lê Hoàng Yến', 9.0, 8.5, 10.0, ''],
        [4, 'Phạm Quốc Bảo', 6.5, 7.0, 8.0, '']
      ],
      numericColumns: [2, 3, 4]
    }
  },
  {
    id: 'task_02',
    title: 'Kế Hoạch Quyên Góp Nuôi Heo Đất Lớp 7A1',
    requirement: 'Tính TỔNG số tiền quyên góp của cả 4 tổ từ ô B2 đến B5',
    expectedFunction: 'SUM',
    expectedRange: 'B2:B5',
    gridData: {
      headers: ['A: Tổ', 'B: Số tiền (nghìn đồng)', 'C: Chỉ tiêu', 'D: Trạng thái'],
      rows: [
        ['Tổ 1', 120, 100, 'Đạt'],
        ['Tổ 2', 150, 100, 'Vượt'],
        ['Tổ 3', 95, 100, 'Gần đạt'],
        ['Tổ 4', 135, 100, 'Vượt']
      ],
      numericColumns: [1]
    }
  },
  {
    id: 'task_03',
    title: 'Hội Khỏe Phù Đổng - Nhảy Xa Nam',
    requirement: 'Tìm thành tích NHẢY XA CAO NHẤT (lớn nhất) của các vận động viên trong vùng B2 đến B6',
    expectedFunction: 'MAX',
    expectedRange: 'B2:B6',
    gridData: {
      headers: ['A: Vận động viên', 'B: Thành tích (m)', 'C: Xếp hạng'],
      rows: [
        ['Dương Tuấn Hải', 4.15, ''],
        ['Nguyễn Đức Cường', 4.52, ''],
        ['Hoàng Mạnh Dũng', 3.98, ''],
        ['Trần Phúc Thịnh', 4.35, ''],
        ['Võ Gia Huy', 4.20, '']
      ],
      numericColumns: [1]
    }
  },
  {
    id: 'task_04',
    title: 'Hội Khỏe Phù Đổng - Chạy 100m Nữ',
    requirement: 'Tìm thời gian chạy NHỎ NHẤT (nhanh nhất) của các bạn nữ trong vùng C2 đến C6',
    expectedFunction: 'MIN',
    expectedRange: 'C2:C6',
    gridData: {
      headers: ['A: STT', 'B: Họ và tên', 'C: Thời gian (giây)'],
      rows: [
        [1, 'Phạm Mai Anh', 14.8],
        [2, 'Trần Diệu Hà', 15.2],
        [3, 'Lê Cẩm Tú', 13.9],
        [4, 'Đỗ Quỳnh Chi', 16.1],
        [5, 'Bùi Thảo My', 14.3]
      ],
      numericColumns: [2]
    }
  },
  {
    id: 'task_05',
    title: 'Kiểm Kê Sĩ Số Tham Gia Thi Tin Học Trẻ',
    requirement: 'ĐẾM số lượng học sinh có nhập điểm số hợp lệ từ ô C2 đến C7',
    expectedFunction: 'COUNT',
    expectedRange: 'C2:C7',
    gridData: {
      headers: ['A: STT', 'B: Tên thí sinh', 'C: Điểm số', 'D: Ghi chú'],
      rows: [
        [1, 'Nguyễn An', 85, 'Đạt'],
        [2, 'Bình Minh', 90, 'Đạt'],
        [3, 'Cao Cường', 75, 'Đạt'],
        [4, 'Dương Đạt', 80, 'Đạt'],
        [5, 'Em Vy', 95, 'Xuất sắc'],
        [6, 'Gia Hân', 88, 'Đạt']
      ],
      numericColumns: [2]
    }
  }
];

export function FormulaDoctorPage() {
  const { user } = useAuthStore();
  const { updateStudent } = useDataStore();
  const { recordAiHintUsage, recordErrorCorrection } = useEvidenceStore();

  const [currentTaskIndex, setCurrentTaskIndex] = useState(0);
  const task = SAMPLE_TASKS[currentTaskIndex];

  // Trạng thái nhập công thức của học sinh
  const [formula, setFormula] = useState('=AVERGE(C2:E2)'); // Khởi tạo với 1 lỗi minh họa
  const [initialAttemptFormula, setInitialAttemptFormula] = useState('=AVERGE(C2:E2)');
  const [historyOfAttempts, setHistoryOfAttempts] = useState<string[]>([]);
  
  // Trạng thái chẩn đoán
  const [diagnostic, setDiagnostic] = useState<DiagnosticResult | null>(null);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [hasChecked, setHasChecked] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSource, setAiSource] = useState<'ai' | 'rule'>('rule');

  // Gợi ý 3 mức
  const [unlockedTier, setUnlockedTier] = useState<number>(1);
  const [tierHints, setTierHints] = useState<{
    tier1: string;
    tier2: string;
    tier3: string;
  }>({ tier1: '', tier2: '', tier3: '' });

  // Giải thích của học sinh
  const [studentSelfExplanation, setStudentSelfExplanation] = useState('');
  const [explanationSubmitted, setExplanationSubmitted] = useState(false);

  // Pháo hoa khi tự sửa đúng
  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  // Reset khi đổi bài
  const handleSelectTask = (index: number) => {
    setCurrentTaskIndex(index);
    const newTask = SAMPLE_TASKS[index];
    const sampleFaulty = `=${newTask.expectedFunction.toLowerCase()}m(${newTask.expectedRange.replace(':', '-')}`;
    setFormula(sampleFaulty);
    setInitialAttemptFormula(sampleFaulty);
    setHistoryOfAttempts([]);
    setDiagnostic(null);
    setHasChecked(false);
    setUnlockedTier(1);
    setTierHints({ tier1: '', tier2: '', tier3: '' });
    setStudentSelfExplanation('');
    setExplanationSubmitted(false);
  };

  // Hàm kiểm tra công thức bằng bộ phân tích cú pháp + gọi Gemini AI qua API máy chủ
  const handleCheckFormula = async (customInput?: string) => {
    const inputToCheck = (customInput || formula).trim();
    if (!inputToCheck) return;

    setIsDiagnosing(true);
    setHasChecked(true);

    // 1. Phân tích nội bộ deterministic chuẩn SGK Tin 7 trước
    const ruleResult = diagnoseFormula(inputToCheck, task);
    setDiagnostic(ruleResult);
    setTierHints({
      tier1: ruleResult.tier1Hint,
      tier2: ruleResult.tier2Hint,
      tier3: ruleResult.tier3Hint,
    });

    // 2. Gửi request đến server Gemini AI để nhận phản hồi sư phạm tự nhiên
    try {
      setIsAiLoading(true);
      const res = await fetch('/api/ai/diagnose-formula', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          formula: inputToCheck,
          taskRequirement: task.requirement,
          expectedFunction: task.expectedFunction,
          expectedRange: task.expectedRange,
          gridSummary: task.title,
        })
      });

      if (res.ok) {
        const aiData = await res.json();
        if (!aiData.fallback && aiData.tier1Hint) {
          setAiSource('ai');
          setTierHints({
            tier1: aiData.tier1Hint,
            tier2: aiData.tier2Hint,
            tier3: aiData.tier3Hint,
          });
        } else {
          setAiSource('rule');
        }
      } else {
        setAiSource('rule');
      }
    } catch (err) {
      console.warn('AI offline, relying on deterministic pedagogical rules:', err);
      setAiSource('rule');
    } finally {
      setIsAiLoading(false);
      setIsDiagnosing(false);
    }

    // 3. Ghi nhận quá trình học tập & sửa lỗi vào Evidence Store
    const studentName = user?.name || 'Học sinh';
    const studentId = user?.id || 'hs_current';
    const className = (user as any)?.className || '7A1';

    if (ruleResult.isCorrect) {
      triggerConfetti();
      // Nếu trước đó từng sai và giờ tự sửa đúng
      const wasFaulty = historyOfAttempts.length > 0 && !historyOfAttempts[0].startsWith(`=${task.expectedFunction}(${task.expectedRange})`);
      if (wasFaulty) {
        recordErrorCorrection({
          studentId,
          studentName,
          className,
          errorCode: (ruleResult.errorCode || 'E02') as ErrorCode,
          errorTitle: ruleResult.errorTitle || 'Tự sửa lỗi công thức thành công',
          initialFormula: initialAttemptFormula,
          correctedFormula: inputToCheck,
          hintsUsedCount: unlockedTier,
          isSuccessful: true
        });

        // Sync attempt & error event to cloud database in background
        syncSaveAttempt(
          {
            student_id: studentId,
            activity_id: task.id || 'doctor_task',
            activity_type: 'formula_doctor',
            score: 10,
            max_score: 10,
            started_at: new Date(Date.now() - 60000).toISOString(),
            completed_at: new Date().toISOString(),
            is_demo: Boolean((user as any)?.isDemo),
          },
          [
            {
              error_code: (ruleResult.errorCode || 'E02') as string,
              corrected: true,
              hint_count: unlockedTier,
            },
          ],
          {
            studentCode: (user as any)?.studentCode || 'HS01',
            classCode: className,
            displayName: studentName,
          }
        ).catch((err) => console.warn('Sync formula error event error:', err));

        // Thưởng XP cho học sinh
        if (user && user.role === 'student') {
          const studentXp = (user as any).xp ?? 950;
          updateStudent(studentId, { xp: studentXp + 50 });
        }
      }
    } else {
      // Ghi nhận lỗi phát hiện
      if (ruleResult.errorCode) {
        recordAiHintUsage({
          studentId,
          studentName,
          className,
          errorCode: ruleResult.errorCode,
          hintTier: unlockedTier as 1 | 2 | 3,
          formula: inputToCheck,
          resolved: false
        });
      }
    }

    setHistoryOfAttempts(prev => [...prev, inputToCheck]);
  };

  // Yêu cầu nâng mức gợi ý (1 -> 2 -> 3)
  const handleRequestNextTier = () => {
    if (unlockedTier < 3) {
      const nextTier = (unlockedTier + 1) as 1 | 2 | 3;
      setUnlockedTier(nextTier);

      const studentName = user?.name || 'Học sinh';
      const studentId = user?.id || 'hs_current';
      const className = (user as any)?.className || '7A1';

      if (diagnostic?.errorCode) {
        recordAiHintUsage({
          studentId,
          studentName,
          className,
          errorCode: diagnostic.errorCode,
          hintTier: nextTier,
          formula,
          resolved: false
        });
      }
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-teal-700 p-8 rounded-3xl border-4 border-b-8 border-indigo-950 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-80 h-80 bg-teal-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-black uppercase tracking-wider border border-yellow-400/30">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>CHỨC NĂNG TRỌNG TÂM FUNHAM AI V2.0</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black uppercase tracking-wider text-yellow-300 drop-shadow-md">
              🩺 PHÒNG KHÁM CÔNG THỨC & TRỢ LÝ AI SỬA LỖI
            </h1>
            <p className="text-blue-100 text-sm md:text-base font-bold leading-relaxed">
              Trợ lý AI chẩn đoán 10 mã lỗi cú pháp & ngữ nghĩa chuẩn SGK Tin học 7. Hệ thống đồng hành với em qua <strong className="text-yellow-300">3 mức gợi ý hỗ trợ</strong>: Gợi mở ➔ Định hướng ➔ Giải thích để em tự nhận ra lỗi sai và làm chủ hoàn toàn bảng tính! 🚀
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border-2 border-white/20 text-center shrink-0">
            <div className="text-xs font-black uppercase text-teal-200 mb-1">Mục tiêu học tập</div>
            <div className="text-2xl font-black text-white">Hiểu Từ Lỗi Sai</div>
            <div className="text-xs text-blue-200 mt-1">10 Mã Lỗi Chuẩn GDPT 2018</div>
          </div>
        </div>
      </div>

      {/* Task Selector Bar */}
      <div className="bg-white p-4 rounded-2xl border-3 border-slate-200 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen className="w-5 h-5 text-blue-600" />
          <span className="text-xs font-black uppercase text-slate-700 tracking-wider">
            Chọn Bài Tập Thực Hành Bảng Tính SGK Tin 7:
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_TASKS.map((t, idx) => (
            <button
              key={t.id}
              onClick={() => handleSelectTask(idx)}
              className={cn(
                "px-4 py-2.5 rounded-xl font-black text-xs uppercase tracking-wide border-2 transition-all cursor-pointer",
                currentTaskIndex === idx
                  ? "bg-blue-600 text-white border-blue-800 shadow-md scale-102"
                  : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300"
              )}
            >
              <span>{idx + 1}. {t.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Doctor Studio */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Spreadsheet Table & Task Requirement */}
        <div className="lg:col-span-7 space-y-6">
          <Card className="bg-white p-6 rounded-3xl border-4 border-b-8 border-slate-300 shadow-xl space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-lg text-xs font-black uppercase mb-1">
                  Nhiệm vụ {currentTaskIndex + 1}
                </span>
                <h2 className="text-xl md:text-2xl font-black text-slate-900 uppercase">
                  {task.title}
                </h2>
              </div>
              <Badge className="bg-emerald-100 text-emerald-800 border-emerald-300 font-black">
                Hàm: {task.expectedFunction}
              </Badge>
            </div>

            <div className="p-4 bg-amber-50 rounded-2xl border-2 border-amber-300 text-amber-900 font-bold text-sm flex items-start gap-3">
              <span className="text-2xl shrink-0">🎯</span>
              <div>
                <span className="font-black uppercase tracking-wider block text-xs text-amber-800 mb-0.5">Yêu cầu bài toán:</span>
                <p className="leading-snug">{task.requirement}</p>
              </div>
            </div>

            {/* Live Interactive Spreadsheet Grid Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-black text-slate-500 uppercase">
                <span>Bảng dữ liệu thực nghiệm:</span>
                <span className="text-blue-600 font-bold">Vùng đích cần tính: {task.expectedRange}</span>
              </div>
              <div className="overflow-x-auto border-3 border-slate-300 rounded-2xl shadow-inner bg-slate-50">
                <table className="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr className="bg-gradient-to-r from-slate-200 to-slate-100 text-slate-800 font-black border-b-2 border-slate-300 text-xs uppercase">
                      {task.gridData.headers.map((h, i) => (
                        <th key={i} className="px-3.5 py-3 border-r border-slate-300 text-center">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {task.gridData.rows.map((row, rIdx) => (
                      <tr 
                        key={rIdx} 
                        className={cn(
                          "border-b border-slate-200 transition-colors",
                          rIdx % 2 === 0 ? "bg-white" : "bg-slate-50/70"
                        )}
                      >
                        {row.map((cell, cIdx) => {
                          const isTargetCell = rIdx === 0 && cIdx === row.length - 1;
                          return (
                            <td 
                              key={cIdx} 
                              className={cn(
                                "px-3.5 py-2.5 border-r border-slate-200 font-semibold text-center text-slate-800 text-xs",
                                isTargetCell && "bg-yellow-200/60 font-black text-blue-800 outline outline-2 outline-yellow-400"
                              )}
                            >
                              {isTargetCell && diagnostic?.isCorrect && diagnostic.calculatedValue !== null
                                ? diagnostic.calculatedValue
                                : String(cell)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Card>

          {/* Formula Bar & Input Area */}
          <Card className="bg-slate-900 p-6 rounded-3xl border-4 border-b-8 border-slate-950 text-white shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center font-black text-xs text-white">
                  fx
                </div>
                <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                  Thanh công thức (Formula Bar)
                </span>
              </div>
              <span className="text-[11px] font-bold text-slate-400">
                Nhập công thức bắt đầu bằng "="
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch gap-3">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={formula}
                  onChange={(e) => setFormula(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleCheckFormula();
                  }}
                  placeholder="Ví dụ: =AVERAGE(C2:E2)"
                  className="w-full px-4 py-3.5 bg-slate-800 text-yellow-300 font-mono text-base md:text-lg font-bold rounded-2xl border-2 border-slate-700 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-500/20 transition-all shadow-inner"
                />
              </div>

              <Button
                onClick={() => handleCheckFormula()}
                disabled={isDiagnosing}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-black text-sm uppercase px-6 py-3.5 rounded-2xl shadow-lg border-2 border-b-4 border-blue-900 flex items-center justify-center gap-2 cursor-pointer active:translate-y-1"
              >
                {isDiagnosing ? (
                  <>
                    <Cpu className="w-4 h-4 animate-spin" />
                    <span>Đang chẩn đoán...</span>
                  </>
                ) : (
                  <>
                    <Stethoscope className="w-4 h-4" />
                    <span>Khám lỗi & Kiểm tra</span>
                  </>
                )}
              </Button>
            </div>

            {/* Quick Helper Keys for Grade 7 Students */}
            <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-800 text-xs">
              <span className="text-slate-400 font-bold mr-1">Phím nhanh:</span>
              {['=', 'SUM(', 'AVERAGE(', 'MAX(', 'MIN(', 'COUNT(', ':', ')'].map((btn) => (
                <button
                  key={btn}
                  onClick={() => setFormula(prev => prev + btn)}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-blue-300 rounded-lg font-mono text-xs font-black border border-slate-700 transition-colors cursor-pointer"
                >
                  {btn}
                </button>
              ))}
              <button
                onClick={() => setFormula('')}
                className="ml-auto text-xs text-rose-400 hover:text-rose-300 font-bold underline cursor-pointer"
              >
                Xóa làm lại
              </button>
            </div>
          </Card>
        </div>

        {/* Right Column: AI Diagnosis & 3-Tier Scaffolding Advice */}
        <div className="lg:col-span-5 space-y-6">
          <Card className="bg-white p-6 rounded-3xl border-4 border-b-8 border-slate-300 shadow-xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b-2 border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-blue-600 text-white flex items-center justify-center shadow-md">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black uppercase text-slate-900">
                    KẾT QUẢ CHẨN ĐOÁN SƯ PHẠM
                  </h3>
                  <div className="flex items-center gap-1.5 text-[11px] font-bold">
                    {aiSource === 'ai' ? (
                      <span className="text-purple-600 flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-purple-600" /> Trợ lý Gemini AI hỗ trợ
                      </span>
                    ) : (
                      <span className="text-teal-700 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-teal-600" /> Quy tắc chuẩn GDPT 2018
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {diagnostic && (
                <Badge className={diagnostic.isCorrect ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}>
                  {diagnostic.isCorrect ? '✅ CHÍNH XÁC' : `⚠️ LỖI ${diagnostic.errorCode || 'E01'}`}
                </Badge>
              )}
            </div>

            {/* Waiting State */}
            {!hasChecked && (
              <div className="p-8 text-center text-slate-400 space-y-3">
                <div className="w-16 h-16 rounded-3xl bg-slate-100 mx-auto flex items-center justify-center text-3xl">
                  💡
                </div>
                <h4 className="font-black text-slate-700 uppercase text-sm">Chưa có công thức nào được khám</h4>
                <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed font-bold">
                  Hãy nhập công thức vào thanh công thức bên trái và nhấn <strong className="text-blue-600">"Khám lỗi & Kiểm tra"</strong> để Trợ lý AI bắt đầu hỗ trợ em nhé!
                </p>
              </div>
            )}

            {/* Active Diagnosis Results */}
            {hasChecked && diagnostic && (
              <div className="space-y-4">
                {/* Status Box */}
                {diagnostic.isCorrect ? (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl text-emerald-900 space-y-2"
                  >
                    <div className="flex items-center gap-2 font-black text-sm uppercase text-emerald-800">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <span>XUẤT SẮC! CÔNG THỨC HOÀN TOÀN CHÍNH XÁC</span>
                    </div>
                    <p className="text-xs font-bold text-emerald-800 leading-relaxed">
                      Kết quả tính toán trên bảng số liệu là: <strong className="text-base text-emerald-950 underline">{diagnostic.calculatedValue}</strong>. Em đã làm chủ hoàn hảo hàm <strong>{task.expectedFunction}</strong>!
                    </p>
                  </motion.div>
                ) : (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-4 bg-rose-50 border-2 border-rose-400 rounded-2xl text-rose-900 space-y-1.5"
                  >
                    <div className="flex items-center gap-2 font-black text-sm uppercase text-rose-800">
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                      <span>PHÁT HIỆN: {diagnostic.errorTitle}</span>
                    </div>
                    <div className="text-xs font-bold text-rose-700">
                      Mã lỗi phân loại: <strong className="underline text-rose-900">{diagnostic.errorCode}</strong> ({diagnostic.category})
                    </div>
                  </motion.div>
                )}

                {/* 3-Tier Scaffolding Advice Section */}
                {!diagnostic.isCorrect && (
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                        <Layers className="w-4 h-4 text-purple-600" />
                        GỢI Ý SƯ PHẠM 3 MỨC ĐỘ:
                      </span>
                      <span className="text-[11px] font-bold text-purple-700">
                        Đang xem Mức {unlockedTier}/3
                      </span>
                    </div>

                    {/* Tier 1: Gợi mở (Câu hỏi tự vấn) */}
                    <div className="p-3.5 bg-blue-50/80 rounded-2xl border-2 border-blue-300 space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-black uppercase text-blue-900">
                        <span className="flex items-center gap-1.5">
                          <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[11px]">1</span>
                          Mức 1: Gợi mở (Tự vấn)
                        </span>
                        <Badge className="bg-blue-200 text-blue-800 text-[10px]">Khuyên dùng trước</Badge>
                      </div>
                      <p className="text-xs text-blue-950 font-bold leading-relaxed italic">
                        "{tierHints.tier1 || diagnostic.tier1Hint}"
                      </p>
                    </div>

                    {/* Tier 2: Định hướng (Chỉ rõ thành phần) */}
                    {unlockedTier >= 2 ? (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3.5 bg-amber-50/80 rounded-2xl border-2 border-amber-300 space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs font-black uppercase text-amber-900">
                          <span className="flex items-center gap-1.5">
                            <span className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-[11px]">2</span>
                            Mức 2: Định hướng thành phần
                          </span>
                        </div>
                        <p className="text-xs text-amber-950 font-bold leading-relaxed">
                          {tierHints.tier2 || diagnostic.tier2Hint}
                        </p>
                      </motion.div>
                    ) : (
                      <div className="p-3 bg-slate-100 rounded-2xl border border-dashed border-slate-300 flex items-center justify-between text-xs text-slate-500 font-bold">
                        <span>🔒 Gợi ý Mức 2 (Định hướng) đang khóa</span>
                        <Button 
                          size="sm" 
                          onClick={handleRequestNextTier}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-black px-3 py-1 rounded-xl"
                        >
                          Mở Mức 2
                        </Button>
                      </div>
                    )}

                    {/* Tier 3: Giải thích từng bước & ví dụ */}
                    {unlockedTier >= 3 ? (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3.5 bg-purple-50/80 rounded-2xl border-2 border-purple-300 space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs font-black uppercase text-purple-900">
                          <span className="flex items-center gap-1.5">
                            <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[11px]">3</span>
                            Mức 3: Giải thích chi tiết & ví dụ mẫu
                          </span>
                        </div>
                        <p className="text-xs text-purple-950 font-bold leading-relaxed">
                          {tierHints.tier3 || diagnostic.tier3Hint}
                        </p>
                      </motion.div>
                    ) : (
                      unlockedTier === 2 && (
                        <div className="p-3 bg-slate-100 rounded-2xl border border-dashed border-slate-300 flex items-center justify-between text-xs text-slate-500 font-bold">
                          <span>🔒 Em vẫn chưa sửa được? Mở giải thích chi tiết</span>
                          <Button 
                            size="sm" 
                            onClick={handleRequestNextTier}
                            className="bg-purple-100 hover:bg-purple-200 text-purple-800 text-xs font-black px-3 py-1 rounded-xl"
                          >
                            Mở Mức 3
                          </Button>
                        </div>
                      )
                    )}
                  </div>
                )}

                {/* Action after correct: Explain Result Meaning (Pedagogical Reflection) */}
                {diagnostic.isCorrect && (
                  <div className="space-y-3 pt-3 border-t-2 border-slate-100">
                    <div className="flex items-center gap-2 text-xs font-black text-slate-800 uppercase">
                      <Flame className="w-4 h-4 text-orange-500" />
                      <span>Thử Thách Năng Lực: Giải thích ý nghĩa kết quả</span>
                    </div>

                    {!explanationSubmitted ? (
                      <div className="space-y-2">
                        <textarea
                          value={studentSelfExplanation}
                          onChange={(e) => setStudentSelfExplanation(e.target.value)}
                          placeholder="Ví dụ: Kết quả 9.0 là điểm trung bình cộng 3 môn Toán, Văn, Tin của bạn Lan..."
                          className="w-full p-3 bg-slate-50 text-slate-900 text-xs font-semibold rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                          rows={2}
                        />
                        <Button
                          onClick={() => setExplanationSubmitted(true)}
                          disabled={!studentSelfExplanation.trim()}
                          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black text-xs uppercase py-2.5 rounded-xl cursor-pointer"
                        >
                          Gửi lời giải thích (+20 XP)
                        </Button>
                      </div>
                    ) : (
                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-xs font-bold flex items-center gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Đã ghi nhận lời giải thích của em! (+20 XP)</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </Card>

          {/* Responsible AI Transparency Card */}
          <div className="bg-slate-100 p-4 rounded-2xl border-2 border-slate-200 text-[11px] font-bold text-slate-600 space-y-1.5">
            <div className="flex items-center gap-1.5 text-slate-800 uppercase font-black">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              <span>Chính sách AI Có Trách Nhiệm (Responsible AI)</span>
            </div>
            <p className="leading-relaxed">
              Trợ lý FUNHAM AI được cấu hình chuyên biệt theo Chương trình GDPT 2018 môn Tin học 7. Hệ thống tuyệt đối không lưu trữ thông tin cá nhân nhạy cảm, không thiên vị, và luôn khuyến khích học sinh tự chủ tư duy sửa lỗi.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
