import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { saveSupabaseConfig } from './services/supabaseClient';
import { flushOfflineQueue } from './services/databaseService';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { StudentLayout } from './components/layout/StudentLayout';
import { TeacherLayout } from './components/layout/TeacherLayout';
import { StudentDashboard } from './pages/student/StudentDashboard';
import { LessonPage } from './pages/student/LessonPage';
import { GameLobby } from './pages/student/GameLobby';
import { QuizPage } from './pages/student/QuizPage';
import { LeaderboardPage } from './pages/student/LeaderboardPage';
import { SpreadsheetPractice } from './pages/student/SpreadsheetPractice';
import { MatchGame } from './pages/student/MatchGame';
import { BugHunterGame } from './pages/student/BugHunterGame';
import { MemoryGame } from './pages/student/MemoryGame';
import { FormulaRacingGame } from './pages/student/FormulaRacingGame';
import { InteractiveVideoPage } from './pages/student/InteractiveVideoPage';
import { LearningLoopPage } from './pages/student/LearningLoopPage';
import { ResearchKHKTPage } from './pages/student/ResearchKHKTPage';
import { FourTiersPage } from './pages/student/FourTiersPage';
import { StudentEvidencePortfolio } from './pages/student/StudentEvidencePortfolio';
import { FormulaDoctorPage } from './pages/student/FormulaDoctorPage';
import { AssessmentPage } from './pages/student/AssessmentPage';
import { AdaptivePracticePage } from './pages/student/AdaptivePracticePage';
import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { StudentManagement } from './pages/teacher/StudentManagement';
import { QuestionBank } from './pages/teacher/QuestionBank';
import { AssignmentManager } from './pages/teacher/AssignmentManager';
import { PedagogicalEvidenceCenter } from './pages/teacher/PedagogicalEvidenceCenter';

function App() {
  const { user, isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const sUrl = params.get('supabase_url');
      const sKey = params.get('supabase_key');
      if (sUrl && sKey) {
        saveSupabaseConfig(sUrl, sKey);
        flushOfflineQueue().catch(() => {});
      }
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={
          isAuthenticated ? (
            <Navigate to={user?.role === 'teacher' ? '/teacher' : '/student'} replace />
          ) : (
            <LoginPage />
          )
        } />
        
        {/* Student Routes */}
        <Route path="/student" element={
          isAuthenticated && user?.role === 'student' ? <StudentLayout /> : <Navigate to="/login" replace />
        }>
          <Route index element={<StudentDashboard />} />
          <Route path="doctor" element={<FormulaDoctorPage />} />
          <Route path="assessment" element={<AssessmentPage />} />
          <Route path="adaptive" element={<AdaptivePracticePage />} />
          <Route path="lesson" element={<LessonPage />} />
          <Route path="video" element={<InteractiveVideoPage />} />
          <Route path="game" element={<GameLobby />} />
          <Route path="quiz" element={<QuizPage />} />
          <Route path="spreadsheet" element={<SpreadsheetPractice />} />
          <Route path="match-game" element={<MatchGame />} />
          <Route path="bug-hunter" element={<BugHunterGame />} />
          <Route path="memory-game" element={<MemoryGame />} />
          <Route path="formula-racing" element={<FormulaRacingGame />} />
          <Route path="leaderboard" element={<LeaderboardPage />} />
          <Route path="tiers" element={<FourTiersPage />} />
          <Route path="portfolio" element={<StudentEvidencePortfolio />} />
          <Route path="loop" element={<LearningLoopPage />} />
          <Route path="khkt" element={<ResearchKHKTPage />} />
        </Route>

        {/* Teacher Routes */}
        <Route path="/teacher" element={
          isAuthenticated && user?.role === 'teacher' ? <TeacherLayout /> : <Navigate to="/login" replace />
        }>
          <Route index element={<TeacherDashboard />} />
          <Route path="evidence" element={<PedagogicalEvidenceCenter />} />
          <Route path="students" element={<StudentManagement />} />
          <Route path="questions" element={<QuestionBank />} />
          <Route path="assignments" element={<AssignmentManager />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
