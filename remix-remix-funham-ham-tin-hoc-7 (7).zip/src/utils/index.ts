import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Utility to calculate level based on XP
export function calculateLevel(xp: number): number {
  if (xp < 100) return 1;
  if (xp < 250) return 2;
  if (xp < 450) return 3;
  if (xp < 700) return 4;
  if (xp < 1000) return 5;
  if (xp < 1400) return 6;
  if (xp < 1900) return 7;
  if (xp < 2500) return 8;
  if (xp < 3200) return 9;
  return 10;
}

export function getXpForNextLevel(level: number): number {
  const requirements = [0, 100, 250, 450, 700, 1000, 1400, 1900, 2500, 3200, 99999];
  return requirements[level] || requirements[10];
}

export function getLevelName(level: number): string {
  const names = [
    "Người mới", "Người khám phá", "Người luyện tập", 
    "Người hiểu bài", "Chiến binh Tin học", "Cao thủ bảng tính",
    "Bậc thầy công thức", "Chuyên gia hàm", "Siêu cao thủ", "MASTER TIN HỌC"
  ];
  return names[level - 1] || "Huyền thoại";
}
