/**
 * FUNHAM AI V2.0 - Formula Syntax & Semantic Parser
 * Chuyên gia phân tích cú pháp và ngữ nghĩa công thức bảng tính môn Tin học 7
 * Chuẩn Chương trình GDPT 2018 - SGK Kết nối tri thức với cuộc sống
 */

export type ErrorCode = 
  | 'E01' // Thiếu dấu bằng đầu công thức
  | 'E02' // Sai tên hàm
  | 'E03' // Thiếu hoặc thừa dấu ngoặc
  | 'E04' // Sai cách viết vùng dữ liệu
  | 'E05' // Sai dấu phân cách đối số
  | 'E06' // Chọn hàm không phù hợp yêu cầu bài toán
  | 'E07' // Chọn sai ô hoặc vùng dữ liệu
  | 'E08' // Nhầm lẫn công dụng của SUM, AVERAGE, MAX, MIN
  | 'E09' // Hiểu sai kết quả tính toán
  | 'E10'; // Lỗi khác cần giáo viên xem xét

export interface ErrorDefinition {
  code: ErrorCode;
  title: string;
  category: 'Cú pháp' | 'Ngữ nghĩa' | 'Lựa chọn hàm' | 'Tham chiếu';
  description: string;
  sgkReference: string;
}

export const ERROR_DEFINITIONS: Record<ErrorCode, ErrorDefinition> = {
  E01: {
    code: 'E01',
    title: 'Thiếu dấu bằng (=) ở đầu công thức',
    category: 'Cú pháp',
    description: 'Trong phần mềm bảng tính, mọi công thức hay hàm bắt buộc phải bắt đầu bằng dấu "=" để phần mềm nhận biết đó là phép tính.',
    sgkReference: 'SGK Tin 7 - Bài 8: Bắt đầu nhập công thức với dấu "="'
  },
  E02: {
    code: 'E02',
    title: 'Sai tên hàm (Lỗi chính tả hoặc tên không tồn tại)',
    category: 'Cú pháp',
    description: 'Tên hàm bị viết sai chính tả (ví dụ SUMM, AVERGE, TONG, TRUNGBINH) hoặc phần mềm không hỗ trợ tên hàm này.',
    sgkReference: 'SGK Tin 7 - Tên các hàm chuẩn: SUM, AVERAGE, MAX, MIN, COUNT'
  },
  E03: {
    code: 'E03',
    title: 'Thiếu hoặc thừa dấu ngoặc đơn ()',
    category: 'Cú pháp',
    description: 'Danh sách đối số của hàm phải nằm trong cặp ngoặc đơn tròn ( ), số ngoặc mở phải bằng số ngoặc đóng.',
    sgkReference: 'SGK Tin 7 - Cú pháp hàm: =TÊN_HÀM(đối số 1, đối số 2,...)'
  },
  E04: {
    code: 'E04',
    title: 'Sai cách viết vùng dữ liệu (Dùng sai ký tự ngăn cách)',
    category: 'Cú pháp',
    description: 'Vùng dữ liệu liên tục được viết bằng dấu hai chấm (:) giữa ô đầu và ô cuối, ví dụ: A1:A10. Không dùng dấu gạch ngang (-) hoặc khoảng trắng.',
    sgkReference: 'SGK Tin 7 - Vùng dữ liệu dạng: Ô_đầu:Ô_cuối (VD: B2:B9)'
  },
  E05: {
    code: 'E05',
    title: 'Sai dấu phân cách đối số',
    category: 'Cú pháp',
    description: 'Các đối số riêng lẻ được phân tách bằng dấu phẩy (,) hoặc chấm phẩy (;) tùy theo thiết lập hệ thống.',
    sgkReference: 'SGK Tin 7 - Phân tách các đối số bằng dấu phẩy hoặc chấm phẩy'
  },
  E06: {
    code: 'E06',
    title: 'Chọn hàm không phù hợp với yêu cầu bài toán',
    category: 'Lựa chọn hàm',
    description: 'Yêu cầu tính trung bình lại chọn hàm SUM, hoặc yêu cầu tìm giá trị lớn nhất lại chọn hàm MIN.',
    sgkReference: 'SGK Tin 7 - SUM: Tính tổng; AVERAGE: Trung bình cộng; MAX: Lớn nhất; MIN: Nhỏ nhất'
  },
  E07: {
    code: 'E07',
    title: 'Chọn sai ô hoặc vùng dữ liệu',
    category: 'Tham chiếu',
    description: 'Công thức tham chiếu nhầm cột (ví dụ cột Điểm mà chọn cột Họ tên), hoặc quét thiếu ô (B2:B7 thay vì B2:B8).',
    sgkReference: 'SGK Tin 7 - Xác định đúng địa chỉ cột và hàng chứa dữ liệu cần tính'
  },
  E08: {
    code: 'E08',
    title: 'Nhầm lẫn công dụng giữa các hàm (SUM, AVERAGE, MAX, MIN)',
    category: 'Ngữ nghĩa',
    description: 'Chưa phân biệt rõ giữa Tổng (cộng lại) và Trung bình cộng (cộng lại chia đều cho số lượng phần tử).',
    sgkReference: 'SGK Tin 7 - Ý nghĩa toán học của từng hàm trong thực tiễn'
  },
  E09: {
    code: 'E09',
    title: 'Hiểu sai kết quả tính toán hoặc bảng dữ liệu',
    category: 'Ngữ nghĩa',
    description: 'Kết quả tính toán hiển thị đúng nhưng học sinh diễn giải sai ý nghĩa kết quả hoặc đơn vị tính.',
    sgkReference: 'SGK Tin 7 - Đọc và giải thích ý nghĩa của giá trị trả về'
  },
  E10: {
    code: 'E10',
    title: 'Lỗi cấu trúc hoặc cần giáo viên xem xét',
    category: 'Cú pháp',
    description: 'Công thức chứa các ký tự lạ, lồng ghép sai quy tắc hoặc trường hợp đặc biệt cần giáo viên hỗ trợ.',
    sgkReference: 'SGK Tin 7 - Cú pháp chuẩn của bảng tính'
  }
};

export interface TaskContext {
  id?: string;
  title: string;
  requirement: string;
  expectedFunction: 'SUM' | 'AVERAGE' | 'MAX' | 'MIN' | 'COUNT';
  expectedRange: string; // e.g. "B2:B6" or alternative format
  gridData: {
    headers: string[];
    rows: (string | number)[][];
    numericColumns?: number[]; // index of columns with numbers
  };
}

export interface DiagnosticResult {
  isCorrect: boolean;
  errorCode?: ErrorCode;
  errorTitle?: string;
  category?: string;
  detectedFunction?: string;
  detectedRange?: string;
  calculatedValue?: number | string | null;
  tier1Hint: string; // Gợi mở (Câu hỏi tự vấn)
  tier2Hint: string; // Định hướng (Chỉ rõ thành phần cần xem)
  tier3Hint: string; // Giải thích (Hướng dẫn từng bước + ví dụ)
  suggestedFix?: string;
  ruleBased: boolean; // true if deterministic
}

/**
 * Tính toán kết quả thực tế từ chuỗi công thức trên dữ liệu bảng
 */
export function evaluateFormulaOnGrid(formula: string, grid: TaskContext['gridData']): number | string | null {
  try {
    const clean = formula.trim().toUpperCase();
    if (!clean.startsWith('=')) return null;

    const match = clean.match(/^=([A-Z]+)\((.+)\)$/);
    if (!match) return null;

    const func = match[1];
    const argsStr = match[2];

    // Trích xuất các số từ dải ô hoặc danh sách đối số
    const numbers: number[] = [];

    // Parse range như B2:B6
    const rangeMatch = argsStr.match(/([A-Z])([0-9]+):([A-Z])([0-9]+)/);
    if (rangeMatch) {
      const colStartChar = rangeMatch[1];
      const rowStart = parseInt(rangeMatch[2], 10);
      const colEndChar = rangeMatch[3];
      const rowEnd = parseInt(rangeMatch[4], 10);

      const colStartIdx = colStartChar.charCodeAt(0) - 65; // A -> 0, B -> 1
      const colEndIdx = colEndChar.charCodeAt(0) - 65;

      for (let r = rowStart; r <= rowEnd; r++) {
        // Dữ liệu hàng r tương ứng row index r - 2 nếu header ở hàng 1
        const rowDataIdx = r - 2;
        if (rowDataIdx >= 0 && rowDataIdx < grid.rows.length) {
          for (let c = colStartIdx; c <= colEndIdx; c++) {
            const val = grid.rows[rowDataIdx][c];
            const num = typeof val === 'number' ? val : parseFloat(String(val));
            if (!isNaN(num)) numbers.push(num);
          }
        }
      }
    } else {
      // Tách theo dấu phẩy hoặc chấm phẩy
      const parts = argsStr.split(/[,;]/);
      for (const p of parts) {
        const num = parseFloat(p.trim());
        if (!isNaN(num)) numbers.push(num);
      }
    }

    if (numbers.length === 0) return 0;

    switch (func) {
      case 'SUM':
        return numbers.reduce((a, b) => a + b, 0);
      case 'AVERAGE': {
        const sum = numbers.reduce((a, b) => a + b, 0);
        return Math.round((sum / numbers.length) * 10) / 10;
      }
      case 'MAX':
        return Math.max(...numbers);
      case 'MIN':
        return Math.min(...numbers);
      case 'COUNT':
        return numbers.length;
      default:
        return null;
    }
  } catch {
    return null;
  }
}

/**
 * Bộ kiểm tra cú pháp và ngữ nghĩa độc lập chuẩn SGK Tin 7
 */
export function diagnoseFormula(inputFormula: string, task: TaskContext): DiagnosticResult {
  const raw = (inputFormula || '').trim();
  const upper = raw.toUpperCase();

  // 1. Kiểm tra rỗng
  if (!raw) {
    return {
      isCorrect: false,
      errorCode: 'E01',
      errorTitle: ERROR_DEFINITIONS.E01.title,
      category: ERROR_DEFINITIONS.E01.category,
      tier1Hint: 'Em hãy nhớ lại: Mọi công thức tính toán trong bảng tính luôn bắt đầu bằng ký tự nào?',
      tier2Hint: 'Kiểm tra ký tự đầu tiên của ô tính. Cần có dấu bằng "=" ở trước tên hàm.',
      tier3Hint: 'Cú pháp chuẩn bắt buộc: =TÊN_HÀM(vùng dữ liệu). Ví dụ: =' + task.expectedFunction + '(' + task.expectedRange + ').',
      suggestedFix: `=${task.expectedFunction}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  // 2. E01: Thiếu dấu bằng đầu công thức
  if (!raw.startsWith('=')) {
    return {
      isCorrect: false,
      errorCode: 'E01',
      errorTitle: ERROR_DEFINITIONS.E01.title,
      category: ERROR_DEFINITIONS.E01.category,
      tier1Hint: 'Khi em gõ trực tiếp chữ cái vào ô tính mà không có dấu đặc biệt ở đầu, bảng tính sẽ coi đó là văn bản hay công thức?',
      tier2Hint: 'Công thức của em đang thiếu dấu "=" ở vị trí đầu tiên. Hãy thêm dấu "=" trước tên hàm.',
      tier3Hint: `Để máy tính thực hiện tính toán thay vì hiển thị chữ, em phải viết: =${raw}. Thử thêm dấu "=" vào đầu nhé!`,
      suggestedFix: `=${raw}`,
      ruleBased: true
    };
  }

  const withoutEqual = upper.slice(1).trim();

  // 3. E03: Kiểm tra dấu ngoặc
  const openParens = (withoutEqual.match(/\(/g) || []).length;
  const closeParens = (withoutEqual.match(/\)/g) || []).length;
  if (openParens === 0) {
    return {
      isCorrect: false,
      errorCode: 'E03',
      errorTitle: 'Thiếu cặp dấu ngoặc đơn () chứa đối số',
      category: 'Cú pháp',
      tier1Hint: 'Sau khi viết tên hàm, làm sao để bảng tính biết hàm này áp dụng cho những ô nào?',
      tier2Hint: 'Các tham số hoặc vùng dữ liệu của hàm bắt buộc phải được đặt trong cặp ngoặc đơn tròn ( ).',
      tier3Hint: `Cú pháp đúng: =TÊN_HÀM(đối_số). Ví dụ: =${task.expectedFunction}(${task.expectedRange}). Hãy thêm cặp ngoặc ( ) quanh vùng dữ liệu.`,
      suggestedFix: `=${task.expectedFunction}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  if (openParens > closeParens) {
    return {
      isCorrect: false,
      errorCode: 'E03',
      errorTitle: 'Thiếu dấu ngoặc đóng ")" ở cuối hàm',
      category: 'Cú pháp',
      tier1Hint: 'Em hãy đếm xem số lượng dấu ngoặc mở "(" đã có đủ số dấu ngoặc đóng ")" tương ứng chưa?',
      tier2Hint: 'Công thức của em đã mở ngoặc "(" nhưng chưa có dấu ngoặc đóng ")" ở cuối cùng.',
      tier3Hint: `Mỗi dấu mở ngoặc cần một dấu đóng ngoặc tương ứng. Hãy thêm dấu ")" vào cuối công thức: ${raw})`,
      suggestedFix: `${raw})`,
      ruleBased: true
    };
  }

  if (closeParens > openParens) {
    return {
      isCorrect: false,
      errorCode: 'E03',
      errorTitle: 'Thừa dấu ngoặc đóng ")"',
      category: 'Cú pháp',
      tier1Hint: 'Em hãy quan sát kỹ phần cuối công thức xem có bị gõ dư dấu ngoặc nào không?',
      tier2Hint: 'Công thức có nhiều dấu ngoặc đóng ")" hơn dấu mở ngoặc "(". Hãy xóa bớt dấu ngoặc thừa.',
      tier3Hint: 'Một hàm đơn giản chỉ cần 1 dấu ngoặc mở và 1 dấu ngoặc đóng bao quanh vùng ô. Ví dụ: =SUM(B2:B8).',
      suggestedFix: `=${task.expectedFunction}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  // 4. E02: Trích xuất tên hàm và kiểm tra chính tả
  const funcMatch = withoutEqual.match(/^([A-Z0-9_]+)\s*\((.*)\)$/);
  if (!funcMatch) {
    // Có thể dùng ngoặc vuông [ ] hoặc ký tự lạ
    if (withoutEqual.includes('[') || withoutEqual.includes('{')) {
      return {
        isCorrect: false,
        errorCode: 'E03',
        errorTitle: 'Dùng sai loại dấu ngoặc (dùng ngoặc vuông hoặc nhọn)',
        category: 'Cú pháp',
        tier1Hint: 'Trong bảng tính, loại dấu ngoặc nào được dùng để chứa các đối số của hàm?',
        tier2Hint: 'Bảng tính chỉ chấp nhận dấu ngoặc đơn tròn ( ), không dùng ngoặc vuông [ ] hay ngoặc nhọn { }.',
        tier3Hint: 'Thay thế [ ] hoặc { } bằng dấu ngoặc tròn ( ). Ví dụ: =SUM(A1:A5) thay vì =SUM[A1:A5].',
        suggestedFix: `=${task.expectedFunction}(${task.expectedRange})`,
        ruleBased: true
      };
    }
  }

  const rawFuncName = funcMatch ? funcMatch[1] : withoutEqual.split('(')[0].trim();
  const rawArgs = funcMatch ? funcMatch[2].trim() : '';

  const STANDARD_FUNCS = ['SUM', 'AVERAGE', 'MAX', 'MIN', 'COUNT', 'COUNTA'];
  const COMMON_TYPOS: Record<string, string> = {
    'SUMM': 'SUM',
    'SUN': 'SUM',
    'TONG': 'SUM',
    'CONG': 'SUM',
    'AVERGE': 'AVERAGE',
    'AVARAGE': 'AVERAGE',
    'AVG': 'AVERAGE',
    'TRUNGBINH': 'AVERAGE',
    'TBC': 'AVERAGE',
    'MAXIMUM': 'MAX',
    'LONNHAT': 'MAX',
    'MINIMUM': 'MIN',
    'NHONHAT': 'MIN',
    'DEM': 'COUNT',
    'COUN': 'COUNT'
  };

  if (!STANDARD_FUNCS.includes(rawFuncName)) {
    const suggested = COMMON_TYPOS[rawFuncName] || task.expectedFunction;
    return {
      isCorrect: false,
      errorCode: 'E02',
      errorTitle: `Sai tên hàm "${rawFuncName}" (Không có trong chuẩn Tin học 7)`,
      category: 'Cú pháp',
      detectedFunction: rawFuncName,
      tier1Hint: 'Tên các hàm tính toán trong bảng tính thường là từ tiếng Anh viết tắt. Em hãy kiểm tra xem tên hàm này đã đúng chính tả tiếng Anh chưa?',
      tier2Hint: `Tên hàm "${rawFuncName}" không hợp lệ. Trong chương trình lớp 7, chúng ta học 5 hàm: SUM, AVERAGE, MAX, MIN, COUNT.`,
      tier3Hint: `Nếu em muốn tính, hãy dùng tên hàm chuẩn: ${suggested}. Viết hoa hay viết thường đều được (phần mềm tự chuẩn hóa), ví dụ: =${suggested}(${task.expectedRange}).`,
      suggestedFix: `=${suggested}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  // 5. E06 & E08: Kiểm tra tính phù hợp của hàm với yêu cầu bài toán
  if (rawFuncName !== task.expectedFunction) {
    const isSumAvgMix = (rawFuncName === 'SUM' && task.expectedFunction === 'AVERAGE') ||
                        (rawFuncName === 'AVERAGE' && task.expectedFunction === 'SUM');
    const isMaxMinMix = (rawFuncName === 'MAX' && task.expectedFunction === 'MIN') ||
                        (rawFuncName === 'MIN' && task.expectedFunction === 'MAX');

    return {
      isCorrect: false,
      errorCode: isSumAvgMix || isMaxMinMix ? 'E08' : 'E06',
      errorTitle: isSumAvgMix || isMaxMinMix 
        ? `Nhầm lẫn công dụng giữa hàm ${rawFuncName} và ${task.expectedFunction}`
        : `Chọn hàm ${rawFuncName} không phù hợp với yêu cầu "${task.requirement}"`,
      category: 'Lựa chọn hàm',
      detectedFunction: rawFuncName,
      tier1Hint: `Em hãy đọc kỹ yêu cầu bài toán: "${task.requirement}". Hàm ${rawFuncName} có tác dụng gì? Nó có khớp với mục tiêu tính toán này không?`,
      tier2Hint: `Yêu cầu cần ${task.requirement.toLowerCase()}. Hàm ${rawFuncName} dùng để ${getFunctionPurpose(rawFuncName)}, trong khi hàm ${task.expectedFunction} mới dùng để ${getFunctionPurpose(task.expectedFunction)}.`,
      tier3Hint: `Hãy thay tên hàm "${rawFuncName}" thành "${task.expectedFunction}". Cú pháp gợi ý: =${task.expectedFunction}(${task.expectedRange}).`,
      suggestedFix: `=${task.expectedFunction}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  // 6. E04 & E05: Kiểm tra cú pháp vùng dữ liệu và dấu ngăn cách
  if (rawArgs.includes('-')) {
    return {
      isCorrect: false,
      errorCode: 'E04',
      errorTitle: 'Sai ký tự phân cách vùng: Dùng dấu gạch ngang (-) thay vì hai chấm (:)',
      category: 'Cú pháp',
      tier1Hint: 'Trong toán học chúng ta hay viết từ A đến B là A-B, nhưng trong bảng tính, dấu nào được dùng để biểu diễn một khối (vùng) ô?',
      tier2Hint: 'Bảng tính dùng dấu hai chấm ":" giữa ô đầu và ô cuối để chỉ định một vùng. Dấu gạch ngang "-" sẽ bị hiểu là phép trừ.',
      tier3Hint: `Hãy sửa dấu "-" thành dấu ":". Ví dụ sửa "${rawArgs}" thành "${rawArgs.replace(/-/g, ':')}". Công thức hoàn chỉnh: =${rawFuncName}(${task.expectedRange}).`,
      suggestedFix: `=${rawFuncName}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  if (rawArgs.includes(' ') && !rawArgs.includes(':') && !rawArgs.includes(',') && !rawArgs.includes(';')) {
    return {
      isCorrect: false,
      errorCode: 'E04',
      errorTitle: 'Sai cách viết vùng dữ liệu: Dùng khoảng trắng phân cách các ô',
      category: 'Cú pháp',
      tier1Hint: 'Giữa ô đầu và ô cuối của một vùng cần có ký hiệu đặc biệt nào để phần mềm hiểu là một dải liên tục?',
      tier2Hint: 'Khoảng trắng không biểu thị vùng ô trong Excel/Sheets lớp 7. Em cần dùng dấu hai chấm ":".',
      tier3Hint: `Hãy viết ô đầu và ô cuối nối nhau bằng dấu hai chấm, ví dụ: ${task.expectedRange}. Không dùng dấu cách.`,
      suggestedFix: `=${rawFuncName}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  if (rawArgs.includes('..')) {
    return {
      isCorrect: false,
      errorCode: 'E04',
      errorTitle: 'Dùng hai dấu chấm (..) thay vì dấu hai chấm (:)',
      category: 'Cú pháp',
      tier1Hint: 'Kiểm tra ký tự nối giữa hai địa chỉ ô trong ngoặc đơn.',
      tier2Hint: 'Phần mềm bảng tính chỉ dùng duy nhất 1 dấu hai chấm ":" chứ không dùng dấu hai chấm nằm ngang "..".',
      tier3Hint: `Sửa ".." thành ":". Ví dụ: =${rawFuncName}(${task.expectedRange}).`,
      suggestedFix: `=${rawFuncName}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  // 7. E07: Kiểm tra địa chỉ ô hoặc vùng dữ liệu có đúng yêu cầu không
  const normalizedExpected = task.expectedRange.toUpperCase().replace(/\s+/g, '');
  const normalizedActual = rawArgs.toUpperCase().replace(/\s+/g, '');

  if (normalizedActual !== normalizedExpected) {
    // Phân tích xem lệch cột hay lệch hàng
    const actualRangeMatch = normalizedActual.match(/^([A-Z])([0-9]+):([A-Z])([0-9]+)$/);
    const expectedRangeMatch = normalizedExpected.match(/^([A-Z])([0-9]+):([A-Z])([0-9]+)$/);

    let specificGuide = `Vùng dữ liệu em chọn là "${rawArgs}", chưa chính xác với bảng số liệu yêu cầu (${task.expectedRange}).`;
    if (actualRangeMatch && expectedRangeMatch) {
      if (actualRangeMatch[1] !== expectedRangeMatch[1]) {
        specificGuide = `Em đang tham chiếu nhầm sang cột ${actualRangeMatch[1]}. Cột số liệu cần tính là cột ${expectedRangeMatch[1]}.`;
      } else if (actualRangeMatch[2] !== expectedRangeMatch[2] || actualRangeMatch[4] !== expectedRangeMatch[4]) {
        specificGuide = `Em đã chọn đúng cột ${actualRangeMatch[1]} nhưng chọn thiếu hoặc thừa hàng (đang chọn từ hàng ${actualRangeMatch[2]} đến ${actualRangeMatch[4]}, trong khi yêu cầu từ hàng ${expectedRangeMatch[2]} đến ${expectedRangeMatch[4]}).`;
      }
    }

    return {
      isCorrect: false,
      errorCode: 'E07',
      errorTitle: `Chọn sai vùng dữ liệu (Nhập "${rawArgs}" thay vì "${task.expectedRange}")`,
      category: 'Tham chiếu',
      detectedFunction: rawFuncName,
      detectedRange: rawArgs,
      tier1Hint: `Em hãy nhìn lại bảng dữ liệu: Cột nào và những dòng nào chứa các con số cần ${task.requirement.toLowerCase()}?`,
      tier2Hint: specificGuide,
      tier3Hint: `Hãy kiểm tra địa chỉ ô đầu tiên chứa số liệu và ô cuối cùng, nối với nhau bằng dấu hai chấm. Đáp án chuẩn là: =${rawFuncName}(${task.expectedRange}).`,
      suggestedFix: `=${rawFuncName}(${task.expectedRange})`,
      ruleBased: true
    };
  }

  // 8. ĐÚNG HOÀN TOÀN
  const val = evaluateFormulaOnGrid(raw, task.gridData);
  return {
    isCorrect: true,
    detectedFunction: rawFuncName,
    detectedRange: rawArgs,
    calculatedValue: val,
    tier1Hint: 'Chúc mừng em! Công thức hoàn toàn chính xác theo chuẩn SGK Tin học 7.',
    tier2Hint: `Công thức =${rawFuncName}(${rawArgs}) đã tính ra kết quả: ${val}. Em có thể giải thích ý nghĩa con số này với cả lớp được không?`,
    tier3Hint: `Kết quả tính toán: ${val}. Hàm ${rawFuncName} đã thực hiện đúng ${task.requirement.toLowerCase()}.`,
    ruleBased: true
  };
}

function getFunctionPurpose(funcName: string): string {
  switch (funcName) {
    case 'SUM': return 'tính tổng tất cả các số trong vùng dữ liệu';
    case 'AVERAGE': return 'tính trung bình cộng các số trong vùng dữ liệu';
    case 'MAX': return 'tìm giá trị lớn nhất trong vùng dữ liệu';
    case 'MIN': return 'tìm giá trị nhỏ nhất trong vùng dữ liệu';
    case 'COUNT': return 'đếm số lượng ô có chứa dữ liệu số';
    default: return 'thực hiện phép tính';
  }
}
