export interface Tier1Question {
  id: string;
  topic: 'SUM' | 'AVERAGE' | 'MAX' | 'MIN' | 'COUNT';
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

export interface Tier2Question {
  id: string;
  topic: 'SUM' | 'AVERAGE' | 'MAX' | 'MIN' | 'COUNT';
  situation: string;
  question: string;
  options: string[];
  correctAnswer: string;
  syntaxRule: string;
  explanation: string;
}

export interface TableRowData {
  name: string;
  math: number;
  literature: number;
  it: number;
}

export interface Tier3Question {
  id: string;
  title: string;
  description: string;
  tableData: TableRowData[];
  targetPrompt: string;
  targetCell: string;
  expectedResult: number;
  acceptedFormulas: string[];
  options?: string[];
  explanation: string;
}

export interface Tier4BugQuestion {
  id: string;
  topic: 'SUM' | 'AVERAGE' | 'MAX' | 'MIN' | 'COUNT';
  buggyFormula: string;
  isCorrect: boolean;
  bugType: string;
  bugDescription: string;
  correctFormula: string;
  fixOptions: string[];
  pedagogicalTip: string;
}

// =================== TẦNG 1: NHẬN BIẾT ===================
export const TIER_1_QUESTIONS: Tier1Question[] = [
  {
    id: 't1_1',
    topic: 'SUM',
    question: 'Hàm SUM dùng để làm gì?',
    options: [
      'A. Tính tổng',
      'B. Tính trung bình',
      'C. Tìm giá trị lớn nhất',
      'D. Tìm giá trị nhỏ nhất'
    ],
    correctAnswer: 'A. Tính tổng',
    explanation: 'Hàm SUM (Summation) có chức năng tính tổng tất cả các giá trị số trong danh sách hoặc khối ô được chọn.'
  },
  {
    id: 't1_2',
    topic: 'AVERAGE',
    question: 'Hàm AVERAGE dùng để làm gì?',
    options: [
      'A. Đếm số lượng ô',
      'B. Tính trung bình cộng',
      'C. Tìm số lớn nhất',
      'D. Tính tổng các ô'
    ],
    correctAnswer: 'B. Tính trung bình cộng',
    explanation: 'Hàm AVERAGE tính trung bình cộng bằng cách lấy tổng các giá trị chia cho số lượng ô chứa số.'
  },
  {
    id: 't1_3',
    topic: 'MAX',
    question: 'Hàm MAX dùng để làm gì trong bảng tính?',
    options: [
      'A. Tìm giá trị lớn nhất',
      'B. Tìm giá trị nhỏ nhất',
      'C. Tính tổng số ô',
      'D. Đếm ô có chữ'
    ],
    correctAnswer: 'A. Tìm giá trị lớn nhất',
    explanation: 'Hàm MAX (Maximum) trả về số có giá trị lớn nhất trong tập hợp các số được chọn.'
  },
  {
    id: 't1_4',
    topic: 'MIN',
    question: 'Hàm MIN dùng để làm gì trong bảng tính?',
    options: [
      'A. Tìm giá trị lớn nhất',
      'B. Tìm giá trị nhỏ nhất',
      'C. Nhân các số với nhau',
      'D. Chia trung bình'
    ],
    correctAnswer: 'B. Tìm giá trị nhỏ nhất',
    explanation: 'Hàm MIN (Minimum) trả về số có giá trị nhỏ nhất trong tập hợp các số được chọn.'
  },
  {
    id: 't1_5',
    topic: 'COUNT',
    question: 'Hàm COUNT dùng để làm gì?',
    options: [
      'A. Đếm các ô chứa dữ liệu số',
      'B. Đếm tất cả các ô trống',
      'C. Tính tổng các ô',
      'D. Đổi chữ hoa thành chữ thường'
    ],
    correctAnswer: 'A. Đếm các ô chứa dữ liệu số',
    explanation: 'Hàm COUNT đếm số lượng các ô chứa dữ liệu kiểu số trong danh sách tham số.'
  }
];

// =================== TẦNG 2: HIỂU (THÔNG HIỂU CÚ PHÁP) ===================
export const TIER_2_QUESTIONS: Tier2Question[] = [
  {
    id: 't2_1',
    topic: 'SUM',
    situation: 'Cần tính tổng giá trị các ô liên tục từ ô B2 đến ô B8.',
    question: 'Công thức nào tính tổng từ B2 đến B8 đúng chuẩn cú pháp?',
    options: [
      '=SUM(B2:B8)',
      '=SUM(B2-B8)',
      'SUM(B2:B8)',
      '=SUM(B2..B8)'
    ],
    correctAnswer: '=SUM(B2:B8)',
    syntaxRule: 'Bắt đầu bằng dấu = -> tên hàm SUM -> cặp ngoặc tròn () -> địa chỉ khối ô với dấu hai chấm (B2:B8).',
    explanation: 'Học sinh phải hiểu: Để chỉ một khối ô liền nhau từ B2 đến B8, bảng tính dùng dấu hai chấm ":". Mọi hàm phải có dấu "=" đứng đầu.'
  },
  {
    id: 't2_2',
    topic: 'AVERAGE',
    situation: 'Cần tính điểm trung bình của 3 môn nằm ở 3 ô rời rạc: Toán (B3), Văn (D3), Tin (F3).',
    question: 'Cách viết hàm AVERAGE nào sau đây là đúng khi các ô không nằm liền kề nhau?',
    options: [
      '=AVERAGE(B3, D3, F3)',
      '=AVERAGE(B3:D3:F3)',
      '=AVERAGE(B3-D3-F3)',
      '=AVERAGE(B3..F3)'
    ],
    correctAnswer: '=AVERAGE(B3, D3, F3)',
    syntaxRule: 'Các ô rời rạc được phân cách bằng dấu phẩy "," (hoặc dấu chấm phẩy ";").',
    explanation: 'Học sinh phải hiểu: Khi các ô không liền nhau, ta dùng dấu phẩy "," để ngăn cách từng đối số.'
  },
  {
    id: 't2_3',
    topic: 'MAX',
    situation: 'Muốn tìm giá trị lớn nhất trong toàn bộ bảng số liệu từ ô A1 đến ô C10.',
    question: 'Công thức đúng để tìm giá trị lớn nhất của vùng chữ nhật từ A1 đến C10 là:',
    options: [
      '=MAX(A1:C10)',
      '=MAX(A1, C10)',
      '=MAX(A1-C10)',
      '=MAX[A1:C10]'
    ],
    correctAnswer: '=MAX(A1:C10)',
    syntaxRule: 'Địa chỉ khối hình chữ nhật được xác định bằng [Ô góc trên bên trái] : [Ô góc dưới bên phải].',
    explanation: 'Học sinh phải hiểu: Khối từ A1 đến C10 bao gồm tất cả các ô thuộc các cột A, B, C từ hàng 1 đến hàng 10, biểu diễn là A1:C10.'
  },
  {
    id: 't2_4',
    topic: 'COUNT',
    situation: 'Trong vùng từ E2 đến E20 có một số ô chứa số, một số ô chứa chữ và một số ô để trống.',
    question: 'Khi thực hiện công thức =COUNT(E2:E20), hàm COUNT sẽ xử lý như thế nào?',
    options: [
      'Chỉ đếm các ô chứa số, bỏ qua ô chứa chữ và ô trống',
      'Đếm tất cả các ô có dữ liệu bất kể là chữ hay số',
      'Báo lỗi vì có ô chứa chữ',
      'Chỉ đếm các ô để trống'
    ],
    correctAnswer: 'Chỉ đếm các ô chứa số, bỏ qua ô chứa chữ và ô trống',
    syntaxRule: 'COUNT chỉ đếm giá trị số. Muốn đếm cả chữ phải dùng COUNTA.',
    explanation: 'Học sinh phải hiểu bản chất: Hàm COUNT thuần túy chỉ quét và đếm những ô có giá trị định dạng số.'
  }
];

// =================== TẦNG 3: VẬN DỤNG (BẢNG ĐIỂM THỰC TẾ) ===================
export const TIER_3_QUESTIONS: Tier3Question[] = [
  {
    id: 't3_1',
    title: 'Tính tổng điểm của bạn An',
    description: 'Quan sát bảng điểm học sinh lớp 7 dưới đây. Cột B là điểm Toán, cột C là điểm Văn, cột D là điểm Tin học.',
    tableData: [
      { name: 'An', math: 8, literature: 7, it: 9 },
      { name: 'Bình', math: 7, literature: 8, it: 8 },
      { name: 'Cúc', math: 9, literature: 9, it: 10 }
    ],
    targetPrompt: 'Yêu cầu: Sử dụng hàm phù hợp để tính TỔNG ĐIỂM 3 môn cho bạn An (tại ô E2).',
    targetCell: 'E2',
    expectedResult: 24, // 8 + 7 + 9
    acceptedFormulas: [
      '=SUM(B2:D2)',
      '=SUM(B2,C2,D2)',
      '=SUM(B2, C2, D2)'
    ],
    options: [
      '=SUM(B2:D2)',
      '=SUM(B2:B4)',
      '=AVERAGE(B2:D2)',
      '=SUM(B2+C2+D2)'
    ],
    explanation: 'Bạn An ở hàng 2. Điểm 3 môn của An nằm ở B2 (Toán 8), C2 (Văn 7), D2 (Tin 9). Do đó công thức tính tổng điểm chuẩn là =SUM(B2:D2), kết quả ra 24 điểm.'
  },
  {
    id: 't3_2',
    title: 'Tính điểm trung bình của bạn Bình',
    description: 'Bảng điểm lớp 7: Cần tính điểm trung bình cộng 3 môn Toán, Văn, Tin cho bạn Bình (ở hàng 3).',
    tableData: [
      { name: 'An', math: 8, literature: 7, it: 9 },
      { name: 'Bình', math: 7, literature: 8, it: 8 },
      { name: 'Cúc', math: 9, literature: 9, it: 10 }
    ],
    targetPrompt: 'Yêu cầu: Sử dụng hàm phù hợp để tính ĐIỂM TRUNG BÌNH cho bạn Bình (tại ô F3).',
    targetCell: 'F3',
    expectedResult: 7.67, // (7 + 8 + 8) / 3
    acceptedFormulas: [
      '=AVERAGE(B3:D3)',
      '=AVERAGE(B3,C3,D3)',
      '=AVERAGE(B3, C3, D3)'
    ],
    options: [
      '=AVERAGE(B3:D3)',
      '=AVERAGE(B2:B4)',
      '=SUM(B3:D3)',
      '=AVERAGE(C1:C3)'
    ],
    explanation: 'Bạn Bình ở hàng 3, các điểm môn học nằm liên tục từ cột B đến cột D (B3, C3, D3). Hàm phù hợp nhất để tính điểm trung bình là =AVERAGE(B3:D3).'
  },
  {
    id: 't3_3',
    title: 'Tìm điểm môn Tin học cao nhất lớp',
    description: 'Quan sát cột Tin học (cột D) từ bạn An đến bạn Cúc (hàng 2 đến hàng 4: D2:D4).',
    tableData: [
      { name: 'An', math: 8, literature: 7, it: 9 },
      { name: 'Bình', math: 7, literature: 8, it: 8 },
      { name: 'Cúc', math: 9, literature: 9, it: 10 }
    ],
    targetPrompt: 'Yêu cầu: Tìm bạn có điểm môn Tin học cao nhất hiển thị tại ô D5.',
    targetCell: 'D5',
    expectedResult: 10,
    acceptedFormulas: [
      '=MAX(D2:D4)',
      '=MAX(D2,D3,D4)',
      '=MAX(D2, D3, D4)'
    ],
    options: [
      '=MAX(D2:D4)',
      '=MAX(B2:D2)',
      '=MIN(D2:D4)',
      '=SUM(D2:D4)'
    ],
    explanation: 'Điểm Tin học của cả 3 bạn nằm ở cột D từ dòng 2 đến dòng 4 (D2:D4). Để tìm điểm cao nhất, công thức chuẩn là =MAX(D2:D4) cho kết quả là 10 (bạn Cúc).'
  }
];

// =================== TẦNG 4: PHÁT HIỆN VÀ SỬA LỖI (SƯ PHẠM) ===================
export const TIER_4_QUESTIONS: Tier4BugQuestion[] = [
  {
    id: 't4_1',
    topic: 'SUM',
    buggyFormula: '=SUM(B2-B8)',
    isCorrect: false,
    bugType: 'Lỗi ký hiệu khối dữ liệu',
    bugDescription: 'Học sinh dùng dấu trừ "-" thay vì dấu hai chấm ":" để biểu diễn khối ô.',
    correctFormula: '=SUM(B2:B8)',
    fixOptions: [
      '=SUM(B2:B8)',
      '=SUM(B2+B8)',
      '=SUM(B2*B8)',
      'SUM(B2:B8)'
    ],
    pedagogicalTip: 'Trong toán học, dấu "-" là phép trừ (B2 trừ B8). Nhưng trong bảng tính, để chỉ vùng từ ô B2 đến B8, ta bắt buộc phải dùng dấu hai chấm ":".'
  },
  {
    id: 't4_2',
    topic: 'SUM',
    buggyFormula: 'SUM(B2:B8)',
    isCorrect: false,
    bugType: 'Thiếu dấu bằng (=) đầu công thức',
    bugDescription: 'Gõ trực tiếp tên hàm mà quên dấu "=" khiến bảng tính hiểu nhầm là chữ (text).',
    correctFormula: '=SUM(B2:B8)',
    fixOptions: [
      '=SUM(B2:B8)',
      '+SUM(B2-B8)',
      ':SUM(B2:B8)',
      '=SUM[B2:B8]'
    ],
    pedagogicalTip: 'Bảng tính chỉ bắt đầu tính toán khi ký tự đầu tiên trong ô là dấu "=". Nếu thiếu, phần mềm sẽ hiển thị nguyên văn chuỗi chữ SUM(B2:B8).'
  },
  {
    id: 't4_3',
    topic: 'AVERAGE',
    buggyFormula: '=AVERGE(A1:A10)',
    isCorrect: false,
    bugType: 'Sai chính tả tên hàm (#NAME?)',
    bugDescription: 'Viết thiếu chữ "A" trong tên hàm AVERAGE (gõ thành AVERGE), gây lỗi #NAME?.',
    correctFormula: '=AVERAGE(A1:A10)',
    fixOptions: [
      '=AVERAGE(A1:A10)',
      '=AVARAGE(A1:A10)',
      '=TB(A1:A10)',
      '=AVERAGE[A1:A10]'
    ],
    pedagogicalTip: 'Tên hàm là từ khóa tiếng Anh cố định. Chỉ cần sai một chữ cái, phần mềm sẽ báo lỗi #NAME? vì không biết hàm đó là gì.'
  },
  {
    id: 't4_4',
    topic: 'MAX',
    buggyFormula: '=MAX(A1:A10',
    isCorrect: false,
    bugType: 'Lỗi cú pháp thiếu dấu ngoặc đóng ")"',
    bugDescription: 'Mở ngoặc đơn "(" nhưng quên đóng ngoặc đơn ")" ở cuối hàm.',
    correctFormula: '=MAX(A1:A10)',
    fixOptions: [
      '=MAX(A1:A10)',
      '=MAX(A1:A10];',
      '=MAX[A1:A10]',
      'MAX(A1:A10)'
    ],
    pedagogicalTip: 'Các dấu ngoặc đơn trong công thức luôn phải đi theo từng cặp: có mở ngoặc "(" thì bắt buộc phải có đóng ngoặc ")".'
  },
  {
    id: 't4_5',
    topic: 'SUM',
    buggyFormula: '=SUM(B2..B8)',
    isCorrect: false,
    bugType: 'Dùng hai dấu chấm ".." sai quy ước',
    bugDescription: 'Thói quen từ một số phần mềm cũ dùng hai dấu chấm thay cho dấu hai chấm (:).',
    correctFormula: '=SUM(B2:B8)',
    fixOptions: [
      '=SUM(B2:B8)',
      '=SUM(B2,B8)',
      '=SUM(B2;B8)',
      'SUM(B2:B8)'
    ],
    pedagogicalTip: 'Quy ước quốc tế của bảng tính Excel / Google Sheets chỉ chấp nhận dấu hai chấm (:) để thể hiện dải ô liên tục.'
  }
];
