import { CognitiveLevel, Question } from '../types';

export interface CognitiveLevelInfo {
  level: CognitiveLevel;
  name: string;
  shortDesc: string;
  badge: string;
  icon: string;
  color: string;
  border: string;
  bgLight: string;
  bgDark: string;
  textColor: string;
}

export const COGNITIVE_LEVELS: CognitiveLevelInfo[] = [
  {
    level: 1,
    name: 'Nhận biết hàm',
    shortDesc: 'Nhận diện tên hàm (SUM, AVERAGE, MAX, MIN, COUNT) và chức năng cơ bản.',
    badge: 'Mức 1: Nhận Biết',
    icon: '🔍',
    color: 'from-blue-500 to-cyan-500',
    border: 'border-blue-500',
    bgLight: 'bg-blue-50',
    bgDark: 'bg-blue-950/60',
    textColor: 'text-blue-600 dark:text-blue-300'
  },
  {
    level: 2,
    name: 'Nhận dạng cú pháp',
    shortDesc: 'Cú pháp chuẩn của hàm: Dấu =, tên hàm, cặp ngoặc (), dấu phẩy và hai chấm.',
    badge: 'Mức 2: Cú Pháp',
    icon: '📝',
    color: 'from-indigo-500 to-purple-500',
    border: 'border-indigo-500',
    bgLight: 'bg-indigo-50',
    bgDark: 'bg-indigo-950/60',
    textColor: 'text-indigo-600 dark:text-indigo-300'
  },
  {
    level: 3,
    name: 'Chọn hàm phù hợp',
    shortDesc: 'Lựa chọn đúng hàm (SUM, AVERAGE, MAX, MIN, COUNT) dựa theo tình huống bài toán.',
    badge: 'Mức 3: Chọn Hàm',
    icon: '🎯',
    color: 'from-amber-500 to-orange-500',
    border: 'border-amber-500',
    bgLight: 'bg-amber-50',
    bgDark: 'bg-amber-950/60',
    textColor: 'text-amber-600 dark:text-amber-300'
  },
  {
    level: 4,
    name: 'Phân tích công thức',
    shortDesc: 'Đọc hiểu công thức, tính nhẩm giá trị trả về và phân tích các ô tham chiếu.',
    badge: 'Mức 4: Phân Tích',
    icon: '🧠',
    color: 'from-purple-500 to-pink-500',
    border: 'border-purple-500',
    bgLight: 'bg-purple-50',
    bgDark: 'bg-purple-950/60',
    textColor: 'text-purple-600 dark:text-purple-300'
  },
  {
    level: 5,
    name: 'Phát hiện lỗi',
    shortDesc: 'Phát hiện và chỉ ra nguyên nhân gây lỗi cú pháp, sai tên hàm hoặc lỗi tính toán.',
    badge: 'Mức 5: Phát Hiện Lỗi',
    icon: '🕵️‍♂️',
    color: 'from-rose-500 to-red-600',
    border: 'border-rose-500',
    bgLight: 'bg-rose-50',
    bgDark: 'bg-rose-950/60',
    textColor: 'text-rose-600 dark:text-rose-300'
  },
  {
    level: 6,
    name: 'Vận dụng vào bảng tính thực tế',
    shortDesc: 'Lập công thức giải quyết bài toán thực tế (bảng điểm, kế hoạch chi tiêu, bán hàng).',
    badge: 'Mức 6: Vận Dụng Thực Tế',
    icon: '📊',
    color: 'from-emerald-500 to-teal-600',
    border: 'border-emerald-500',
    bgLight: 'bg-emerald-50',
    bgDark: 'bg-emerald-950/60',
    textColor: 'text-emerald-600 dark:text-emerald-300'
  }
];

export const COGNITIVE_QUESTIONS: Question[] = [
  // ================= MỨC 1: NHẬN BIẾT HÀM =================
  {
    id: 'cog_1_1',
    type: 'mcq',
    cognitiveLevel: 1,
    topic: 'SUM',
    content: 'Hàm nào trong bảng tính dùng để tính TỔNG các giá trị số trong một vùng dữ liệu?',
    options: ['=AVERAGE()', '=SUM()', '=COUNT()', '=MAX()'],
    answer: '=SUM()',
    explanation: 'Hàm SUM (viết tắt của Summation) là hàm tính tổng các giá trị trong bảng tính.',
    difficulty: 'nhan_biet',
    points: 10
  },
  {
    id: 'cog_1_2',
    type: 'mcq',
    cognitiveLevel: 1,
    topic: 'AVERAGE',
    content: 'Hàm AVERAGE trong phần mềm bảng tính có chức năng gì?',
    options: [
      'Tính trung bình cộng các giá trị số',
      'Tìm giá trị lớn nhất trong dãy',
      'Đếm tổng số ô có chứa chữ cái',
      'Nhân tất cả các số lại với nhau'
    ],
    answer: 'Tính trung bình cộng các giá trị số',
    explanation: 'Hàm AVERAGE tính trung bình cộng bằng cách cộng các giá trị số rồi chia cho số lượng ô chứa số.',
    difficulty: 'nhan_biet',
    points: 10
  },
  {
    id: 'cog_1_3',
    type: 'mcq',
    cognitiveLevel: 1,
    topic: 'MIN',
    content: 'Để tìm giá trị NHỎ NHẤT trong một danh sách các số, em sử dụng hàm nào?',
    options: ['=MIN()', '=MAX()', '=SMALL()', '=COUNT()'],
    answer: '=MIN()',
    explanation: 'Hàm MIN (Minimum) dùng để tìm giá trị nhỏ nhất trong một tập hợp các giá trị số.',
    difficulty: 'nhan_biet',
    points: 10
  },
  {
    id: 'cog_1_4',
    type: 'mcq',
    cognitiveLevel: 1,
    topic: 'COUNT',
    content: 'Hàm COUNT trong bảng tính dùng để làm gì?',
    options: [
      'Đếm các ô chứa dữ liệu số',
      'Đếm tất cả các ô có chứa chữ cái',
      'Tính tổng các ô được chọn',
      'Tìm giá trị xuất hiện nhiều lần nhất'
    ],
    answer: 'Đếm các ô chứa dữ liệu số',
    explanation: 'Hàm COUNT chỉ đếm những ô có chứa dữ liệu số, các ô chứa chữ hoặc ô trống sẽ bị bỏ qua.',
    difficulty: 'nhan_biet',
    points: 10
  },

  // ================= MỨC 2: NHẬN DẠNG CÚ PHÁP =================
  {
    id: 'cog_2_1',
    type: 'mcq',
    cognitiveLevel: 2,
    topic: 'SUM',
    content: 'Ký tự đầu tiên bắt buộc phải có khi gõ bất kỳ công thức hay hàm nào trong ô tính là:',
    options: ['Dấu cộng (+)', 'Dấu bằng (=)', 'Dấu nhân (*)', 'Dấu hai chấm (:)'],
    answer: 'Dấu bằng (=)',
    explanation: 'Trong Excel và bảng tính, mọi công thức hay hàm đều bắt buộc phải bắt đầu bằng dấu "=" để phần mềm hiểu đó là phép tính.',
    difficulty: 'nhan_biet',
    points: 10
  },
  {
    id: 'cog_2_2',
    type: 'mcq',
    cognitiveLevel: 2,
    topic: 'general',
    content: 'Ký hiệu nào được dùng để biểu diễn một KHỐI (vùng) ô liền kề, ví dụ từ ô A1 đến ô A10?',
    options: ['Dấu gạch nối (A1-A10)', 'Dấu hai chấm (A1:A10)', 'Dấu hai chấm phẩy (A1..A10)', 'Dấu mũi tên (A1->A10)'],
    answer: 'Dấu hai chấm (A1:A10)',
    explanation: 'Dấu hai chấm ":" dùng để xác định địa chỉ khối ô từ ô đầu góc trên bên trái đến ô cuối góc dưới bên phải.',
    difficulty: 'nhan_biet',
    points: 10
  },
  {
    id: 'cog_2_3',
    type: 'mcq',
    cognitiveLevel: 2,
    topic: 'AVERAGE',
    content: 'Cách viết cú pháp hàm AVERAGE nào sau đây là ĐÚNG CHUẨN?',
    options: [
      '=AVERAGE(A1:A5)',
      'AVERAGE = (A1:A5)',
      '=AVERAGE[A1:A5]',
      '=AVERAGE{A1:A5}'
    ],
    answer: '=AVERAGE(A1:A5)',
    explanation: 'Cú pháp chuẩn: =TÊNHÀM(danh_sách_tham_số). Tham số luôn phải nằm trong cặp ngoặc đơn tròn ().',
    difficulty: 'thong_hieu',
    points: 10
  },
  {
    id: 'cog_2_4',
    type: 'mcq',
    cognitiveLevel: 2,
    topic: 'MAX',
    content: 'Khi truyền nhiều đối số rời rạc vào hàm, ví dụ tính giá trị lớn nhất của 3 ô A1, B3 và C5, ta ngăn cách chúng bằng dấu gì?',
    options: ['Dấu phẩy (,) hoặc chấm phẩy (;)', 'Dấu gạch chéo (/)', 'Dấu gạch dưới (_)', 'Dấu khoảng trắng (space)'],
    answer: 'Dấu phẩy (,) hoặc chấm phẩy (;)',
    explanation: 'Các tham số rời rạc trong hàm được phân tách bằng dấu phẩy "," (hoặc dấu chấm phẩy ";" tùy theo cài đặt ngôn ngữ máy tính).',
    difficulty: 'thong_hieu',
    points: 10
  },

  // ================= MỨC 3: CHỌN HÀM PHÙ HỢP =================
  {
    id: 'cog_3_1',
    type: 'mcq',
    cognitiveLevel: 3,
    topic: 'MAX',
    content: 'Trong bảng điểm tổng kết lớp 7A, để tìm bạn học sinh có "Điểm thi Tin học cao nhất", em sẽ dùng hàm nào?',
    options: ['=MAX()', '=MIN()', '=SUM()', '=AVERAGE()'],
    answer: '=MAX()',
    explanation: 'Tìm điểm số cao nhất trong danh sách là bài toán tìm giá trị cực đại, do đó cần dùng hàm MAX.',
    difficulty: 'thong_hieu',
    points: 15
  },
  {
    id: 'cog_3_2',
    type: 'mcq',
    cognitiveLevel: 3,
    topic: 'AVERAGE',
    content: 'Thầy giáo muốn tính "Điểm trung bình các môn học" cho từng bạn học sinh, hàm thích hợp nhất là:',
    options: ['=AVERAGE()', '=SUM()', '=COUNT()', '=MAX()'],
    answer: '=AVERAGE()',
    explanation: 'Hàm AVERAGE giúp tính trung bình cộng của các cột điểm môn học một cách nhanh chóng và chính xác.',
    difficulty: 'thong_hieu',
    points: 15
  },
  {
    id: 'cog_3_3',
    type: 'mcq',
    cognitiveLevel: 3,
    topic: 'COUNT',
    content: 'Cô thủ quỹ muốn kiểm tra xem trong danh sách có bao nhiêu bạn "Đã nộp tiền quỹ" (được ghi bằng số tiền cụ thể trong cột C), cô nên dùng hàm nào?',
    options: ['=COUNT(C3:C45)', '=SUM(C3:C45)', '=AVERAGE(C3:C45)', '=MIN(C3:C45)'],
    answer: '=COUNT(C3:C45)',
    explanation: 'Hàm COUNT đếm số lượng ô có nhập dữ liệu số (số tiền), giúp biết chính xác số bạn đã nộp tiền.',
    difficulty: 'thong_hieu',
    points: 15
  },
  {
    id: 'cog_3_4',
    type: 'mcq',
    cognitiveLevel: 3,
    topic: 'SUM',
    content: 'Để tính "Tổng số cây xanh" mà cả 4 tổ của lớp 7B đã trồng được trong đợt phát động kế hoạch nhỏ, em dùng hàm nào?',
    options: ['=SUM()', '=MAX()', '=COUNT()', '=AVERAGE()'],
    answer: '=SUM()',
    explanation: 'Tính tổng số lượng toàn bộ các tổ trồng được ta sử dụng hàm SUM.',
    difficulty: 'thong_hieu',
    points: 15
  },

  // ================= MỨC 4: PHÂN TÍCH CÔNG THỨC =================
  {
    id: 'cog_4_1',
    type: 'mcq',
    cognitiveLevel: 4,
    topic: 'AVERAGE',
    content: 'Cho các ô: A1 = 8, A2 = 6, A3 = 10. Khi nhập công thức =AVERAGE(A1:A3), kết quả hiển thị trên màn hình là:',
    options: ['8', '24', '7.5', '10'],
    answer: '8',
    explanation: 'Phân tích: Tổng các ô là (8 + 6 + 10) = 24. Số lượng ô là 3. Vậy trung bình cộng là 24 / 3 = 8.',
    difficulty: 'van_dung',
    points: 15
  },
  {
    id: 'cog_4_2',
    type: 'mcq',
    cognitiveLevel: 4,
    topic: 'SUM',
    content: 'Cho B1 = 5, B2 = 10, B3 = 15. Công thức =SUM(B1:B2, 20) sẽ cho kết quả là bao nhiêu?',
    options: ['35', '30', '50', '25'],
    answer: '35',
    explanation: 'Phân tích: B1:B2 gồm ô B1 (5) và B2 (10), tổng là 15. Cộng thêm đối số trực tiếp 20 => 15 + 20 = 35. (Lưu ý: B3 không nằm trong vùng B1:B2).',
    difficulty: 'van_dung',
    points: 15
  },
  {
    id: 'cog_4_3',
    type: 'mcq',
    cognitiveLevel: 4,
    topic: 'COUNT',
    content: 'Cho các ô: C1 = 12, C2 = "Lan", C3 = 18, C4 = 20. Khi nhập =COUNT(C1:C4), kết quả trả về là:',
    options: ['3', '4', '2', '50'],
    answer: '3',
    explanation: 'Phân tích: C1 (12), C3 (18), C4 (20) là 3 ô chứa số. Ô C2 chứa chuỗi ký tự chữ "Lan" nên bị hàm COUNT bỏ qua.',
    difficulty: 'van_dung',
    points: 15
  },
  {
    id: 'cog_4_4',
    type: 'mcq',
    cognitiveLevel: 4,
    topic: 'MAX',
    content: 'Cho bảng số liệu gồm 2 dòng và 2 cột: A1=4, B1=9, A2=7, B2=3. Công thức =MAX(A1:B2) trả về số nào?',
    options: ['9', '7', '4', '23'],
    answer: '9',
    explanation: 'Khối A1:B2 bao gồm cả 4 ô {4, 9, 7, 3}. Trong 4 số này, số lớn nhất là 9.',
    difficulty: 'van_dung',
    points: 15
  },

  // ================= MỨC 5: PHÁT HIỆN LỖI =================
  {
    id: 'cog_5_1',
    type: 'mcq',
    cognitiveLevel: 5,
    topic: 'SUM',
    content: 'Bạn An gõ vào ô tính công thức "=SUM(B2:B10" rồi nhấn Enter thì máy tính báo lỗi. Lỗi ở đây là gì?',
    options: [
      'Thiếu dấu ngoặc đơn đóng ")" ở cuối hàm',
      'Phải viết tên hàm bằng chữ thường "=sum"',
      'Không được dùng dấu hai chấm',
      'Thiếu dấu phẩy ở giữa'
    ],
    answer: 'Thiếu dấu ngoặc đơn đóng ")" ở cuối hàm',
    explanation: 'Phát hiện lỗi: Cặp ngoặc đơn mở và đóng phải luôn đi liền thành đôi. Công thức của An mở ngoặc "(" nhưng chưa đóng ngoặc ")".',
    difficulty: 'van_dung',
    points: 20
  },
  {
    id: 'cog_5_2',
    type: 'mcq',
    cognitiveLevel: 5,
    topic: 'general',
    content: 'Bạn Bình nhập công thức "SUM(A1:A5)" vào ô C1 nhưng sau khi nhấn Enter, ô C1 chỉ hiện nguyên chữ "SUM(A1:A5)" chứ không tính ra số. Nguyên nhân là:',
    options: [
      'Bình đã quên không gõ dấu bằng (=) ở đầu công thức',
      'Máy tính bị đơ không kịp xử lý',
      'Hàm SUM không hỗ trợ chữ in hoa',
      'Vùng A1:A5 không có dữ liệu'
    ],
    answer: 'Bình đã quên không gõ dấu bằng (=) ở đầu công thức',
    explanation: 'Khi thiếu dấu "=", bảng tính hiểu nội dung nhập vào chỉ là một chuỗi văn bản (text) thông thường chứ không phải công thức tính toán.',
    difficulty: 'van_dung',
    points: 20
  },
  {
    id: 'cog_5_3',
    type: 'mcq',
    cognitiveLevel: 5,
    topic: 'AVERAGE',
    content: 'Ô D2 xuất hiện thông báo lỗi "#NAME?". Lỗi này thường xuất hiện do nguyên nhân nào sau đây?',
    options: [
      'Gõ sai chính tả tên hàm (ví dụ: gõ =AVERGE thay vì =AVERAGE)',
      'Phép chia cho số 0',
      'Độ rộng cột quá hẹp không đủ hiển thị số',
      'Vùng dữ liệu có quá nhiều số'
    ],
    answer: 'Gõ sai chính tả tên hàm (ví dụ: gõ =AVERGE thay vì =AVERAGE)',
    explanation: 'Lỗi #NAME? xuất hiện khi phần mềm bảng tính không nhận diện được tên hàm hoặc tên vùng dữ liệu (thường do viết sai chính tả).',
    difficulty: 'van_dung',
    points: 20
  },
  {
    id: 'cog_5_4',
    type: 'mcq',
    cognitiveLevel: 5,
    topic: 'general',
    content: 'Một bạn học sinh viết công thức "=SUM(D1..D10)". Công thức này sai ở điểm nào?',
    options: [
      'Dùng hai dấu chấm ".." thay vì dấu hai chấm ":"',
      'Tên hàm SUM phải có khoảng trắng với dấu ngoặc',
      'Không được phép tính quá 5 ô',
      'Tên cột D phải viết thường là d'
    ],
    answer: 'Dùng hai dấu chấm ".." thay vì dấu hai chấm ":"',
    explanation: 'Trong quy ước bảng tính, ký hiệu phân cách địa chỉ đầu và cuối của một khối ô bắt buộc là dấu hai chấm (:), không phải dấu hai chấm (..).',
    difficulty: 'van_dung',
    points: 20
  },

  // ================= MỨC 6: VẬN DỤNG VÀO BẢNG TÍNH THỰC TẾ =================
  {
    id: 'cog_6_1',
    type: 'mcq',
    cognitiveLevel: 6,
    topic: 'AVERAGE',
    content: 'Bảng điểm lớp 7A có điểm Toán ở cột C (từ C3:C40), điểm Văn ở cột D (D3:D40), điểm Anh ở cột E (E3:E40). Để tính điểm trung bình cả 3 môn cho học sinh đầu tiên ở dòng 3, công thức tại ô F3 là:',
    options: [
      '=AVERAGE(C3:E3)',
      '=AVERAGE(C3:C40)',
      '=SUM(C3:E3)/2',
      '=AVERAGE(C3, D40, E3)'
    ],
    answer: '=AVERAGE(C3:E3)',
    explanation: 'Vận dụng thực tế: Điểm 3 môn của học sinh tại hàng 3 nằm liên tục từ cột C đến cột E (C3, D3, E3), do đó công thức đúng là =AVERAGE(C3:E3).',
    difficulty: 'van_dung_cao',
    points: 20
  },
  {
    id: 'cog_6_2',
    type: 'mcq',
    cognitiveLevel: 6,
    topic: 'SUM',
    content: 'Trong "Bảng theo dõi thu chi hội chợ kế hoạch nhỏ", cột C là "Đơn giá", cột D là "Số lượng". Để tính "Tổng số lượng tất cả các mặt hàng đã bán" từ dòng 4 đến dòng 18 tại ô D19, công thức cần điền là:',
    options: [
      '=SUM(D4:D18)',
      '=SUM(C4:D18)',
      '=AVERAGE(D4:D18)',
      '=COUNT(D4:D18)'
    ],
    answer: '=SUM(D4:D18)',
    explanation: 'Để tính tổng số lượng các mặt hàng đã bán, ta tính tổng của toàn bộ các ô trong cột Số lượng (từ D4 đến D18) bằng hàm =SUM(D4:D18).',
    difficulty: 'van_dung_cao',
    points: 20
  },
  {
    id: 'cog_6_3',
    type: 'mcq',
    cognitiveLevel: 6,
    topic: 'MIN',
    content: 'Một trạm khí tượng ghi nhận nhiệt độ các ngày trong tuần ở cột B (từ B2:B8). Để tìm "Ngày có nhiệt độ thấp nhất trong tuần" hiển thị ở ô B9, công thức chuẩn là:',
    options: [
      '=MIN(B2:B8)',
      '=MAX(B2:B8)',
      '=AVERAGE(B2:B8)',
      '=COUNT(B2:B8)'
    ],
    answer: '=MIN(B2:B8)',
    explanation: 'Để tìm nhiệt độ thấp nhất trong toàn bộ 7 ngày ghi nhận (B2:B8), ta áp dụng hàm tìm giá trị nhỏ nhất: =MIN(B2:B8).',
    difficulty: 'van_dung_cao',
    points: 20
  },
  {
    id: 'cog_6_4',
    type: 'mcq',
    cognitiveLevel: 6,
    topic: 'COUNT',
    content: 'Trong danh sách tiêm phòng vắc-xin cho học sinh khối 7 (hàng 2 đến 120), cột F ghi ngày tiêm chủng (nếu đã tiêm) hoặc để trống (nếu chưa tiêm). Công thức đếm "Số học sinh đã được tiêm chủng" ở ô F121 là:',
    options: [
      '=COUNT(F2:F120)',
      '=SUM(F2:F120)',
      '=MAX(F2:F120)',
      '=AVERAGE(F2:F120)'
    ],
    answer: '=COUNT(F2:F120)',
    explanation: 'Ngày tháng trong bảng tính được lưu dưới dạng số (serial number). Hàm COUNT(F2:F120) sẽ tự động đếm các ô có ghi ngày và bỏ qua các ô trống.',
    difficulty: 'van_dung_cao',
    points: 20
  }
];
