import { AssessmentQuestion } from '../types/evidence';

/**
 * BÀI KIỂM TRA ĐẦU VÀO (PRE-TEST) - 10 CÂU (THANG ĐIỂM 10)
 * Đo lường kiến thức ban đầu của học sinh về các hàm tính toán Tin học 7
 */
export const PRE_TEST_QUESTIONS: AssessmentQuestion[] = [
  {
    id: 'pre_01',
    type: 'multiple_choice',
    topic: 'SYNTAX',
    title: 'Câu 1: Ký tự bắt đầu công thức',
    prompt: 'Trong phần mềm bảng tính, ký tự nào bắt buộc phải đứng ở vị trí đầu tiên của một công thức hay hàm tính toán?',
    options: ['Dấu cộng (+)', 'Dấu bằng (=)', 'Dấu nhân (*)', 'Dấu chấm phẩy (;)'],
    correctAnswer: 'Dấu bằng (=)',
    explanation: 'Theo SGK Tin học 7, mọi công thức hoặc hàm tính toán đều bắt đầu bằng dấu "=" để phân biệt với dữ liệu văn bản.',
    errorCodeTested: 'E01'
  },
  {
    id: 'pre_02',
    type: 'function_select',
    topic: 'SUM',
    title: 'Câu 2: Chọn hàm tính tổng',
    prompt: 'Để tính tổng số điểm kiểm tra thường xuyên của bạn Lan trong các ô B2, C2, D2, hàm nào sau đây là đúng?',
    options: ['=TOTAL(B2:D2)', '=SUM(B2:D2)', '=AVERAGE(B2:D2)', '=COUNT(B2:D2)'],
    correctAnswer: '=SUM(B2:D2)',
    explanation: 'Hàm SUM dùng để tính tổng các số trong danh sách đối số hoặc khối ô.',
    errorCodeTested: 'E02'
  },
  {
    id: 'pre_03',
    type: 'bug_detect',
    topic: 'SYNTAX',
    title: 'Câu 3: Phát hiện lỗi công thức',
    prompt: 'Một học sinh gõ công thức: =SUM(A1-A10 để tính tổng từ ô A1 đến A10. Công thức này mắc những lỗi nào?',
    options: [
      'Sai dấu ngăn cách vùng (dùng "-" thay vì ":") và thiếu dấu ngoặc đóng ")"',
      'Chỉ thiếu dấu ngoặc đóng ")"',
      'Sai tên hàm SUM',
      'Không có lỗi nào cả'
    ],
    correctAnswer: 'Sai dấu ngăn cách vùng (dùng "-" thay vì ":") và thiếu dấu ngoặc đóng ")"',
    explanation: 'Vùng ô liên tục phải dùng dấu hai chấm (:) và phải có đủ cặp ngoặc tròn ( ).',
    errorCodeTested: 'E04'
  },
  {
    id: 'pre_04',
    type: 'function_select',
    topic: 'AVERAGE',
    title: 'Câu 4: Chọn hàm tính trung bình',
    prompt: 'Để tính nhiệt độ trung bình của tuần từ thứ Hai đến Chủ nhật (ô B3 đến B9), em sử dụng hàm nào?',
    options: ['=AVERAGE(B3:B9)', '=SUM(B3:B9)/7', '=AVG(B3:B9)', '=MEAN(B3:B9)'],
    correctAnswer: '=AVERAGE(B3:B9)',
    explanation: 'Hàm AVERAGE là hàm chuẩn trong SGK Tin học 7 để tính trung bình cộng.',
    errorCodeTested: 'E08'
  },
  {
    id: 'pre_05',
    type: 'multiple_choice',
    topic: 'MAX',
    title: 'Câu 5: Nhận biết hàm MAX',
    prompt: 'Hàm nào sau đây dùng để tìm giá trị lớn nhất trong một tập hợp dữ liệu số?',
    options: ['Hàm MIN', 'Hàm MAX', 'Hàm LARGE', 'Hàm SUM'],
    correctAnswer: 'Hàm MAX',
    explanation: 'Hàm MAX trả về giá trị lớn nhất trong các đối số hoặc vùng tham chiếu.',
    errorCodeTested: 'E06'
  },
  {
    id: 'pre_06',
    type: 'formula_input',
    topic: 'MIN',
    title: 'Câu 6: Viết công thức tìm điểm thấp nhất',
    prompt: 'Viết công thức chuẩn để tìm điểm số thấp nhất môn Toán của cả lớp trong vùng C2 đến C35.',
    correctAnswer: '=MIN(C2:C35)',
    explanation: 'Cú pháp chuẩn: =MIN(C2:C35). Tên hàm MIN, vùng ô viết cách nhau bằng dấu hai chấm (:).',
    errorCodeTested: 'E03'
  },
  {
    id: 'pre_07',
    type: 'result_explain',
    topic: 'AVERAGE',
    title: 'Câu 7: Giải thích kết quả hàm AVERAGE',
    prompt: 'Cho các ô A1 = 8, A2 = 6, A3 = 10. Giá trị của công thức =AVERAGE(A1:A3) là bao nhiêu?',
    options: ['24', '8', '6', '10'],
    correctAnswer: '8',
    explanation: 'Trung bình cộng = (8 + 6 + 10) / 3 = 24 / 3 = 8.',
    errorCodeTested: 'E09'
  },
  {
    id: 'pre_08',
    type: 'bug_detect',
    topic: 'SYNTAX',
    title: 'Câu 8: Soát lỗi cú pháp ngoặc',
    prompt: 'Công thức nào sau đây KHÔNG bị lỗi cú pháp trong phần mềm bảng tính?',
    options: [
      '=SUM[B2:B10]',
      'SUM(B2:B10)',
      '=SUM(B2:B10)',
      '=SUM(B2 B10)'
    ],
    correctAnswer: '=SUM(B2:B10)',
    explanation: 'Phải có dấu "=", tên hàm chuẩn SUM, cặp ngoặc tròn (), và dấu hai chấm : cho vùng ô.',
    errorCodeTested: 'E03'
  },
  {
    id: 'pre_09',
    type: 'function_select',
    topic: 'COUNT',
    title: 'Câu 9: Hàm đếm số ô chứa số',
    prompt: 'Để đếm số lượng học sinh đã nộp bài (những ô có nhập điểm số từ D2 đến D30), em dùng hàm nào?',
    options: ['=COUNT(D2:D30)', '=SUM(D2:D30)', '=NUMBER(D2:D30)', '=COUNTA(D2:D30)'],
    correctAnswer: '=COUNT(D2:D30)',
    explanation: 'Hàm COUNT đếm số lượng ô có chứa dữ liệu số trong danh sách đối số.',
    errorCodeTested: 'E06'
  },
  {
    id: 'pre_10',
    type: 'result_explain',
    topic: 'MAX',
    title: 'Câu 10: Vận dụng hàm MAX và MIN',
    prompt: 'Cho dãy số tại các ô B1=15, B2=42, B3=7, B4=29. Giá trị của công thức =MAX(B1:B4) - MIN(B1:B4) là bao nhiêu?',
    options: ['42', '7', '35', '49'],
    correctAnswer: '35',
    explanation: 'MAX(B1:B4) = 42, MIN(B1:B4) = 7. Hiệu là 42 - 7 = 35.',
    errorCodeTested: 'E09'
  }
];

/**
 * BÀI KIỂM TRA ĐẦU RA (POST-TEST) - 10 CÂU (THANG ĐIỂM 10)
 * Đo lường sự tiến bộ sau khi học sinh trải nghiệm FUNHAM AI V2.0
 * Có độ khó tương đương nhưng sử dụng ngữ cảnh và câu hỏi mới.
 */
export const POST_TEST_QUESTIONS: AssessmentQuestion[] = [
  {
    id: 'post_01',
    type: 'multiple_choice',
    topic: 'SYNTAX',
    title: 'Câu 1: Nhận diện cấu trúc hàm',
    prompt: 'Thành phần nào sau đây là cấu trúc chung đúng của một hàm trong bảng tính (SGK Tin học 7)?',
    options: [
      '=TÊN_HÀM(đối số 1, đối số 2,...)',
      'TÊN_HÀM = (đối số 1, đối số 2,...)',
      '=TÊN_HÀM[đối số 1 : đối số 2]',
      '(đối số 1, đối số 2,...)=TÊN_HÀM'
    ],
    correctAnswer: '=TÊN_HÀM(đối số 1, đối số 2,...)',
    explanation: 'Cấu trúc tổng quát: Bắt đầu bằng dấu "=", tiếp theo là TÊN HÀM và các đối số đặt trong cặp ngoặc đơn tròn ( ).',
    errorCodeTested: 'E01'
  },
  {
    id: 'post_02',
    type: 'function_select',
    topic: 'SUM',
    title: 'Câu 2: Ứng dụng hàm tính tổng doanh thu',
    prompt: 'Để tính tổng số tiền quyên góp nuôi heo đất của 4 tổ (các ô C5, C6, C7, C8), công thức chuẩn là gì?',
    options: ['=SUM(C5:C8)', '=AVERAGE(C5:C8)', '=SUM(C5-C8)', '=TOTAL(C5..C8)'],
    correctAnswer: '=SUM(C5:C8)',
    explanation: 'Hàm SUM kết hợp với vùng ô C5:C8 là công thức chính xác nhất.',
    errorCodeTested: 'E02'
  },
  {
    id: 'post_03',
    type: 'bug_detect',
    topic: 'SYNTAX',
    title: 'Câu 3: Sửa lỗi chính tả tên hàm',
    prompt: 'Khi học sinh nhập: =AVERGE(D2:D12), phần mềm bảng tính báo lỗi gì và em cần sửa lại như thế nào?',
    options: [
      'Lỗi sai tên hàm (thiếu chữ "A"), sửa thành =AVERAGE(D2:D12)',
      'Lỗi vùng dữ liệu, sửa thành D2-D12',
      'Lỗi thiếu dấu ngoặc',
      'Không có lỗi, phần mềm tự hiểu'
    ],
    correctAnswer: 'Lỗi sai tên hàm (thiếu chữ "A"), sửa thành =AVERAGE(D2:D12)',
    explanation: 'Tên chuẩn tiếng Anh là AVERAGE (A-V-E-R-A-G-E), viết "AVERGE" là sai chính tả (mã lỗi E02).',
    errorCodeTested: 'E02'
  },
  {
    id: 'post_04',
    type: 'function_select',
    topic: 'AVERAGE',
    title: 'Câu 4: Phân biệt SUM và AVERAGE',
    prompt: 'Đề bài yêu cầu: "Tính chiều cao trung bình của các bạn trong tổ 1 từ ô E2 đến E7". Nếu em dùng =SUM(E2:E7) thì điều gì sẽ xảy ra?',
    options: [
      'Công thức cho ra tổng chiều cao chứ không phải chiều cao trung bình (chọn sai hàm)',
      'Bảng tính sẽ báo lỗi cú pháp không tính được',
      'Kết quả vẫn đúng chiều cao trung bình',
      'Hàm SUM tự động chia cho 6'
    ],
    correctAnswer: 'Công thức cho ra tổng chiều cao chứ không phải chiều cao trung bình (chọn sai hàm)',
    explanation: 'SUM chỉ cộng tổng; để tính trung bình cộng ta phải dùng hàm AVERAGE (mã lỗi E08/E06).',
    errorCodeTested: 'E08'
  },
  {
    id: 'post_05',
    type: 'multiple_choice',
    topic: 'MIN',
    title: 'Câu 5: Nhận biết hàm tìm giá trị nhỏ nhất',
    prompt: 'Để tìm bạn chạy 100m có thời gian ngắn nhất (thành tích tốt nhất) trong cột F (từ F2 đến F20), hàm nào cần sử dụng?',
    options: ['Hàm MIN', 'Hàm MAX', 'Hàm COUNT', 'Hàm SHORT'],
    correctAnswer: 'Hàm MIN',
    explanation: 'Thời gian ngắn nhất là giá trị nhỏ nhất, do đó dùng hàm MIN: =MIN(F2:F20).',
    errorCodeTested: 'E06'
  },
  {
    id: 'post_06',
    type: 'formula_input',
    topic: 'MAX',
    title: 'Câu 6: Viết công thức tìm điểm cao nhất',
    prompt: 'Viết công thức chuẩn để tìm số điểm kiểm tra cao nhất môn Tin học trong vùng từ ô D3 đến D40.',
    correctAnswer: '=MAX(D3:D40)',
    explanation: 'Cú pháp chuẩn: =MAX(D3:D40).',
    errorCodeTested: 'E03'
  },
  {
    id: 'post_07',
    type: 'result_explain',
    topic: 'SUM',
    title: 'Câu 7: Tính toán và kiểm chứng kết quả',
    prompt: 'Cho các ô B2 = 12, B3 = 8, B4 = 20, B5 = 10. Giá trị của công thức =AVERAGE(B2:B5) là:',
    options: ['50', '12.5', '20', '8'],
    correctAnswer: '12.5',
    explanation: 'Tổng = 12 + 8 + 20 + 10 = 50. Số lượng = 4 ô. Trung bình cộng = 50 / 4 = 12.5.',
    errorCodeTested: 'E09'
  },
  {
    id: 'post_08',
    type: 'bug_detect',
    topic: 'SYNTAX',
    title: 'Câu 8: Khắc phục lỗi vùng dữ liệu',
    prompt: 'Công thức =SUM(B2:B6) khác biệt thế nào so với công thức =SUM(B2, B6)?',
    options: [
      'B2:B6 tính tổng 5 ô (B2, B3, B4, B5, B6); còn B2, B6 chỉ tính tổng 2 ô B2 và B6',
      'Hai công thức hoàn toàn giống nhau',
      'B2:B6 bị lỗi cú pháp',
      'B2, B6 bị lỗi cú pháp'
    ],
    correctAnswer: 'B2:B6 tính tổng 5 ô (B2, B3, B4, B5, B6); còn B2, B6 chỉ tính tổng 2 ô B2 và B6',
    explanation: 'Dấu hai chấm (:) biểu thị vùng dữ liệu liên tục; dấu phẩy (,) biểu thị các đối số rời rạc.',
    errorCodeTested: 'E04'
  },
  {
    id: 'post_09',
    type: 'function_select',
    topic: 'COUNT',
    title: 'Câu 9: Hàm COUNT trong quản lý sĩ số',
    prompt: 'Bảng theo dõi gồm cột A (Họ và tên) và cột B (Điểm thi). Vì sao để đếm số học sinh có điểm thi ta dùng =COUNT(B2:B40) mà không dùng =COUNT(A2:A40)?',
    options: [
      'Vì hàm COUNT chỉ đếm các ô chứa dữ liệu số, còn cột A chứa dữ liệu văn bản nên COUNT sẽ cho kết quả 0',
      'Vì hàm COUNT không dùng được với cột A',
      'Vì cột B có ít học sinh hơn',
      'Cả hai công thức đều cho kết quả giống nhau'
    ],
    correctAnswer: 'Vì hàm COUNT chỉ đếm các ô chứa dữ liệu số, còn cột A chứa dữ liệu văn bản nên COUNT sẽ cho kết quả 0',
    explanation: 'SGK Tin học 7 quy định: Hàm COUNT chỉ đếm các ô chứa dữ liệu số, bỏ qua ô chứa ký tự chữ.',
    errorCodeTested: 'E06'
  },
  {
    id: 'post_10',
    type: 'result_explain',
    topic: 'MIN',
    title: 'Câu 10: Kết hợp và đọc kết quả',
    prompt: 'Một cửa hàng có doanh thu các ngày trong tuần: T2=100, T3=150, T4=80, T5=200, T6=120 (vùng C2:C6). Công thức nào cho biết chênh lệch giữa ngày cao nhất và ngày thấp nhất?',
    options: [
      '=MAX(C2:C6) - MIN(C2:C6)',
      '=SUM(C2:C6) - AVERAGE(C2:C6)',
      '=MAX(C2:C6) + MIN(C2:C6)',
      '=COUNT(C2:C6)'
    ],
    correctAnswer: '=MAX(C2:C6) - MIN(C2:C6)',
    explanation: 'Chênh lệch giữa giá trị lớn nhất và nhỏ nhất được tính bằng: MAX(vùng) - MIN(vùng).',
    errorCodeTested: 'E09'
  }
];
