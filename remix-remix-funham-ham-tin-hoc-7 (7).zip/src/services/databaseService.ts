import { getSupabase, isSupabaseConfigured } from './supabaseClient';

export interface ClassRecord {
  id: string;
  class_code: string;
  class_name: string;
  teacher_id: string;
  created_at?: string;
}

export interface StudentRecord {
  id: string;
  class_id: string;
  student_code: string;
  display_name: string;
  created_at?: string;
  class_code?: string;
}

export interface AttemptRecord {
  id?: string;
  student_id: string;
  activity_id: string;
  activity_type: 'pre_assessment' | 'post_assessment' | 'practice' | 'formula_doctor' | 'game' | 'adaptive' | 'quiz';
  score: number;
  max_score: number;
  started_at: string;
  completed_at: string;
  is_demo: boolean;
}

export interface ErrorEventRecord {
  id?: string;
  attempt_id?: string;
  error_code: string;
  corrected: boolean;
  hint_count: number;
  created_at?: string;
}

export interface TeacherStudentAggregated {
  student_id: string;
  student_code: string;
  display_name: string;
  class_code: string;
  class_name: string;
  pre_score: number | null;
  post_score: number | null;
  delta: number | null;
  gain_percent: number | null;
  completed_tasks: number;
  accuracy_rate: number;
  ai_hints_used: number;
  errors_detected: number;
  errors_corrected: number;
  self_correction_rate: number;
  last_activity_at: string | null;
  is_demo: boolean;
}

export interface TeacherDashboardStats {
  totalStudents: number;
  preTestCompletedCount: number;
  postTestCompletedCount: number;
  avgPreScore: number;
  avgPostScore: number;
  avgDelta: number;
  totalTasksCompleted: number;
  overallSelfCorrectionRate: number;
  frequentErrors: { code: string; count: number; name: string }[];
  students: TeacherStudentAggregated[];
  lastSyncedAt: string;
  isUsingSupabase: boolean;
  isDemoMode: boolean;
}

const OFFLINE_QUEUE_KEY = 'funham_offline_sync_queue';

export interface QueuedItem {
  id: string;
  type: 'attempt';
  data: {
    attempt: AttemptRecord;
    errorEvents?: ErrorEventRecord[];
    studentCode: string;
    classCode: string;
    displayName: string;
  };
  timestamp: number;
  retryCount: number;
}

export function getOfflineQueue(): QueuedItem[] {
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

export function saveOfflineQueue(queue: QueuedItem[]): void {
  try {
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
  } catch (e) {
    console.error('Failed to save offline queue', e);
  }
}

export function getOfflineQueueCount(): number {
  return getOfflineQueue().length;
}

/**
 * Ensure a class exists in Supabase. If not found, create it.
 */
export async function syncEnsureClass(classCode: string, className?: string, teacherId = 'gv1'): Promise<ClassRecord> {
  const code = classCode.trim().toUpperCase();
  const name = className?.trim() || `Lớp ${code}`;
  const supabase = getSupabase();

  if (!supabase) {
    // Return mock/local record if no supabase configured
    return {
      id: `local_cls_${code}`,
      class_code: code,
      class_name: name,
      teacher_id: teacherId,
      created_at: new Date().toISOString(),
    };
  }

  // Check if class exists
  const { data: existing, error: selectError } = await supabase
    .from('classes')
    .select('*')
    .eq('class_code', code)
    .maybeSingle();

  if (selectError && selectError.code !== 'PGRST116') {
    console.warn('Error checking class:', selectError);
  }

  if (existing) {
    return existing as ClassRecord;
  }

  // Insert new class
  const { data: inserted, error: insertError } = await supabase
    .from('classes')
    .insert([
      {
        class_code: code,
        class_name: name,
        teacher_id: teacherId,
      },
    ])
    .select()
    .single();

  if (insertError) {
    console.error('Error inserting class:', insertError);
    // If concurrent insert happened, retry query
    const { data: retry } = await supabase
      .from('classes')
      .select('*')
      .eq('class_code', code)
      .maybeSingle();
    if (retry) return retry as ClassRecord;
    throw insertError;
  }

  return inserted as ClassRecord;
}

/**
 * Register or fetch a student by Class Code + Student Code.
 */
export async function syncRegisterStudent(
  classCode: string,
  studentCode: string,
  displayName: string
): Promise<StudentRecord> {
  const normClassCode = classCode.trim().toUpperCase();
  const normStudentCode = studentCode.trim().toUpperCase();
  const normDisplayName = displayName.trim();

  const supabase = getSupabase();

  if (!supabase) {
    return {
      id: `local_std_${normStudentCode}`,
      class_id: `local_cls_${normClassCode}`,
      student_code: normStudentCode,
      display_name: normDisplayName,
      class_code: normClassCode,
      created_at: new Date().toISOString(),
    };
  }

  // 1. Ensure class exists
  const classRec = await syncEnsureClass(normClassCode);

  // 2. Check if student already exists in this class
  const { data: existing, error: stdSelectErr } = await supabase
    .from('students')
    .select('*')
    .eq('class_id', classRec.id)
    .eq('student_code', normStudentCode)
    .maybeSingle();

  if (existing) {
    // If display name updated, update it
    if (existing.display_name !== normDisplayName) {
      await supabase
        .from('students')
        .update({ display_name: normDisplayName })
        .eq('id', existing.id);
      existing.display_name = normDisplayName;
    }
    return {
      ...existing,
      class_code: normClassCode,
    } as StudentRecord;
  }

  // 3. Insert student
  const { data: inserted, error: insertErr } = await supabase
    .from('students')
    .insert([
      {
        class_id: classRec.id,
        student_code: normStudentCode,
        display_name: normDisplayName,
      },
    ])
    .select()
    .single();

  if (insertErr) {
    console.error('Error registering student:', insertErr);
    // Fallback lookup
    const { data: retry } = await supabase
      .from('students')
      .select('*')
      .eq('class_id', classRec.id)
      .eq('student_code', normStudentCode)
      .maybeSingle();
    if (retry) {
      return { ...retry, class_code: normClassCode } as StudentRecord;
    }
    throw insertErr;
  }

  return {
    ...inserted,
    class_code: normClassCode,
  } as StudentRecord;
}

/**
 * Save an assessment or practice attempt with optional error events.
 * Returns detailed status: whether it was committed to Supabase or queued offline.
 */
export async function syncSaveAttempt(
  attempt: AttemptRecord,
  errorEvents?: ErrorEventRecord[],
  studentMeta?: { studentCode: string; classCode: string; displayName: string }
): Promise<{ success: boolean; attemptId?: string; offline?: boolean; error?: string }> {
  const supabase = getSupabase();

  // If not configured or navigator is offline, push to offline queue
  if (!supabase || (typeof navigator !== 'undefined' && !navigator.onLine)) {
    if (studentMeta) {
      const queue = getOfflineQueue();
      queue.push({
        id: `queue_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        type: 'attempt',
        data: {
          attempt,
          errorEvents,
          studentCode: studentMeta.studentCode,
          classCode: studentMeta.classCode,
          displayName: studentMeta.displayName,
        },
        timestamp: Date.now(),
        retryCount: 0,
      });
      saveOfflineQueue(queue);
    }
    return {
      success: true,
      offline: true,
      error: !supabase ? 'Chưa cấu hình Supabase URL - Đã lưu tạm bộ nhớ nội bộ' : 'Mất kết nối mạng - Đã lưu hàng đợi chờ đồng bộ',
    };
  }

  try {
    // 1. Resolve student UUID if not valid UUID
    let targetStudentId = attempt.student_id;
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(targetStudentId);

    if ((!isUUID || targetStudentId.startsWith('hs_') || targetStudentId.startsWith('std_')) && studentMeta) {
      try {
        const stdRec = await syncRegisterStudent(
          studentMeta.classCode,
          studentMeta.studentCode,
          studentMeta.displayName
        );
        if (stdRec?.id) {
          targetStudentId = stdRec.id;
        }
      } catch (err) {
        console.warn('Failed to auto-register student for UUID:', err);
      }
    }

    // 2. Insert attempt
    let attemptData: any = null;
    let attemptErr: any = null;

    const res = await supabase
      .from('attempts')
      .insert([
        {
          student_id: targetStudentId,
          activity_id: attempt.activity_id,
          activity_type: attempt.activity_type,
          score: attempt.score,
          max_score: attempt.max_score,
          started_at: attempt.started_at,
          completed_at: attempt.completed_at,
          is_demo: Boolean(attempt.is_demo),
        },
      ])
      .select()
      .single();

    attemptData = res.data;
    attemptErr = res.error;

    // If foreign key failed (student id was not in DB), register and retry once
    if (attemptErr && studentMeta) {
      console.warn('Attempt insert failed, retrying after re-registering student:', attemptErr);
      try {
        const retryStd = await syncRegisterStudent(
          studentMeta.classCode,
          studentMeta.studentCode,
          studentMeta.displayName
        );
        if (retryStd?.id) {
          const retryRes = await supabase
            .from('attempts')
            .insert([
              {
                student_id: retryStd.id,
                activity_id: attempt.activity_id,
                activity_type: attempt.activity_type,
                score: attempt.score,
                max_score: attempt.max_score,
                started_at: attempt.started_at,
                completed_at: attempt.completed_at,
                is_demo: Boolean(attempt.is_demo),
              },
            ])
            .select()
            .single();
          attemptData = retryRes.data;
          attemptErr = retryRes.error;
        }
      } catch (retryE) {
        console.error('Retry student registration failed:', retryE);
      }
    }

    if (attemptErr) {
      throw attemptErr;
    }

    const savedAttemptId = attemptData.id;

    // 2. Insert error events if any
    if (errorEvents && errorEvents.length > 0) {
      const recordsToInsert = errorEvents.map((ev) => ({
        attempt_id: savedAttemptId,
        error_code: ev.error_code,
        corrected: Boolean(ev.corrected),
        hint_count: ev.hint_count || 0,
      }));

      const { error: errEventsErr } = await supabase
        .from('error_events')
        .insert(recordsToInsert);

      if (errEventsErr) {
        console.warn('Failed to insert error_events:', errEventsErr);
      }
    }

    return {
      success: true,
      attemptId: savedAttemptId,
      offline: false,
    };
  } catch (err: any) {
    console.error('syncSaveAttempt network/server error:', err);

    // Save to offline queue on network exception
    if (studentMeta) {
      const queue = getOfflineQueue();
      queue.push({
        id: `queue_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        type: 'attempt',
        data: {
          attempt,
          errorEvents,
          studentCode: studentMeta.studentCode,
          classCode: studentMeta.classCode,
          displayName: studentMeta.displayName,
        },
        timestamp: Date.now(),
        retryCount: 0,
      });
      saveOfflineQueue(queue);
    }

    return {
      success: false,
      offline: true,
      error: err.message || 'Lỗi lưu dữ liệu máy chủ',
    };
  }
}

/**
 * Flush offline queue when reconnected to internet
 */
export async function flushOfflineQueue(): Promise<{ syncedCount: number; errorsCount: number }> {
  const queue = getOfflineQueue();
  if (queue.length === 0) return { syncedCount: 0, errorsCount: 0 };

  const supabase = getSupabase();
  if (!supabase || (typeof navigator !== 'undefined' && !navigator.onLine)) {
    return { syncedCount: 0, errorsCount: 0 };
  }

  let syncedCount = 0;
  let errorsCount = 0;
  const remainingQueue: QueuedItem[] = [];

  for (const item of queue) {
    try {
      if (item.type === 'attempt') {
        const { attempt, errorEvents, studentCode, classCode, displayName } = item.data;
        // Re-resolve student ID in Supabase
        const studentRec = await syncRegisterStudent(classCode, studentCode, displayName);
        const resolvedAttempt: AttemptRecord = {
          ...attempt,
          student_id: studentRec.id,
        };

        const res = await syncSaveAttempt(resolvedAttempt, errorEvents);
        if (res.success && !res.offline) {
          syncedCount++;
        } else {
          item.retryCount++;
          remainingQueue.push(item);
          errorsCount++;
        }
      }
    } catch (e) {
      item.retryCount++;
      remainingQueue.push(item);
      errorsCount++;
    }
  }

  saveOfflineQueue(remainingQueue);
  return { syncedCount, errorsCount };
}

// Auto-listen to window online event
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    console.log('App is online, flushing offline queue...');
    flushOfflineQueue().then(({ syncedCount }) => {
      if (syncedCount > 0) {
        console.log(`Successfully synced ${syncedCount} queued attempts to Supabase.`);
      }
    });
  });
}

/**
 * Fetch all classes from Supabase
 */
export async function syncFetchClasses(): Promise<ClassRecord[]> {
  const supabase = getSupabase();
  if (!supabase) {
    return [
      { id: 'c1', class_code: '7A1', class_name: 'Lớp 7A1', teacher_id: 'gv1' },
      { id: 'c2', class_code: '7A2', class_name: 'Lớp 7A2', teacher_id: 'gv1' },
      { id: 'c3', class_code: '7A3', class_name: 'Lớp 7A3', teacher_id: 'gv1' },
    ];
  }

  try {
    const { data, error } = await supabase
      .from('classes')
      .select('*')
      .order('class_code', { ascending: true });

    if (error) {
      console.warn('Failed to fetch classes from Supabase:', error);
      return [];
    }

    return (data || []) as ClassRecord[];
  } catch (err) {
    console.error('Error fetching classes:', err);
    return [];
  }
}

/**
 * Fetch Teacher Dashboard Aggregated Statistics
 * Strict filtering:
 * - is_demo filter:
 *   If includeDemo is false (DEFAULT): ONLY selects attempts where is_demo = false.
 *   If includeDemo is true: shows demo data.
 */
export async function syncFetchTeacherDashboardData(
  classCode?: string,
  includeDemo = false
): Promise<TeacherDashboardStats> {
  const supabase = getSupabase();
  const isUsingSupabase = Boolean(supabase && isSupabaseConfigured());

  // Error definitions dictionary
  const ERROR_TITLES: Record<string, string> = {
    E01: 'Thiếu dấu =',
    E02: 'Sai tên hàm',
    E03: 'Sai dấu ngoặc ()',
    E04: 'Sai cú pháp vùng (:)',
    E05: 'Sai dấu phân cách đối số',
    E06: 'Chọn hàm không phù hợp',
    E07: 'Chọn sai ô / vùng dữ liệu',
    E08: 'Nhầm công dụng hàm',
    E09: 'Hiểu sai kết quả tính toán',
    E10: 'Lỗi cú pháp khác',
  };

  if (!isUsingSupabase || !supabase) {
    return {
      totalStudents: 0,
      preTestCompletedCount: 0,
      postTestCompletedCount: 0,
      avgPreScore: 0,
      avgPostScore: 0,
      avgDelta: 0,
      totalTasksCompleted: 0,
      overallSelfCorrectionRate: 0,
      frequentErrors: [],
      students: [],
      lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
      isUsingSupabase: false,
      isDemoMode: includeDemo,
    };
  }

  try {
    // 1. Fetch classes
    let classQuery = supabase.from('classes').select('id, class_code, class_name');
    if (classCode && classCode !== 'ALL') {
      classQuery = classQuery.eq('class_code', classCode.trim().toUpperCase());
    }
    const { data: classesData, error: classErr } = await classQuery;
    if (classErr) throw classErr;

    const classIds = (classesData || []).map((c) => c.id);
    const classMap = new Map((classesData || []).map((c) => [c.id, c]));

    if (classIds.length === 0) {
      return {
        totalStudents: 0,
        preTestCompletedCount: 0,
        postTestCompletedCount: 0,
        avgPreScore: 0,
        avgPostScore: 0,
        avgDelta: 0,
        totalTasksCompleted: 0,
        overallSelfCorrectionRate: 0,
        frequentErrors: [],
        students: [],
        lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
        isUsingSupabase: true,
        isDemoMode: includeDemo,
      };
    }

    // 2. Fetch students in these classes
    const { data: studentsData, error: stdErr } = await supabase
      .from('students')
      .select('id, class_id, student_code, display_name, created_at')
      .in('class_id', classIds);

    if (stdErr) throw stdErr;

    const studentIds = (studentsData || []).map((s) => s.id);
    if (studentIds.length === 0) {
      return {
        totalStudents: 0,
        preTestCompletedCount: 0,
        postTestCompletedCount: 0,
        avgPreScore: 0,
        avgPostScore: 0,
        avgDelta: 0,
        totalTasksCompleted: 0,
        overallSelfCorrectionRate: 0,
        frequentErrors: [],
        students: [],
        lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
        isUsingSupabase: true,
        isDemoMode: includeDemo,
      };
    }

    // 3. Fetch attempts for these students
    // STRICT RULE: filter by is_demo
    let attemptsQuery = supabase
      .from('attempts')
      .select('id, student_id, activity_id, activity_type, score, max_score, started_at, completed_at, is_demo')
      .in('student_id', studentIds);

    if (!includeDemo) {
      attemptsQuery = attemptsQuery.or('is_demo.eq.false,is_demo.is.null');
    } else {
      attemptsQuery = attemptsQuery.eq('is_demo', true);
    }

    const { data: attemptsData, error: attErr } = await attemptsQuery;
    if (attErr) throw attErr;

    const attemptList = attemptsData || [];
    const attemptIds = attemptList.map((a) => a.id);

    // 4. Fetch error events for these attempts
    let errorEventsList: any[] = [];
    if (attemptIds.length > 0) {
      const { data: errEvents, error: evErr } = await supabase
        .from('error_events')
        .select('id, attempt_id, error_code, corrected, hint_count')
        .in('attempt_id', attemptIds);

      if (!evErr && errEvents) {
        errorEventsList = errEvents;
      }
    }

    // Map attempts and error events by student_id
    const attemptsByStudent = new Map<string, any[]>();
    for (const att of attemptList) {
      if (!attemptsByStudent.has(att.student_id)) {
        attemptsByStudent.set(att.student_id, []);
      }
      attemptsByStudent.get(att.student_id)!.push(att);
    }

    const errorsByAttempt = new Map<string, any[]>();
    for (const ev of errorEventsList) {
      if (!errorsByAttempt.has(ev.attempt_id)) {
        errorsByAttempt.set(ev.attempt_id, []);
      }
      errorsByAttempt.get(ev.attempt_id)!.push(ev);
    }

    // Frequent errors count
    const errorCounts: Record<string, number> = {};
    for (const ev of errorEventsList) {
      const code = ev.error_code || 'E10';
      errorCounts[code] = (errorCounts[code] || 0) + 1;
    }

    const frequentErrors = Object.entries(errorCounts)
      .map(([code, count]) => ({
        code,
        count,
        name: ERROR_TITLES[code] || 'Lỗi cú pháp',
      }))
      .sort((a, b) => b.count - a.count);

    // Process per-student aggregated statistics
    const aggregatedStudents: TeacherStudentAggregated[] = [];

    let totalPreScoreSum = 0;
    let preCount = 0;
    let totalPostScoreSum = 0;
    let postCount = 0;
    let totalTasksCompleted = 0;
    let totalErrorsDetected = 0;
    let totalErrorsCorrected = 0;

    for (const std of studentsData || []) {
      const classInfo = classMap.get(std.class_id);
      const studentAttempts = attemptsByStudent.get(std.id) || [];

      // If in real mode and student has no attempts, they are still listed if registered
      // Identify Pre & Post assessments (latest attempt)
      const preAttempts = studentAttempts
        .filter((a) => a.activity_type === 'pre_assessment' || a.activity_id === 'pre_test')
        .sort((a, b) => (b.completed_at || '').localeCompare(a.completed_at || ''));
      const postAttempts = studentAttempts
        .filter((a) => a.activity_type === 'post_assessment' || a.activity_id === 'post_test')
        .sort((a, b) => (b.completed_at || '').localeCompare(a.completed_at || ''));

      const preAttempt = preAttempts[0] || null;
      const postAttempt = postAttempts[0] || null;

      const preScore = preAttempt ? preAttempt.score : null;
      const postScore = postAttempt ? postAttempt.score : null;

      let delta: number | null = null;
      let gainPercent: number | null = null;
      if (preScore !== null && postScore !== null) {
        delta = Number((postScore - preScore).toFixed(1));
        gainPercent =
          preScore < 10
            ? Number((((postScore - preScore) / (10 - preScore)) * 100).toFixed(1))
            : 100;
      }

      if (preScore !== null) {
        totalPreScoreSum += preScore;
        preCount++;
      }
      if (postScore !== null) {
        totalPostScoreSum += postScore;
        postCount++;
      }

      totalTasksCompleted += studentAttempts.length;

      // Calculate errors and corrections for this student
      let stdAiHints = 0;
      let stdErrors = 0;
      let stdCorrected = 0;

      for (const att of studentAttempts) {
        const evs = errorsByAttempt.get(att.id) || [];
        for (const ev of evs) {
          stdErrors++;
          stdAiHints += ev.hint_count || 0;
          if (ev.corrected) {
            stdCorrected++;
          }
        }
      }

      totalErrorsDetected += stdErrors;
      totalErrorsCorrected += stdCorrected;

      const selfCorrectionRate =
        stdErrors > 0 ? Number(((stdCorrected / stdErrors) * 100).toFixed(1)) : 100;

      // Accuracy calculation based on scores/max_scores
      let totalEarned = 0;
      let totalMax = 0;
      for (const att of studentAttempts) {
        totalEarned += att.score || 0;
        totalMax += att.max_score || 10;
      }
      const accuracyRate = totalMax > 0 ? Number(((totalEarned / totalMax) * 100).toFixed(1)) : 0;

      // Find last activity time
      const latestTime = studentAttempts
        .map((a) => a.completed_at || a.started_at)
        .sort()
        .pop() || null;

      aggregatedStudents.push({
        student_id: std.id,
        student_code: std.student_code,
        display_name: std.display_name,
        class_code: classInfo?.class_code || 'Chưa rõ',
        class_name: classInfo?.class_name || 'Lớp học',
        pre_score: preScore,
        post_score: postScore,
        delta,
        gain_percent: gainPercent,
        completed_tasks: studentAttempts.length,
        accuracy_rate: accuracyRate,
        ai_hints_used: stdAiHints,
        errors_detected: stdErrors,
        errors_corrected: stdCorrected,
        self_correction_rate: selfCorrectionRate,
        last_activity_at: latestTime,
        is_demo: includeDemo,
      });
    }

    const avgPre = preCount > 0 ? Number((totalPreScoreSum / preCount).toFixed(1)) : 0;
    const avgPost = postCount > 0 ? Number((totalPostScoreSum / postCount).toFixed(1)) : 0;
    const avgDelta = Number((avgPost - avgPre).toFixed(1));

    const overallSelfCorrectionRate =
      totalErrorsDetected > 0
        ? Number(((totalErrorsCorrected / totalErrorsDetected) * 100).toFixed(1))
        : 100;

    return {
      totalStudents: aggregatedStudents.length,
      preTestCompletedCount: preCount,
      postTestCompletedCount: postCount,
      avgPreScore: avgPre,
      avgPostScore: avgPost,
      avgDelta,
      totalTasksCompleted,
      overallSelfCorrectionRate,
      frequentErrors,
      students: aggregatedStudents,
      lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
      isUsingSupabase: true,
      isDemoMode: includeDemo,
    };
  } catch (err: any) {
    console.error('Error in syncFetchTeacherDashboardData:', err);
    throw err;
  }
}
