import { createClient, SupabaseClient } from '@supabase/supabase-js';

const STORAGE_KEY_URL = 'funham_supabase_url';
const STORAGE_KEY_KEY = 'funham_supabase_anon_key';

export function getSupabaseConfig(): { url: string; anonKey: string } {
  const metaEnv = (import.meta as any).env || {};
  let rawUrl = (metaEnv.VITE_SUPABASE_URL || '').trim();
  let rawKey = (metaEnv.VITE_SUPABASE_ANON_KEY || '').trim();

  try {
    const localUrl = (localStorage.getItem(STORAGE_KEY_URL) || '').trim();
    const localKey = (localStorage.getItem(STORAGE_KEY_KEY) || '').trim();
    if (localUrl && localKey) {
      rawUrl = localUrl;
      rawKey = localKey;
    }
  } catch (e) {}

  // Sanitize Supabase URL: strip /rest/v1, /graphql, and trailing slashes if user pasted full REST endpoint
  if (rawUrl) {
    rawUrl = rawUrl
      .replace(/\/rest\/v1\/?$/i, '')
      .replace(/\/graphql\/?$/i, '')
      .replace(/\/+$/, '');
  }

  return { url: rawUrl, anonKey: rawKey };
}

export function saveSupabaseConfig(url: string, anonKey: string): void {
  try {
    if (url.trim() && anonKey.trim()) {
      localStorage.setItem(STORAGE_KEY_URL, url.trim());
      localStorage.setItem(STORAGE_KEY_KEY, anonKey.trim());
      // Reset instance so next call uses new credentials
      supabaseInstance = null;
    } else {
      localStorage.removeItem(STORAGE_KEY_URL);
      localStorage.removeItem(STORAGE_KEY_KEY);
      supabaseInstance = null;
    }
  } catch (e) {
    console.error('Failed to save Supabase config to localStorage', e);
  }
}

export function isSupabaseConfigured(): boolean {
  const { url, anonKey } = getSupabaseConfig();
  if (!url || !anonKey || !url.startsWith('http')) return false;

  const lowerUrl = url.toLowerCase();
  const lowerKey = anonKey.toLowerCase();
  if (
    lowerUrl.includes('your-project') ||
    lowerUrl.includes('placeholder') ||
    lowerKey.includes('your-anon-key') ||
    lowerKey.includes('placeholder') ||
    lowerKey === 'your-anon-key'
  ) {
    return false;
  }

  return true;
}

let supabaseInstance: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient | null {
  if (supabaseInstance) return supabaseInstance;

  const { url, anonKey } = getSupabaseConfig();
  if (!url || !anonKey) {
    return null;
  }

  try {
    supabaseInstance = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    return supabaseInstance;
  } catch (err) {
    console.error('Error creating Supabase client:', err);
    return null;
  }
}
