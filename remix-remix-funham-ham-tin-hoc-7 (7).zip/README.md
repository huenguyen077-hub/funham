# TIN MASTER 6

"Chinh phục Tin học – Học vui, luyện giỏi"

Web App học tập Tin học tương tác dành cho học sinh THCS, tập trung vào kiến thức bảng tính điện tử và các hàm cơ bản (SUM, AVERAGE, MIN, MAX, COUNT).

## 🚀 Tính năng

- **Dành cho học sinh:**
  - Học bài trực quan với Flashcard 3D.
  - Chơi game rèn luyện (Trắc nghiệm, Điền khuyết, Chọn đáp án nhanh).
  - Thực hành mô phỏng bảng tính trực tiếp.
  - Hệ thống Gamification: Cấp độ, XP, Chuỗi ngày học, Huy hiệu.
  - Bảng xếp hạng.

- **Dành cho giáo viên:**
  - Dashboard tổng quan tình hình học tập.
  - Quản lý danh sách học sinh.
  - Ngân hàng câu hỏi (Tất cả các hàm).

## 🛠 Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- React Router
- Zustand (State & LocalStorage persistence)
- Framer Motion (Animations)
- Lucide React (Icons)
- Canvas Confetti

## 📦 Cài đặt & Chạy Local

1. Cài đặt dependencies:
   ```bash
   npm install
   ```

2. Chạy môi trường development:
   ```bash
   npm run dev
   ```

3. Build cho production:
   ```bash
   npm run build
   ```

## 🌐 Triển khai (Deploy)

Ứng dụng được thiết kế client-side và có thể dễ dàng deploy lên các nền tảng phổ biến:

**Vercel / Netlify:**
1. Tạo project mới trên Vercel/Netlify.
2. Trỏ vào repository.
3. Cấu hình build command: `npm run build`
4. Cấu hình publish directory: `dist`
5. Thêm rewrite rule để hỗ trợ React Router:
   - *Netlify*: Thêm file `public/_redirects` với nội dung `/* /index.html 200`
   - *Vercel*: Thêm file `vercel.json` với cấu hình rewrites.

**GitHub Pages:**
1. Trong `vite.config.ts`, `base` đã được set thành `'./'` để tương thích.
2. Có thể sử dụng package `gh-pages` để deploy thư mục `dist`.

## 👤 Tài khoản Demo

**Học sinh:**
- Nguyễn An (Lớp 7A1)
- Trần Minh (Lớp 7A1)
- Lê Hoa (Lớp 7A2)
- Phạm Nam (Lớp 7A2)

**Giáo viên:**
- GV001 - Giáo viên Tin học
